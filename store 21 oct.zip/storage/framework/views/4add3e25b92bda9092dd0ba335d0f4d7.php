<?php
    $cartService = app(\App\Services\CartService::class);
    $cartTotals = $cartService->totals();
    $cartItems = $cartTotals['items'] ?? collect();
    $cartCount = (int) ($cartTotals['count'] ?? 0);
    $cartSubtotal = (float) ($cartTotals['subtotal'] ?? 0);
    $cartDiscount = (float) ($cartTotals['discount'] ?? 0);
    $cartTax = (float) ($cartTotals['tax'] ?? 0);
    $cartShipping = (float) ($cartTotals['shipping'] ?? 0);
    $cartGrandTotal = (float) ($cartTotals['grand_total'] ?? 0);
    $freeShippingThreshold = 2000;
    $shippingProgress = min(100, $cartSubtotal > 0 ? ($cartSubtotal / $freeShippingThreshold) * 100 : 0);
?>

<!-- ============================================================
     PREMIUM FLOATING SHOPPING CART TRIGGER
     Vertically centered on the right edge, matching Ionia theme
     ============================================================ -->
<button type="button" class="ion-floating-cart-btn" id="floatingCartBtn" aria-label="Open Shopping Bag" title="View Shopping Bag">
    <div class="ion-floating-inner">
        <div class="ion-floating-icon-wrap">
            <i class="fa-solid fa-bag-shopping ion-floating-icon"></i>
            <span class="ion-floating-badge cart-count-badge" id="floatingCartBadge" style="<?php echo e($cartCount > 0 ? '' : 'display:none;'); ?>">
                <?php echo e($cartCount); ?>

            </span>
        </div>
        <span class="ion-floating-label">Cart</span>
    </div>
</button>

<!-- ============================================================
     PREMIUM CART DRAWER OVERLAY
     Glassmorphic frosted dark overlay
     ============================================================ -->
<div class="ion-cart-overlay" id="scDrawerOverlay" aria-hidden="true"></div>

<!-- ============================================================
     PREMIUM CART SLIDE DRAWER PANEL
     High-end slide-out luxury drawer (460px desktop, full mobile)
     ============================================================ -->
<aside class="ion-cart-drawer" id="scDrawerPanel" role="dialog" aria-modal="true" aria-labelledby="scDrawerHeading" aria-hidden="true">

    <!-- 1. DRAWER HEADER -->
    <div class="ion-drawer-header">
        <div class="ion-drawer-title-group">
            <div class="ion-header-icon-box">
                <i class="fa-solid fa-bag-shopping"></i>
            </div>
            <div>
                <h4 class="ion-drawer-heading" id="scDrawerHeading">
                    <span>Shopping Bag</span>
                    <span class="ion-item-chip" id="scHeaderItemBadge"><?php echo e($cartCount); ?> <?php echo e($cartCount === 1 ? 'item' : 'items'); ?></span>
                </h4>
                <p class="ion-drawer-subheading">Authentic Korean Alkaline Technology</p>
            </div>
        </div>
        <button type="button" class="ion-drawer-close" id="scDrawerClose" aria-label="Close Shopping Bag">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>

    <!-- 2. FREE SHIPPING PROGRESS BAR -->
    <div class="ion-shipping-strip" id="scShippingNoticeWrap">
        <div class="ion-shipping-status">
            <div class="ion-shipping-msg" id="scShippingNoticeText">
                <?php if($cartSubtotal >= $freeShippingThreshold): ?>
                    <span class="ion-ship-icon unlocked"><i class="fa-solid fa-circle-check"></i></span>
                    <span>You've unlocked <strong>FREE Express Insured Shipping</strong>!</span>
                <?php else: ?>
                    <span class="ion-ship-icon progress-icon"><i class="fa-solid fa-truck-fast"></i></span>
                    <span>Add <strong>₹<?php echo e(number_format(max(0, $freeShippingThreshold - $cartSubtotal), 2)); ?></strong> more for <strong>FREE Shipping</strong></span>
                <?php endif; ?>
            </div>
            <span class="ion-shipping-pct" id="scShippingPct"><?php echo e(round($shippingProgress)); ?>%</span>
        </div>
        <div class="ion-shipping-meter">
            <div class="ion-shipping-bar" id="scShippingProgressFill" style="width: <?php echo e($shippingProgress); ?>%;"></div>
        </div>
    </div>

    <!-- 3. DRAWER BODY (SCROLLABLE) -->
    <div class="ion-drawer-body">

        <!-- EMPTY STATE -->
        <div class="ion-cart-empty" id="scEmptyState" style="<?php echo e($cartCount === 0 ? 'display:flex;' : 'display:none;'); ?>">
            <div class="ion-empty-graphic">
                <div class="ion-empty-circle-bg"></div>
                <div class="ion-empty-icon-box">
                    <i class="fa-solid fa-bag-shopping"></i>
                </div>
            </div>
            <h5 class="ion-empty-title">Your shopping bag is empty</h5>
            <p class="ion-empty-desc">Discover our premium range of Korean alkaline water ionizers and wellness filtration systems.</p>
            <a href="<?php echo e(url('/products')); ?>" class="ion-btn-explore" id="scContinueShoppingBtn">
                <span>Explore Products</span>
                <i class="fa-solid fa-arrow-right"></i>
            </a>

            <!-- Quick Trust Pillars in Empty State -->
            <div class="ion-empty-pillars">
                <div class="ion-pillar-item">
                    <i class="fa-solid fa-shield-halved"></i>
                    <span>Korea's #1 Alkaline Tech</span>
                </div>
                <div class="ion-pillar-item">
                    <i class="fa-solid fa-truck-fast"></i>
                    <span>Free Shipping Above ₹2,000</span>
                </div>
                <div class="ion-pillar-item">
                    <i class="fa-solid fa-medal"></i>
                    <span>20–25 Years Life Span</span>
                </div>
            </div>
        </div>

        <!-- POPULATED CART ITEMS -->
        <div class="ion-cart-populated" id="scCartContent" style="<?php echo e($cartCount > 0 ? 'display:block;' : 'display:none;'); ?>">
            <div class="ion-items-list" id="scItemsContainer">
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $prod = $item->product;
                    $thumb = $prod ? \App\Models\Product::resolveImageUrl($prod->thumbnail) : null;
                    $pUrl = $prod ? url('product-details/' . $prod->slug) : '#';
                    $pName = $prod ? $prod->name : 'Product';
                    $pBrand = $prod && $prod->brand ? $prod->brand->name : 'Ionia Korea';
                ?>
                <div class="ion-cart-card" data-id="<?php echo e($item->id); ?>">
                    <!-- Thumbnail -->
                    <a href="<?php echo e($pUrl); ?>" class="ion-card-thumb-wrap" title="<?php echo e($pName); ?>">
                        <?php if($thumb): ?>
                            <img src="<?php echo e($thumb); ?>" alt="<?php echo e($pName); ?>" class="ion-card-thumb" loading="lazy">
                        <?php else: ?>
                            <div class="ion-card-placeholder">
                                <i class="fa-solid fa-droplet"></i>
                            </div>
                        <?php endif; ?>
                    </a>

                    <!-- Details -->
                    <div class="ion-card-details">
                        <div class="ion-card-header-row">
                            <a href="<?php echo e($pUrl); ?>" class="ion-card-title" title="<?php echo e($pName); ?>">
                                <?php echo e($pName); ?>

                            </a>
                            <button type="button" class="ion-btn-remove sc-btn-trash" data-id="<?php echo e($item->id); ?>" aria-label="Remove item" title="Remove item">
                                <i class="fa-regular fa-trash-can"></i>
                            </button>
                        </div>

                        <div class="ion-card-meta">
                            <span class="ion-card-brand-badge">
                                <i class="fa-solid fa-circle-check"></i> <?php echo e($pBrand); ?>

                            </span>
                            <span class="ion-card-unit-price">
                                ₹<?php echo e(number_format($item->price, 2)); ?>

                            </span>
                        </div>

                        <!-- Stepper & Line Total Row -->
                        <div class="ion-card-action-row">
                            <div class="ion-qty-stepper sc-qty-wrapper">
                                <button type="button" class="ion-stepper-btn ion-stepper-minus sc-qty-btn sc-qty-minus" aria-label="Decrease quantity">
                                    <i class="fa-solid fa-minus"></i>
                                </button>
                                <input type="number" min="1" max="99" value="<?php echo e($item->quantity); ?>" class="ion-stepper-input sc-qty-input" data-id="<?php echo e($item->id); ?>" aria-label="Quantity" readonly>
                                <button type="button" class="ion-stepper-btn ion-stepper-plus sc-qty-btn sc-qty-plus" aria-label="Increase quantity">
                                    <i class="fa-solid fa-plus"></i>
                                </button>
                            </div>

                            <div class="ion-card-price-wrap">
                                <span class="ion-card-price-label">Total</span>
                                <span class="ion-card-line-price sc-price-val">₹ <?php echo e(number_format($item->price * $item->quantity, 2)); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Trust Bar Inside Items -->
            <div class="ion-trust-pills-bar">
                <div class="ion-trust-pill">
                    <i class="fa-solid fa-shield-halved"></i>
                    <span>100% Genuine Korean Tech</span>
                </div>
                <div class="ion-trust-pill">
                    <i class="fa-solid fa-lock"></i>
                    <span>Secure Checkout</span>
                </div>
            </div>
        </div>

    </div>

    <!-- 4. DRAWER FOOTER (STICKY) -->
    <div class="ion-drawer-footer" id="scDrawerFooter" style="<?php echo e($cartCount > 0 ? '' : 'display:none;'); ?>">

        <!-- Collapsible Coupon Code Accordion -->
        <div class="ion-coupon-accordion">
            <button type="button" class="ion-coupon-toggle" id="scCouponToggle" aria-expanded="false">
                <span class="ion-coupon-toggle-text">
                    <i class="fa-solid fa-tag ion-coupon-icon"></i>
                    <span>Have a promo code?</span>
                </span>
                <i class="fa-solid fa-chevron-down ion-coupon-chevron" id="scCouponChevron"></i>
            </button>
            <div class="ion-coupon-collapse" id="scCouponCollapse">
                <div class="ion-coupon-form">
                    <div class="ion-coupon-input-wrap">
                        <input type="text" id="scCouponCode" class="ion-coupon-input" placeholder="Enter coupon code" autocomplete="off" spellcheck="false">
                        <button type="button" id="scApplyCouponBtn" class="ion-coupon-btn">Apply</button>
                    </div>
                    <div class="ion-coupon-feedback" id="scCouponFeedback"></div>
                </div>
            </div>
        </div>

        <!-- Bill Breakdown -->
        <div class="ion-summary-box">
            <div class="ion-summary-row">
                <span class="ion-sum-label">Item Subtotal</span>
                <span class="ion-sum-val" id="scSumSubtotal">₹ <?php echo e(number_format($cartSubtotal, 2)); ?></span>
            </div>

            <div class="ion-summary-row ion-discount-row" id="scDiscountRow" style="<?php echo e($cartDiscount > 0 ? '' : 'display:none;'); ?>">
                <span class="ion-sum-label"><i class="fa-solid fa-percent me-1"></i> Coupon Discount</span>
                <span class="ion-sum-val ion-discount-val" id="scSumDiscount">- ₹ <?php echo e(number_format($cartDiscount, 2)); ?></span>
            </div>

            <div class="ion-summary-row">
                <span class="ion-sum-label">Estimated Tax (GST 18%)</span>
                <span class="ion-sum-val" id="scSumGst">₹ <?php echo e(number_format($cartTax, 2)); ?></span>
            </div>

            <div class="ion-summary-row">
                <span class="ion-sum-label">Estimated Shipping</span>
                <span class="ion-sum-val ion-shipping-val" id="scSumShipping">
                    <?php if($cartSubtotal >= $freeShippingThreshold): ?>
                        <span class="ion-free-ship-tag"><i class="fa-solid fa-bolt me-1"></i> FREE</span>
                    <?php else: ?>
                        ₹ 100.00
                    <?php endif; ?>
                </span>
            </div>

            <!-- Grand Total Row -->
            <div class="ion-summary-row ion-total-row">
                <div>
                    <div class="ion-total-label">Total Payable</div>
                    <div class="ion-total-note">Inclusive of GST & shipping</div>
                </div>
                <div class="ion-total-val" id="scSumTotal">
                    ₹ <?php echo e(number_format($cartGrandTotal, 2)); ?>

                </div>
            </div>
        </div>

        <!-- Primary Checkout CTA Button -->
        <div class="ion-checkout-action-wrap">
            <a href="<?php echo e(url('/checkout')); ?>" class="ion-btn-checkout" id="scProceedCheckout">
                <span class="ion-checkout-btn-text">
                    <i class="fa-solid fa-lock ion-btn-lock"></i>
                    <span>Proceed to Checkout</span>
                </span>
                <span class="ion-checkout-btn-amount">
                    <span id="scCheckoutBtnPrice">₹ <?php echo e(number_format($cartGrandTotal, 2)); ?></span>
                    <i class="fa-solid fa-arrow-right ms-2"></i>
                </span>
            </a>

            <!-- Secondary link: View Full Cart page -->
            <div class="ion-view-cart-wrap">
                <a href="<?php echo e(url('/cart')); ?>" class="ion-link-view-cart">
                    <span>View full cart page</span>
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </a>
            </div>
        </div>

        <!-- Safe Checkout Trust Footer -->
        <div class="ion-drawer-trust-footer">
            <div class="ion-trust-secure-note">
                <i class="fa-solid fa-shield-check"></i>
                <span>Guaranteed Safe & 256-Bit Encrypted Checkout</span>
            </div>
        </div>

    </div>

</aside>

<!-- ============================================================
     PREMIUM CSS STYLING FOR THE IONIA CART DRAWER & FLOATING BTN
     ============================================================ -->
<style>
/* --- Design Tokens & Color Palette --- */
:root {
    --ion-dark: #173a46;
    --ion-dark-darker: #0d2229;
    --ion-dark-light: #214e5d;
    --ion-coral: #c8372d;
    --ion-coral-hover: #ad2c23;
    --ion-coral-tint: #fef2f2;
    --ion-coral-border: #fecaca;
    --ion-green: #059669;
    --ion-green-tint: #ecfdf5;
    --ion-green-border: #a7f3d0;
    --ion-warm-sand: #f5e5d8;
    --ion-cream-bg: #fbf7f4;
    --ion-surface: #ffffff;
    --ion-bg-soft: #f8fafc;
    --ion-text-main: #173a46;
    --ion-text-muted: #5e7279;
    --ion-text-subtle: #8a9ba1;
    --ion-border: #e8edf1;
    --ion-border-light: #f1f4f6;
    --ion-radius-sm: 8px;
    --ion-radius-md: 12px;
    --ion-radius-lg: 16px;
    --ion-radius-pill: 50px;
    --ion-font-main: 'Plus Jakarta Sans', 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    --ion-shadow-drawer: -18px 0 50px rgba(13, 34, 41, 0.24), -2px 0 10px rgba(13, 34, 41, 0.06);
    --ion-shadow-float: -6px 8px 24px rgba(23, 58, 70, 0.2);
    --ion-shadow-card: 0 4px 16px -2px rgba(23, 58, 70, 0.05);
}

/* --- Floating Right-Edge Cart Launcher Button --- */
.ion-floating-cart-btn {
    position: fixed;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
    z-index: 1045;
    background: #ffffff;
    border: 1px solid #d9e2e6;
    border-right: none;
    border-radius: 40px 0 0 40px;
    padding: 10px 14px 10px 12px;
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    box-shadow: var(--ion-shadow-float);
    transition: transform 0.28s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.25s ease, background 0.2s ease, border-color 0.2s ease;
    outline: none;
    font-family: var(--ion-font-main);
}
.ion-floating-cart-btn:hover {
    transform: translateY(-50%) translateX(-4px);
    background: #fbfdfe;
    border-color: #c4d2d8;
    box-shadow: -8px 10px 30px rgba(23, 58, 70, 0.26);
}
.ion-floating-inner {
    display: flex;
    align-items: center;
    gap: 8px;
}
.ion-floating-icon-wrap {
    position: relative;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.ion-floating-icon {
    font-size: 20px;
    color: var(--ion-dark);
    transition: transform 0.22s ease, color 0.22s ease;
}
.ion-floating-cart-btn:hover .ion-floating-icon {
    transform: scale(1.1);
    color: var(--ion-coral);
}
.ion-floating-badge {
    position: absolute;
    top: -5px;
    right: -8px;
    background: linear-gradient(135deg, var(--ion-coral) 0%, #a02219 100%);
    color: #ffffff;
    font-size: 11px;
    font-weight: 800;
    line-height: 1;
    min-width: 20px;
    height: 20px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 5px;
    box-shadow: 0 2px 8px rgba(200, 55, 45, 0.45);
    border: 2px solid #ffffff;
    font-family: var(--ion-font-main);
}
.ion-floating-label {
    font-size: 12.5px;
    font-weight: 700;
    color: var(--ion-dark);
    letter-spacing: 0.04em;
    text-transform: uppercase;
    display: none;
}
@media (min-width: 768px) {
    .ion-floating-label {
        display: inline-block;
    }
}
.ion-floating-cart-btn.sc-pulse-anim {
    animation: ionCartPulse 0.75s cubic-bezier(0.16, 1, 0.3, 1);
}
@keyframes ionCartPulse {
    0% { transform: translateY(-50%) scale(1); }
    35% { transform: translateY(-50%) scale(1.18); background: var(--ion-coral-tint); }
    100% { transform: translateY(-50%) scale(1); }
}

/* --- Backdrop Overlay --- */
.ion-cart-overlay {
    position: fixed;
    inset: 0;
    background: rgba(13, 34, 41, 0.58);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    z-index: 1055;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.35s ease, visibility 0.35s ease;
}
.ion-cart-overlay.sc-open {
    opacity: 1;
    visibility: visible;
}

/* --- Cart Drawer Panel --- */
.ion-cart-drawer {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    width: 480px;
    max-width: 100vw;
    height: 100vh;
    height: 100dvh;
    background: #ffffff;
    z-index: 1060;
    transform: translateX(100%);
    transition: transform 0.38s cubic-bezier(0.16, 1, 0.3, 1);
    box-shadow: var(--ion-shadow-drawer);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    font-family: var(--ion-font-main);
    color: var(--ion-text-main);
}
.ion-cart-drawer.sc-open {
    transform: translateX(0);
}
body.sc-locked {
    overflow: hidden !important;
}

/* --- 1. Drawer Header --- */
.ion-drawer-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px 24px;
    border-bottom: 1px solid var(--ion-border);
    background: #ffffff;
    flex-shrink: 0;
}
.ion-drawer-title-group {
    display: flex;
    align-items: center;
    gap: 12px;
}
.ion-header-icon-box {
    width: 42px;
    height: 42px;
    border-radius: var(--ion-radius-md);
    background: var(--ion-coral-tint);
    color: var(--ion-coral);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 19px;
    border: 1px solid var(--ion-coral-border);
    flex-shrink: 0;
}
.ion-drawer-heading {
    margin: 0;
    font-size: 19px;
    font-weight: 800;
    color: var(--ion-dark);
    display: flex;
    align-items: center;
    gap: 10px;
    letter-spacing: -0.3px;
    line-height: 1.2;
}
.ion-item-chip {
    font-size: 11.5px;
    font-weight: 700;
    background: #edf3f5;
    color: var(--ion-dark);
    padding: 3px 10px;
    border-radius: var(--ion-radius-pill);
    letter-spacing: 0.02em;
}
.ion-drawer-subheading {
    margin: 3px 0 0 0;
    font-size: 11.5px;
    color: var(--ion-text-muted);
    font-weight: 500;
    letter-spacing: 0.01em;
}
.ion-drawer-close {
    background: #f3f6f8;
    border: none;
    font-size: 17px;
    color: var(--ion-text-muted);
    width: 38px;
    height: 38px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.22s ease;
    outline: none;
    flex-shrink: 0;
}
.ion-drawer-close:hover {
    background: var(--ion-coral-tint);
    color: var(--ion-coral);
    transform: rotate(90deg);
}

/* --- 2. Free Shipping Strip --- */
.ion-shipping-strip {
    background: #fafcfd;
    padding: 12px 24px;
    border-bottom: 1px solid var(--ion-border-light);
    flex-shrink: 0;
}
.ion-shipping-status {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 12.5px;
    color: var(--ion-dark);
    margin-bottom: 8px;
}
.ion-shipping-msg {
    display: flex;
    align-items: center;
    gap: 7px;
}
.ion-ship-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
}
.ion-ship-icon.progress-icon {
    color: var(--ion-coral);
}
.ion-ship-icon.unlocked {
    color: var(--ion-green);
    font-size: 14px;
}
.ion-shipping-msg strong {
    font-weight: 800;
    color: var(--ion-dark-darker);
}
.ion-shipping-pct {
    font-size: 11px;
    font-weight: 700;
    color: var(--ion-text-muted);
    background: #edf2f5;
    padding: 1px 7px;
    border-radius: 10px;
}
.ion-shipping-meter {
    height: 6px;
    background: #e5ecef;
    border-radius: 6px;
    overflow: hidden;
    position: relative;
}
.ion-shipping-bar {
    height: 100%;
    background: linear-gradient(90deg, var(--ion-coral) 0%, #173a46 100%);
    border-radius: 6px;
    transition: width 0.45s cubic-bezier(0.16, 1, 0.3, 1);
    position: relative;
}
.ion-shipping-bar::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    background: linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.4) 50%, rgba(255,255,255,0) 100%);
    animation: ionShimmer 2.2s infinite;
}
@keyframes ionShimmer {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}

/* --- 3. Drawer Body (Scrollable Area) --- */
.ion-drawer-body {
    flex: 1;
    overflow-y: auto;
    padding: 18px 24px;
    background: #ffffff;
    scrollbar-width: thin;
    scrollbar-color: #d1dde2 #f8fafc;
}
.ion-drawer-body::-webkit-scrollbar {
    width: 5px;
}
.ion-drawer-body::-webkit-scrollbar-track {
    background: #f8fafc;
}
.ion-drawer-body::-webkit-scrollbar-thumb {
    background: #d1dde2;
    border-radius: 10px;
}
.ion-drawer-body::-webkit-scrollbar-thumb:hover {
    background: #b5c6cc;
}

/* --- Empty Cart State --- */
.ion-cart-empty {
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 60px 10px 40px;
    height: 100%;
}
.ion-empty-graphic {
    position: relative;
    width: 90px;
    height: 90px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 22px;
}
.ion-empty-circle-bg {
    position: absolute;
    inset: 0;
    border-radius: 50%;
    background: radial-gradient(circle, var(--ion-coral-tint) 0%, #fff5f5 100%);
    border: 1px dashed var(--ion-coral-border);
    animation: ionRotateSlow 16s linear infinite;
}
@keyframes ionRotateSlow {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
.ion-empty-icon-box {
    position: relative;
    font-size: 36px;
    color: var(--ion-coral);
}
.ion-empty-title {
    font-size: 20px;
    font-weight: 800;
    color: var(--ion-dark);
    margin-bottom: 8px;
    letter-spacing: -0.2px;
}
.ion-empty-desc {
    font-size: 13.5px;
    color: var(--ion-text-muted);
    max-width: 320px;
    line-height: 1.55;
    margin-bottom: 24px;
}
.ion-btn-explore {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    background: var(--ion-dark);
    color: #ffffff;
    border-radius: var(--ion-radius-pill);
    padding: 13px 28px;
    font-size: 13.5px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    text-decoration: none;
    box-shadow: 0 4px 16px rgba(23, 58, 70, 0.22);
    transition: all 0.25s ease;
}
.ion-btn-explore:hover {
    background: var(--ion-coral);
    color: #ffffff;
    transform: translateY(-2px);
    box-shadow: 0 8px 22px rgba(200, 55, 45, 0.32);
    text-decoration: none;
}
.ion-empty-pillars {
    margin-top: 40px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    width: 100%;
    max-width: 300px;
}
.ion-pillar-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 14px;
    background: var(--ion-bg-soft);
    border: 1px solid var(--ion-border-light);
    border-radius: var(--ion-radius-md);
    font-size: 12px;
    font-weight: 600;
    color: var(--ion-text-muted);
}
.ion-pillar-item i {
    color: var(--ion-coral);
    font-size: 13px;
}

/* --- Cart Items List & Cards --- */
.ion-items-list {
    display: flex;
    flex-direction: column;
    gap: 14px;
}
.ion-cart-card {
    display: flex;
    gap: 14px;
    padding: 14px;
    background: #ffffff;
    border: 1px solid var(--ion-border);
    border-radius: var(--ion-radius-md);
    box-shadow: var(--ion-shadow-card);
    transition: border-color 0.2s ease, box-shadow 0.2s ease, opacity 0.3s ease, transform 0.3s ease;
}
.ion-cart-card:hover {
    border-color: #cbd9df;
    box-shadow: 0 6px 20px -2px rgba(23, 58, 70, 0.08);
}
.ion-cart-card.sc-row-removing {
    opacity: 0;
    transform: translateX(-30px);
}

/* Thumbnail */
.ion-card-thumb-wrap {
    width: 82px;
    height: 82px;
    border-radius: var(--ion-radius-sm);
    background: #fafcfd;
    border: 1px solid var(--ion-border-light);
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    overflow: hidden;
    text-decoration: none;
}
.ion-card-thumb {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
    transition: transform 0.25s ease;
}
.ion-cart-card:hover .ion-card-thumb {
    transform: scale(1.08);
}
.ion-card-placeholder {
    font-size: 26px;
    color: #cbd5e1;
}

/* Card Details */
.ion-card-details {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.ion-card-header-row {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 8px;
    margin-bottom: 4px;
}
.ion-card-title {
    font-size: 14px;
    font-weight: 700;
    color: var(--ion-dark);
    line-height: 1.35;
    text-decoration: none;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    transition: color 0.18s ease;
}
.ion-card-title:hover {
    color: var(--ion-coral);
    text-decoration: none;
}
.ion-btn-remove {
    background: transparent;
    border: none;
    color: #94a3b8;
    font-size: 15px;
    width: 28px;
    height: 28px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.2s ease;
    flex-shrink: 0;
    padding: 0;
}
.ion-btn-remove:hover {
    color: var(--ion-coral);
    background: var(--ion-coral-tint);
    transform: scale(1.12);
}

.ion-card-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    margin-bottom: 10px;
    font-size: 12px;
}
.ion-card-brand-badge {
    color: var(--ion-text-muted);
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 11px;
}
.ion-card-brand-badge i {
    color: var(--ion-green);
    font-size: 10px;
}
.ion-card-unit-price {
    font-size: 12px;
    color: var(--ion-text-muted);
    font-weight: 600;
}

/* Stepper and Line Price */
.ion-card-action-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding-top: 8px;
    border-top: 1px dashed var(--ion-border-light);
}
.ion-qty-stepper {
    display: inline-flex;
    align-items: center;
    background: #f8fafc;
    border: 1px solid #d7e0e5;
    border-radius: 6px;
    height: 32px;
    padding: 0 2px;
}
.ion-stepper-btn {
    width: 26px;
    height: 100%;
    background: transparent;
    border: none;
    color: var(--ion-dark);
    font-size: 11px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.15s ease;
    border-radius: 4px;
}
.ion-stepper-btn:hover {
    background: #e8eef2;
    color: var(--ion-coral);
}
.ion-stepper-input {
    width: 32px;
    height: 100%;
    border: none;
    text-align: center;
    font-size: 13px;
    font-weight: 800;
    color: var(--ion-dark);
    background: transparent;
    outline: none;
    -moz-appearance: textfield;
}
.ion-stepper-input::-webkit-outer-spin-button,
.ion-stepper-input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}
.ion-card-price-wrap {
    text-align: right;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
}
.ion-card-price-label {
    font-size: 10px;
    text-transform: uppercase;
    color: var(--ion-text-subtle);
    font-weight: 700;
    letter-spacing: 0.05em;
    line-height: 1;
}
.ion-card-line-price {
    font-size: 15px;
    font-weight: 800;
    color: var(--ion-dark);
    letter-spacing: -0.2px;
}

/* Trust Pills Bar */
.ion-trust-pills-bar {
    display: flex;
    gap: 8px;
    margin-top: 18px;
    flex-wrap: wrap;
}
.ion-trust-pill {
    flex: 1 1 calc(50% - 4px);
    display: flex;
    align-items: center;
    gap: 6px;
    background: var(--ion-bg-soft);
    border: 1px solid var(--ion-border);
    padding: 8px 10px;
    border-radius: var(--ion-radius-sm);
    font-size: 11px;
    font-weight: 600;
    color: var(--ion-text-muted);
}
.ion-trust-pill i {
    color: var(--ion-coral);
    font-size: 12px;
}

/* --- 4. Drawer Footer (Sticky Area) --- */
.ion-drawer-footer {
    background: #fcfdfd;
    border-top: 1px solid var(--ion-border);
    padding: 16px 24px 20px;
    box-shadow: 0 -8px 24px rgba(23, 58, 70, 0.04);
    flex-shrink: 0;
}

/* Collapsible Coupon Code Accordion */
.ion-coupon-accordion {
    margin-bottom: 12px;
    background: #ffffff;
    border: 1px solid var(--ion-border);
    border-radius: var(--ion-radius-sm);
    overflow: hidden;
}
.ion-coupon-toggle {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 14px;
    background: #ffffff;
    border: none;
    font-size: 12.5px;
    font-weight: 700;
    color: var(--ion-dark);
    cursor: pointer;
    text-align: left;
    outline: none;
    transition: background 0.15s ease;
}
.ion-coupon-toggle:hover {
    background: #f8fafc;
}
.ion-coupon-toggle-text {
    display: flex;
    align-items: center;
    gap: 8px;
}
.ion-coupon-icon {
    color: var(--ion-coral);
    font-size: 13px;
}
.ion-coupon-chevron {
    font-size: 11px;
    color: var(--ion-text-muted);
    transition: transform 0.25s ease;
}
.ion-coupon-chevron.open {
    transform: rotate(180deg);
}
.ion-coupon-collapse {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s cubic-bezier(0.16, 1, 0.3, 1), padding 0.3s ease;
    padding: 0 14px;
}
.ion-coupon-collapse.open {
    max-height: 120px;
    padding: 0 14px 12px;
}
.ion-coupon-input-wrap {
    display: flex;
    gap: 6px;
    align-items: center;
}
.ion-coupon-input {
    flex: 1;
    height: 36px;
    border: 1px solid #d5dbe1;
    border-radius: 6px;
    padding: 0 12px;
    font-size: 12.5px;
    color: var(--ion-dark);
    background: #ffffff;
    outline: none;
    text-transform: uppercase;
    font-weight: 600;
    letter-spacing: 0.05em;
    transition: all 0.2s ease;
}
.ion-coupon-input:focus {
    border-color: var(--ion-dark);
    box-shadow: 0 0 0 2px rgba(23, 58, 70, 0.1);
}
.ion-coupon-btn {
    height: 36px;
    background: var(--ion-dark);
    color: #ffffff;
    border: none;
    border-radius: 6px;
    padding: 0 16px;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    cursor: pointer;
    transition: background 0.2s ease;
    white-space: nowrap;
}
.ion-coupon-btn:hover {
    background: var(--ion-coral);
}
.ion-coupon-feedback {
    font-size: 11.5px;
    margin-top: 6px;
    font-weight: 600;
    display: none;
}
.ion-coupon-feedback.sc-success {
    color: var(--ion-green);
    display: block;
}
.ion-coupon-feedback.sc-error {
    color: #dc2626;
    display: block;
}

/* Bill Summary Box */
.ion-summary-box {
    margin-bottom: 14px;
}
.ion-summary-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
    color: var(--ion-text-muted);
    margin-bottom: 6px;
}
.ion-sum-label {
    font-weight: 500;
}
.ion-sum-val {
    font-weight: 700;
    color: var(--ion-dark);
}
.ion-discount-val {
    color: var(--ion-green);
}
.ion-free-ship-tag {
    color: var(--ion-green);
    font-weight: 800;
    background: var(--ion-green-tint);
    padding: 1px 6px;
    border-radius: 4px;
    font-size: 11.5px;
}
.ion-summary-row.ion-total-row {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid var(--ion-border);
    margin-bottom: 0;
    align-items: flex-start;
}
.ion-total-label {
    font-size: 15px;
    font-weight: 800;
    color: var(--ion-dark);
    letter-spacing: -0.2px;
}
.ion-total-note {
    font-size: 11px;
    color: var(--ion-text-subtle);
    margin-top: 2px;
}
.ion-total-val {
    font-size: 20px;
    font-weight: 800;
    color: var(--ion-coral);
    letter-spacing: -0.4px;
}

/* Checkout CTA Button */
.ion-checkout-action-wrap {
    margin-top: 4px;
}
.ion-btn-checkout {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    height: 50px;
    background: linear-gradient(135deg, var(--ion-coral) 0%, #b32a21 100%);
    color: #ffffff;
    text-decoration: none;
    font-size: 13px;
    font-weight: 800;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    border-radius: var(--ion-radius-pill);
    padding: 0 20px;
    border: none;
    cursor: pointer;
    box-shadow: 0 8px 24px rgba(200, 55, 45, 0.32);
    position: relative;
    overflow: hidden;
    transition: all 0.28s ease;
}
.ion-btn-checkout::before {
    content: "";
    position: absolute;
    top: 0;
    left: -100%;
    width: 60%;
    height: 100%;
    background: linear-gradient(120deg, transparent, rgba(255, 255, 255, 0.32) 50%, transparent);
    transform: skewX(-25deg);
    transition: left 0.7s ease;
    pointer-events: none;
}
.ion-btn-checkout:hover::before {
    left: 140%;
}
.ion-btn-checkout:hover {
    background: linear-gradient(135deg, #b83026 0%, #9e231b 100%);
    color: #ffffff;
    transform: translateY(-2px);
    box-shadow: 0 10px 28px rgba(200, 55, 45, 0.42);
    text-decoration: none;
}
.ion-checkout-btn-text {
    display: flex;
    align-items: center;
    gap: 8px;
}
.ion-btn-lock {
    font-size: 12px;
    opacity: 0.9;
}
.ion-checkout-btn-amount {
    display: flex;
    align-items: center;
    font-weight: 800;
    font-size: 14px;
    background: rgba(0, 0, 0, 0.16);
    padding: 5px 12px;
    border-radius: var(--ion-radius-pill);
    letter-spacing: -0.2px;
}

/* Secondary full cart link */
.ion-view-cart-wrap {
    text-align: center;
    margin-top: 10px;
}
.ion-link-view-cart {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 12px;
    font-weight: 600;
    color: var(--ion-text-muted);
    text-decoration: none;
    transition: color 0.18s ease;
}
.ion-link-view-cart:hover {
    color: var(--ion-dark);
    text-decoration: underline;
}

/* Trust footer */
.ion-drawer-trust-footer {
    margin-top: 10px;
    text-align: center;
}
.ion-trust-secure-note {
    font-size: 11px;
    color: var(--ion-text-subtle);
    display: inline-flex;
    align-items: center;
    gap: 6px;
}
.ion-trust-secure-note i {
    color: var(--ion-green);
    font-size: 12px;
}

/* --- Mobile Breakpoint Adjustments --- */
@media (max-width: 540px) {
    .ion-cart-drawer {
        width: 100vw;
        max-width: 100vw;
    }
    .ion-drawer-header {
        padding: 16px 18px;
    }
    .ion-shipping-strip {
        padding: 10px 18px;
    }
    .ion-drawer-body {
        padding: 14px 18px;
    }
    .ion-drawer-footer {
        padding: 14px 18px 18px;
    }
    .ion-cart-card {
        padding: 12px;
        gap: 12px;
    }
    .ion-card-thumb-wrap {
        width: 70px;
        height: 70px;
    }
    .ion-btn-checkout {
        height: 48px;
        padding: 0 16px;
        font-size: 12px;
    }
    .ion-checkout-btn-amount {
        font-size: 13px;
        padding: 4px 10px;
    }
}
</style>

<!-- ============================================================
     PREMIUM REAL-TIME JAVASCRIPT CONTROLLER FOR CART DRAWER
     ============================================================ -->
<script>
(function() {
    'use strict';

    // DOM Elements
    const drawerPanel = document.getElementById('scDrawerPanel');
    const drawerOverlay = document.getElementById('scDrawerOverlay');
    const closeBtn = document.getElementById('scDrawerClose');
    const continueBtn = document.getElementById('scContinueShoppingBtn');
    const floatingBtn = document.getElementById('floatingCartBtn');
    const emptyState = document.getElementById('scEmptyState');
    const cartContent = document.getElementById('scCartContent');
    const drawerFooter = document.getElementById('scDrawerFooter');
    const itemsContainer = document.getElementById('scItemsContainer');
    const headerItemBadge = document.getElementById('scHeaderItemBadge');
    const sumSubtotal = document.getElementById('scSumSubtotal');
    const sumDiscount = document.getElementById('scSumDiscount');
    const discountRow = document.getElementById('scDiscountRow');
    const sumGst = document.getElementById('scSumGst');
    const sumShipping = document.getElementById('scSumShipping');
    const sumTotal = document.getElementById('scSumTotal');
    const checkoutBtnPrice = document.getElementById('scCheckoutBtnPrice');
    const couponInput = document.getElementById('scCouponCode');
    const couponBtn = document.getElementById('scApplyCouponBtn');
    const couponFeedback = document.getElementById('scCouponFeedback');
    const couponToggle = document.getElementById('scCouponToggle');
    const couponCollapse = document.getElementById('scCouponCollapse');
    const couponChevron = document.getElementById('scCouponChevron');
    const shippingProgressFill = document.getElementById('scShippingProgressFill');
    const shippingNoticeWrap = document.getElementById('scShippingNoticeWrap');
    const shippingNoticeText = document.getElementById('scShippingNoticeText');
    const shippingPct = document.getElementById('scShippingPct');

    const csrfToken = '<?php echo e(csrf_token()); ?>';
    const baseUrl = '<?php echo e(url("/")); ?>';
    const freeShippingThreshold = 2000;

    // Open Cart Drawer
    function openCartDrawer() {
        if (!drawerPanel || !drawerOverlay) return;
        drawerPanel.classList.add('sc-open');
        drawerOverlay.classList.add('sc-open');
        drawerPanel.setAttribute('aria-hidden', 'false');
        drawerOverlay.setAttribute('aria-hidden', 'false');
        document.body.classList.add('sc-locked');
    }

    // Close Cart Drawer
    function closeCartDrawer() {
        if (!drawerPanel || !drawerOverlay) return;
        drawerPanel.classList.remove('sc-open');
        drawerOverlay.classList.remove('sc-open');
        drawerPanel.setAttribute('aria-hidden', 'true');
        drawerOverlay.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('sc-locked');
    }

    // Expose globally
    window.openCartDrawer = openCartDrawer;
    window.closeCartDrawer = closeCartDrawer;

    // Pulse Floating Cart Button
    window.pulseFloatingCart = function() {
        if (!floatingBtn) return;
        floatingBtn.classList.remove('sc-pulse-anim');
        void floatingBtn.offsetWidth;
        floatingBtn.classList.add('sc-pulse-anim');
        setTimeout(() => floatingBtn.classList.remove('sc-pulse-anim'), 800);
    };

    // Update Badges Across Entire Site
    window.updateCartBadge = function(count) {
        count = parseInt(count, 10) || 0;
        document.querySelectorAll('.cart-count-badge, #floatingCartBadge, #headerCartCount, #cartCount, #mobileCartCount').forEach(badge => {
            badge.textContent = count;
            badge.style.display = count > 0 ? 'flex' : 'none';
        });
        if (headerItemBadge) {
            headerItemBadge.textContent = count + (count === 1 ? ' item' : ' items');
        }
        if (floatingBtn) {
            const b = floatingBtn.querySelector('.cart-count-badge');
            if (b) b.style.display = count > 0 ? 'flex' : 'none';
        }
    };

    // Currency Formatter
    function formatInr(val) {
        val = parseFloat(val) || 0;
        return '₹ ' + val.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    // Free Shipping Progress Update
    function updateShippingNotice(subtotal) {
        subtotal = parseFloat(subtotal) || 0;
        const progress = Math.min(100, subtotal > 0 ? (subtotal / freeShippingThreshold) * 100 : 0);
        if (shippingProgressFill) {
            shippingProgressFill.style.width = progress + '%';
        }
        if (shippingPct) {
            shippingPct.textContent = Math.round(progress) + '%';
        }
        if (shippingNoticeText) {
            if (subtotal >= freeShippingThreshold) {
                shippingNoticeText.innerHTML = '<span class="ion-ship-icon unlocked"><i class="fa-solid fa-circle-check"></i></span> <span>You\'ve unlocked <strong>FREE Express Insured Shipping</strong>!</span>';
            } else {
                const diff = (freeShippingThreshold - subtotal).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                shippingNoticeText.innerHTML = '<span class="ion-ship-icon progress-icon"><i class="fa-solid fa-truck-fast"></i></span> <span>Add <strong>₹' + diff + '</strong> more for <strong>FREE Shipping</strong></span>';
            }
        }
        if (sumShipping) {
            if (subtotal >= freeShippingThreshold) {
                sumShipping.innerHTML = '<span class="ion-free-ship-tag"><i class="fa-solid fa-bolt me-1"></i> FREE</span>';
            } else {
                sumShipping.textContent = '₹ 100.00';
            }
        }
    }

    // Render Items From Server JSON
    function renderCartItems(data) {
        const count = data.count || 0;
        window.updateCartBadge(count);

        const grandTotal = data.grandTotal !== undefined ? data.grandTotal : (data.grand_total !== undefined ? data.grand_total : 0);

        if (count === 0 || !data.items || data.items.length === 0) {
            if (emptyState) emptyState.style.display = 'flex';
            if (cartContent) cartContent.style.display = 'none';
            if (drawerFooter) drawerFooter.style.display = 'none';
            if (itemsContainer) itemsContainer.innerHTML = '';
            updateShippingNotice(0);
            return;
        }

        if (emptyState) emptyState.style.display = 'none';
        if (cartContent) cartContent.style.display = 'block';
        if (drawerFooter) drawerFooter.style.display = 'block';

        if (sumSubtotal) sumSubtotal.textContent = formatInr(data.subtotal);
        if (sumGst) sumGst.textContent = formatInr(data.tax);
        if (sumTotal) sumTotal.textContent = formatInr(grandTotal);
        if (checkoutBtnPrice) checkoutBtnPrice.textContent = formatInr(grandTotal);

        if (data.discount && data.discount > 0) {
            if (sumDiscount) sumDiscount.textContent = '- ' + formatInr(data.discount);
            if (discountRow) discountRow.style.display = 'flex';
        } else {
            if (discountRow) discountRow.style.display = 'none';
        }

        updateShippingNotice(data.subtotal);

        if (!itemsContainer) return;
        let html = '';
        data.items.forEach(item => {
            const thumbHtml = item.thumbnail
                ? `<img src="${item.thumbnail}" alt="${item.name}" class="ion-card-thumb" loading="lazy">`
                : `<div class="ion-card-placeholder"><i class="fa-solid fa-droplet"></i></div>`;

            html += `
            <div class="ion-cart-card" data-id="${item.id}">
                <a href="${item.url}" class="ion-card-thumb-wrap" title="${item.name}">
                    ${thumbHtml}
                </a>
                <div class="ion-card-details">
                    <div class="ion-card-header-row">
                        <a href="${item.url}" class="ion-card-title" title="${item.name}">
                            ${item.name}
                        </a>
                        <button type="button" class="ion-btn-remove sc-btn-trash" data-id="${item.id}" aria-label="Remove item" title="Remove item">
                            <i class="fa-regular fa-trash-can"></i>
                        </button>
                    </div>
                    <div class="ion-card-meta">
                        <span class="ion-card-brand-badge">
                            <i class="fa-solid fa-circle-check"></i> Ionia Korea
                        </span>
                        <span class="ion-card-unit-price">
                            ${formatInr(item.price)}
                        </span>
                    </div>
                    <div class="ion-card-action-row">
                        <div class="ion-qty-stepper sc-qty-wrapper">
                            <button type="button" class="ion-stepper-btn ion-stepper-minus sc-qty-btn sc-qty-minus" aria-label="Decrease quantity">
                                <i class="fa-solid fa-minus"></i>
                            </button>
                            <input type="number" min="1" max="99" value="${item.quantity}" class="ion-stepper-input sc-qty-input" data-id="${item.id}" aria-label="Quantity" readonly>
                            <button type="button" class="ion-stepper-btn ion-stepper-plus sc-qty-btn sc-qty-plus" aria-label="Increase quantity">
                                <i class="fa-solid fa-plus"></i>
                            </button>
                        </div>
                        <div class="ion-card-price-wrap">
                            <span class="ion-card-price-label">Total</span>
                            <span class="ion-card-line-price sc-price-val">${formatInr(item.price * item.quantity)}</span>
                        </div>
                    </div>
                </div>
            </div>`;
        });
        itemsContainer.innerHTML = html;
    }

    // Refresh Cart Data from Server
    window.refreshCartDrawer = function(andOpen = false) {
        fetch(baseUrl + '/api/cart/data', {
            headers: { 'Accept': 'application/json' }
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                renderCartItems(data);
                if (andOpen) openCartDrawer();
            }
        })
        .catch(() => {});
    };

    // Update Quantity via AJAX with Debounce
    let qtyDebounceTimer = null;
    function handleQtyUpdate(id, newQty, inputEl) {
        newQty = parseInt(newQty, 10);
        if (isNaN(newQty) || newQty < 1) newQty = 1;
        if (inputEl) inputEl.value = newQty;

        clearTimeout(qtyDebounceTimer);
        qtyDebounceTimer = setTimeout(() => {
            fetch(baseUrl + '/api/cart/update', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
                body: JSON.stringify({ id: id, quantity: newQty })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    const grandTotal = data.grandTotal !== undefined ? data.grandTotal : data.grand_total;
                    if (sumSubtotal) sumSubtotal.textContent = formatInr(data.subtotal);
                    if (sumGst) sumGst.textContent = formatInr(data.tax);
                    if (sumTotal) sumTotal.textContent = formatInr(grandTotal);
                    if (checkoutBtnPrice) checkoutBtnPrice.textContent = formatInr(grandTotal);

                    if (data.discount && data.discount > 0) {
                        if (sumDiscount) sumDiscount.textContent = '- ' + formatInr(data.discount);
                        if (discountRow) discountRow.style.display = 'flex';
                    } else if (discountRow) {
                        discountRow.style.display = 'none';
                    }

                    updateShippingNotice(data.subtotal);
                    window.updateCartBadge(data.count);
                    window.pulseFloatingCart();

                    // Update row price
                    if (inputEl) {
                        const card = inputEl.closest('.ion-cart-card');
                        if (card && data.lineTotal) {
                            const pEl = card.querySelector('.ion-card-line-price');
                            if (pEl) pEl.textContent = formatInr(data.lineTotal);
                        }
                    }
                }
            })
            .catch(() => {});
        }, 300);
    }

    // Remove Item via AJAX
    function handleRemoveItem(id, cardEl) {
        if (!confirm('Remove this item from your shopping bag?')) return;

        if (cardEl) {
            cardEl.classList.add('sc-row-removing');
        }

        fetch(baseUrl + '/api/cart/remove', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken
            },
            body: JSON.stringify({ id: id })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                setTimeout(() => {
                    if (cardEl) cardEl.remove();
                    const remaining = itemsContainer ? itemsContainer.querySelectorAll('.ion-cart-card') : [];
                    if (remaining.length === 0 || data.count === 0) {
                        if (emptyState) emptyState.style.display = 'flex';
                        if (cartContent) cartContent.style.display = 'none';
                        if (drawerFooter) drawerFooter.style.display = 'none';
                    }
                }, 280);

                const grandTotal = data.grandTotal !== undefined ? data.grandTotal : data.grand_total;
                if (sumSubtotal) sumSubtotal.textContent = formatInr(data.subtotal);
                if (sumGst) sumGst.textContent = formatInr(data.tax);
                if (sumTotal) sumTotal.textContent = formatInr(grandTotal);
                if (checkoutBtnPrice) checkoutBtnPrice.textContent = formatInr(grandTotal);

                if (data.discount && data.discount > 0) {
                    if (sumDiscount) sumDiscount.textContent = '- ' + formatInr(data.discount);
                    if (discountRow) discountRow.style.display = 'flex';
                } else if (discountRow) {
                    discountRow.style.display = 'none';
                }

                updateShippingNotice(data.subtotal);
                window.updateCartBadge(data.count);

                if (typeof window.zToast === 'function') {
                    window.zToast('Item removed from bag', 'info');
                }
            } else if (cardEl) {
                cardEl.classList.remove('sc-row-removing');
            }
        })
        .catch(() => {
            if (cardEl) cardEl.classList.remove('sc-row-removing');
        });
    }

    // Apply Coupon via AJAX
    function handleApplyCoupon() {
        if (!couponInput) return;
        const code = couponInput.value.trim();
        if (!code) {
            if (couponFeedback) {
                couponFeedback.textContent = 'Please enter a coupon code.';
                couponFeedback.className = 'ion-coupon-feedback sc-error';
            }
            return;
        }

        if (couponBtn) {
            couponBtn.disabled = true;
            couponBtn.textContent = '...';
        }

        fetch(baseUrl + '/api/cart/coupon', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken
            },
            body: JSON.stringify({ code: code })
        })
        .then(res => res.json())
        .then(data => {
            if (couponBtn) {
                couponBtn.disabled = false;
                couponBtn.textContent = 'Apply';
            }
            if (data.success) {
                const grandTotal = data.grandTotal !== undefined ? data.grandTotal : data.grand_total;
                if (sumDiscount) sumDiscount.textContent = '- ' + formatInr(data.discount);
                if (discountRow) discountRow.style.display = 'flex';
                if (sumTotal) sumTotal.textContent = formatInr(grandTotal);
                if (checkoutBtnPrice) checkoutBtnPrice.textContent = formatInr(grandTotal);

                if (couponFeedback) {
                    couponFeedback.textContent = 'Promo code applied successfully!';
                    couponFeedback.className = 'ion-coupon-feedback sc-success';
                }
                if (typeof window.zToast === 'function') {
                    window.zToast('Promo code applied!', 'success');
                }
            } else {
                if (couponFeedback) {
                    couponFeedback.textContent = data.message || 'Invalid coupon code.';
                    couponFeedback.className = 'ion-coupon-feedback sc-error';
                }
            }
        })
        .catch(() => {
            if (couponBtn) {
                couponBtn.disabled = false;
                couponBtn.textContent = 'Apply';
            }
            if (couponFeedback) {
                couponFeedback.textContent = 'Could not apply coupon.';
                couponFeedback.className = 'ion-coupon-feedback sc-error';
            }
        });
    }

    // Event Delegations inside Drawer Body
    if (itemsContainer) {
        // Quantity +/- Stepper buttons
        itemsContainer.addEventListener('click', function(e) {
            const minusBtn = e.target.closest('.sc-qty-minus');
            const plusBtn = e.target.closest('.sc-qty-plus');
            if (minusBtn || plusBtn) {
                e.preventDefault();
                const wrap = (minusBtn || plusBtn).closest('.sc-qty-wrapper');
                const input = wrap ? wrap.querySelector('.sc-qty-input') : null;
                if (input) {
                    let cur = parseInt(input.value, 10) || 1;
                    if (minusBtn && cur > 1) cur--;
                    if (plusBtn && cur < 99) cur++;
                    input.value = cur;
                    const id = input.getAttribute('data-id');
                    handleQtyUpdate(id, cur, input);
                }
            }
        });

        // Trash button click
        itemsContainer.addEventListener('click', function(e) {
            const trashBtn = e.target.closest('.sc-btn-trash');
            if (trashBtn) {
                e.preventDefault();
                const id = trashBtn.getAttribute('data-id');
                const card = trashBtn.closest('.ion-cart-card');
                handleRemoveItem(id, card);
            }
        });
    }

    // Coupon Collapsible Accordion Toggle
    if (couponToggle && couponCollapse) {
        couponToggle.addEventListener('click', function() {
            const isOpen = couponCollapse.classList.contains('open');
            couponCollapse.classList.toggle('open', !isOpen);
            if (couponChevron) couponChevron.classList.toggle('open', !isOpen);
            couponToggle.setAttribute('aria-expanded', !isOpen ? 'true' : 'false');
            if (!isOpen && couponInput) {
                setTimeout(() => couponInput.focus(), 200);
            }
        });
    }

    // Coupon Button & Enter key
    if (couponBtn) {
        couponBtn.addEventListener('click', function(e) {
            e.preventDefault();
            handleApplyCoupon();
        });
    }
    if (couponInput) {
        couponInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                handleApplyCoupon();
            }
        });
    }

    // Floating Button Click
    if (floatingBtn) {
        floatingBtn.addEventListener('click', function(e) {
            e.preventDefault();
            openCartDrawer();
        });
    }

    // Header cart button clicks open this drawer
    document.querySelectorAll('.ow-cart-btn, #headerCartCount').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            openCartDrawer();
        });
    });

    if (closeBtn) closeBtn.addEventListener('click', closeCartDrawer);
    if (drawerOverlay) drawerOverlay.addEventListener('click', closeCartDrawer);
    if (continueBtn) continueBtn.addEventListener('click', closeCartDrawer);

    // ESC key to close
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && drawerPanel && drawerPanel.classList.contains('sc-open')) {
            closeCartDrawer();
        }
    });

})();
</script>
<?php /**PATH /var/www/html/store/resources/views/partials/cart-drawer.blade.php ENDPATH**/ ?>