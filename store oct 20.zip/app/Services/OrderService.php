<?php

namespace App\Services;

use App\Models\Coupon;
use App\Models\CouponUsage;
use App\Models\Invoice;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderStatusHistory;
use App\Models\Payment;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class OrderService
{
    public function __construct(private CartService $cart) {}

    public function placeOrder(User $user, array $data): Order
    {
        return DB::transaction(function () use ($user, $data) {
            $totals = $this->cart->totals();
            $cart = $this->cart->getCart(false);

            if (!$cart || $cart->items->isEmpty()) {
                throw new \RuntimeException('Cart is empty.');
            }

            $order = Order::create([
                'order_number' => Order::generateNumber(),
                'user_id' => $user->id,
                'status' => 'pending',
                'payment_status' => ($data['payment_method'] ?? 'cod') === 'cod' ? 'cod_pending' : 'pending',
                'payment_method' => $data['payment_method'] ?? 'cod',
                'shipping_method' => $data['shipping_method'] ?? 'standard',
                'subtotal' => $totals['subtotal'],
                'discount' => $totals['discount'],
                'tax' => $totals['tax'],
                'shipping_cost' => $totals['shipping'],
                'grand_total' => $totals['grand_total'],
                'customer_name' => $data['name'] ?? $user->name,
                'customer_email' => $data['email'] ?? $user->email,
                'customer_phone' => $data['phone'] ?? $user->phone,
                'shipping_address' => $data['shipping_address'] ?? [],
                'billing_address' => $data['billing_address'] ?? [],
                'customer_note' => $data['note'] ?? null,
                'coupon_code' => $cart->coupon_code,
            ]);

            foreach ($cart->items as $ci) {
                $product = $ci->product;
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $product->id,
                    'variant_id' => $ci->variant_id,
                    'product_name' => $product->name,
                    'sku' => $product->sku,
                    'quantity' => $ci->quantity,
                    'price' => $ci->price,
                    'total' => $ci->price * $ci->quantity,
                ]);

                if ($product->manage_stock) {
                    $product->decrement('stock', $ci->quantity);
                    $product->increment('sold_count', $ci->quantity);
                }
            }

            if ($cart->coupon_code && ($coupon = Coupon::where('code', $cart->coupon_code)->first())) {
                $coupon->increment('used_count');
                CouponUsage::create([
                    'coupon_id' => $coupon->id,
                    'user_id' => $user->id,
                    'order_id' => $order->id,
                    'discount_amount' => $totals['discount'],
                ]);
            }

            OrderStatusHistory::create([
                'order_id' => $order->id,
                'status' => 'pending',
                'note' => 'Order placed',
                'changed_by' => $user->id,
                'changed_by_type' => 'customer',
            ]);

            Invoice::create([
                'invoice_number' => 'INV-'.strtoupper(now()->format('ymd')).'-'.str_pad((string) $order->id, 5, '0', STR_PAD_LEFT),
                'order_id' => $order->id,
                'user_id' => $user->id,
                'subtotal' => $totals['subtotal'],
                'discount' => $totals['discount'],
                'tax' => $totals['tax'],
                'shipping' => $totals['shipping'],
                'total' => $totals['grand_total'],
                'issued_at' => now(),
            ]);

            Payment::create([
                'order_id' => $order->id,
                'user_id' => $user->id,
                'gateway' => $data['payment_method'] ?? 'cod',
                'amount' => $totals['grand_total'],
                'status' => 'pending',
            ]);

            // Update customer profile stats
            if ($user->customerProfile) {
                $user->customerProfile->increment('total_orders');
                $user->customerProfile->increment('total_spent', $order->grand_total);
            }

            $this->cart->clear();

            return $order;
        });
    }

    public function updateStatus(Order $order, string $status, ?string $note = null, ?User $by = null): void
    {
        DB::transaction(function () use ($order, $status, $note, $by) {
            $order->update([
                'status' => $status,
                'shipped_at' => $status === 'shipped' ? now() : $order->shipped_at,
                'delivered_at' => $status === 'delivered' ? now() : $order->delivered_at,
                'cancelled_at' => $status === 'cancelled' ? now() : $order->cancelled_at,
            ]);

            OrderStatusHistory::create([
                'order_id' => $order->id,
                'status' => $status,
                'note' => $note,
                'changed_by' => $by?->id,
                'changed_by_type' => $by ? ($by->isAgent() ? 'agent' : 'admin') : 'system',
            ]);

            if ($status === 'delivered' && $order->payment_method === 'cod') {
                $order->update(['payment_status' => 'paid', 'paid_amount' => $order->grand_total]);
                $order->payments()->latest()->first()?->update(['status' => 'success', 'paid_at' => now()]);
            }
        });
    }
}
