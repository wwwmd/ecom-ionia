<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;

class HomeController extends Controller
{
    public function index()
    {
        $banners = Banner::where('status', 'active')
            ->where('position', 'hero')
            ->orderBy('sort_order')
            ->get();

        $categories = Category::active()
            ->whereNull('parent_id')
            ->where('is_featured', true)
            ->take(6)
            ->get();

        $brands = Brand::where('status', 'active')
            ->where('is_featured', true)
            ->take(6)
            ->get();

        $featuredProducts = Product::active()
            ->featured()
            ->with(['brand', 'category'])
            ->take(8)
            ->get();

        return view('home.index', compact('banners', 'categories', 'brands', 'featuredProducts'));
    }

     public function products()
    {

        return view('home.product');
    }
       public function producDetail()
    {

        return view('home.product-details');
    }
        public function about()
    {

        return view('home.about-us');
    }
        public function contact()
    {

        return view('home.contact-us');
    }

        public function checkout()
    {

        return view('home.checkout');
    }

}
