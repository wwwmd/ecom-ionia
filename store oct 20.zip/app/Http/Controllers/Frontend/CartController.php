<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Services\CartService;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function __construct(private CartService $cart) {}

    public function index()
    {
        $totals = $this->cart->totals();

        return view('cart.index', [
            'cartItems' => $totals['items'],
            'subtotal' => $totals['subtotal'],
            'discount' => $totals['discount'],
            'tax' => $totals['tax'],
            'shipping' => $totals['shipping'],
            'grandTotal' => $totals['grand_total'],
        ]);
    }

    public function add(Request $request)
    {
        $data = $request->validate([
            'product_id' => ['required', 'exists:products,id'],
            'quantity' => ['required', 'integer', 'min:1'],
            'variant_id' => ['nullable', 'exists:product_variants,id'],
        ]);

        $product = Product::active()->findOrFail($data['product_id']);

        if ($product->manage_stock && $product->stock < $data['quantity']) {
            return response()->json(['success' => false, 'message' => 'Out of stock'], 422);
        }

        $this->cart->add($product, $data['quantity'], $data['variant_id'] ?? null);
        $totals = $this->cart->totals();

        return response()->json([
            'success' => true,
            'message' => 'Added to cart',
            'count' => $totals['count'],
            'total' => (int) $totals['grand_total'],
        ]);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'id' => 'required|integer',
            'quantity' => 'required|integer|min:1',
        ]);

        $item = $this->cart->updateItem($data['id'], $data['quantity']);
        if (!$item) return response()->json(['success' => false], 404);

        $totals = $this->cart->totals();

        return response()->json([
            'success' => true,
            'lineTotal' => (int) ($item->price * $item->quantity),
            'subtotal' => (int) $totals['subtotal'],
            'grandTotal' => (int) $totals['grand_total'],
        ]);
    }

    public function remove(Request $request)
    {
        $data = $request->validate(['id' => 'required|integer']);
        $this->cart->removeItem($data['id']);
        $totals = $this->cart->totals();

        return response()->json([
            'success' => true,
            'subtotal' => (int) $totals['subtotal'],
            'grandTotal' => (int) $totals['grand_total'],
            'count' => $totals['count'],
        ]);
    }

    public function count()
    {
        $totals = $this->cart->totals();
        return response()->json([
            'count' => $totals['count'],
            'total' => (int) $totals['grand_total'],
        ]);
    }

    public function applyCoupon(Request $request)
    {
        $data = $request->validate(['code' => 'required|string|max:60']);
        $result = $this->cart->applyCoupon($data['code']);

        if (!$result['success']) {
            return response()->json($result, 422);
        }

        $totals = $this->cart->totals();

        return response()->json([
            'success' => true,
            'discount' => (int) $result['discount'],
            'grandTotal' => (int) $totals['grand_total'],
        ]);
    }
}
