<?php $__env->startSection('title', 'Create Account — Zambit Store'); ?>

<?php $__env->startSection('content'); ?>
<section class="z-auth-page">
    <div class="z-auth-bg"></div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="z-auth-card" style="padding:40px">

                    <div class="text-center mb-4">
                        <span style="font-size:32px;font-weight:800;background:linear-gradient(135deg,#2E6DB4,#26A69A);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">
                            Zambit
                        </span>
                        <h3 class="mt-3">Create Your Account</h3>
                        <p class="text-muted">Join thousands of happy customers</p>
                    </div>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0 ps-3">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($err); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(url('/register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="z-field">
                            <label>Full Name</label>
                            <div class="z-input-wrap">
                                <i class="bi bi-person"></i>
                                <input type="text" name="name" value="<?php echo e(old('name')); ?>" required placeholder="John Doe">
                            </div>
                        </div>

                        <div class="z-field">
                            <label>Email</label>
                            <div class="z-input-wrap">
                                <i class="bi bi-envelope"></i>
                                <input type="email" name="email" value="<?php echo e(old('email')); ?>" required placeholder="you@example.com">
                            </div>
                        </div>

                        <div class="z-field">
                            <label>Phone (optional)</label>
                            <div class="z-input-wrap">
                                <i class="bi bi-telephone"></i>
                                <input type="tel" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="+91 99999 99999">
                            </div>
                        </div>

                        <div class="z-field">
                            <label>Password</label>
                            <div class="z-input-wrap">
                                <i class="bi bi-lock"></i>
                                <input type="password" name="password" required placeholder="Min 8 characters">
                            </div>
                        </div>

                        <div class="z-field">
                            <label>Confirm Password</label>
                            <div class="z-input-wrap">
                                <i class="bi bi-lock-fill"></i>
                                <input type="password" name="password_confirmation" required placeholder="Repeat password">
                            </div>
                        </div>

                        <button type="submit" class="z-btn-primary w-100 mt-2">
                            Create Account <i class="bi bi-arrow-right"></i>
                        </button>
                    </form>

                    <p class="z-auth-foot">
                        Already registered? <a href="<?php echo e(url('/login')); ?>">Sign In</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/auth/register.blade.php ENDPATH**/ ?>