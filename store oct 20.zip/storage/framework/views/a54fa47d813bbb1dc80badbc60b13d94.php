 
<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
  <!-- ================= BREADCRUMB ================= -->
  <nav class="ionp-breadcrumb" aria-label="Breadcrumb">
    <ol class="ionp-breadcrumb-list">
      <li class="ionp-breadcrumb-item">
        <a href="/" class="ionp-breadcrumb-link">Home</a>
      </li>
      <li class="ionp-breadcrumb-sep" aria-hidden="true">/</li>
      <li class="ionp-breadcrumb-item">
        <span class="ionp-breadcrumb-current" aria-current="page">Products</span>
      </li>
    </ol>
  </nav>
 <section class="ionp-section" aria-labelledby="ionpTitle">
    <div class="ionp-container">

      <!-- PAGE TITLE -->
      <header class="omnx-news-header">

        <h1 class="omnx-news-title" id="omnxNewsHeading">Our <em>Products</em></h1>
        
      </header>


      <!-- TOOLBAR -->


      <!-- PRODUCT GRID -->
      <div class="ionp-grid" id="ionpGrid">

        <!-- CARD 1 -->
        <article class="ionp-card" data-name="Better Naked Palette" data-price="60">
          <div class="ionp-img-wrap">
            <img class="ionp-img" src="<?php echo e(asset('public/assets/images/X-BLUE-5-PLATES-5.webp')); ?>" alt="Better Naked Palette">
            <div class="ionp-actions">
              <button class="ionp-action" type="button">PRODUCT DETAILS <i class="fa-solid fa-arrow-right"></i></button>
            </div>
          </div>
          <a class="ionp-name" href="#product">Ionia X-BLUE Alkaline</a>
          <p class="ionp-price">$60.00</p>
        </article>

        <!-- CARD 2 -->
        <article class="ionp-card" data-name="Ionia EN-7P – Alkaline" data-price="70">
          <div class="ionp-img-wrap">
            <img class="ionp-img" src="<?php echo e(asset('public/assets/images/EN-7-P-1.webp')); ?>" alt="Ionia EN-7P – Alkaline">
            <div class="ionp-actions">
              <button class="ionp-action" type="button">PRODUCT DETAILS <i class="fa-solid fa-arrow-right"></i></button>
            </div>
          </div>
          <a class="ionp-name" href="#product">Ionia EN-7P – Alkaline</a>
          <p class="ionp-price">$70.00</p>
        </article>

        <!-- CARD 3 (badge + old price) -->
        <article class="ionp-card" data-name="Bright Eyed Illuminating" data-price="49">
          <div class="ionp-img-wrap">
            
            <img class="ionp-img" src="<?php echo e(asset('public/assets/images/sm-230.1.webp')); ?>" alt="Ionia SM-S230TL Alkaline">
            <div class="ionp-actions">
              <button class="ionp-action" type="button">PRODUCT DETAILS <i class="fa-solid fa-arrow-right"></i></button>
            </div>
          </div>
          <a class="ionp-name" href="#product">Ionia SM-S230TL Alkaline</a>
          <p class="ionp-price">$49.00 <span class="ionp-price-old">$52.00</span></p>
        </article>

        <!-- CARD 4 -->
        <article class="ionp-card" data-name="Ionia IO-400U – Alkaline" data-price="30">
          <div class="ionp-img-wrap">
            <img class="ionp-img" src="<?php echo e(asset('public/assets/images/TL-112-9PLATES-1.webp')); ?>" alt="Ionia IO-400U – Alkaline">
            <div class="ionp-actions">
              <button class="ionp-action" type="button">PRODUCT DETAILS <i class="fa-solid fa-arrow-right"></i></button>
            </div>
          </div>
          <a class="ionp-name" href="#product">Ionia IO-400U – Alkaline</a>
          <p class="ionp-price">$30.00</p>
        </article>


      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

  <script>

(() => {
      const header = document.getElementById('owHeader');
      const menuButton = document.getElementById('owMenuButton');
      const drawer = document.getElementById('owSideDrawer');
      const overlay = document.getElementById('owDrawerOverlay');
      const closeButton = document.getElementById('owDrawerClose');
      let lastFocus = null;

      function owOpenDrawer() {
        lastFocus = document.activeElement;
        header.classList.add('ow-menu-open');
        drawer.classList.add('ow-visible');
        overlay.classList.add('ow-visible');
        drawer.setAttribute('aria-hidden', 'false');
        overlay.setAttribute('aria-hidden', 'false');
        menuButton.setAttribute('aria-expanded', 'true');
        menuButton.setAttribute('aria-label', 'Close menu');
        document.body.classList.add('ow-body-locked');
        closeButton.focus();
      }
      function owCloseDrawer() {
        header.classList.remove('ow-menu-open');
        drawer.classList.remove('ow-visible');
        overlay.classList.remove('ow-visible');
        drawer.setAttribute('aria-hidden', 'true');
        overlay.setAttribute('aria-hidden', 'true');
        menuButton.setAttribute('aria-expanded', 'false');
        menuButton.setAttribute('aria-label', 'Open menu');
        document.body.classList.remove('ow-body-locked');
        if (lastFocus) lastFocus.focus();
      }

      menuButton.addEventListener('click', () => drawer.classList.contains('ow-visible') ? owCloseDrawer() : owOpenDrawer());
      closeButton.addEventListener('click', owCloseDrawer);
      overlay.addEventListener('click', owCloseDrawer);
      drawer.querySelectorAll('a').forEach(link => link.addEventListener('click', owCloseDrawer));
      document.addEventListener('keydown', event => {
        if (event.key === 'Escape' && drawer.classList.contains('ow-visible')) owCloseDrawer();
      });
      document.getElementById('owNewsletterForm').addEventListener('submit', event => {
        event.preventDefault();
        document.getElementById('owNewsletterMessage').textContent = 'Thanks! Connect this form to your newsletter service to collect subscriptions.';
        event.target.reset();
      });
    })();

        (function() {
      const slider = document.getElementById('heroSlider');
      const slides = Array.from(document.querySelectorAll('.blume-hero-slide'));
      const dots = Array.from(document.querySelectorAll('.blume-hero-dot'));
      const prevBtn = document.getElementById('prevBtn');
      const nextBtn = document.getElementById('nextBtn');
      const dotsContainer = document.getElementById('dotsContainer');

      let currentIndex = 0;
      let slideInterval = null;
      const SLIDE_DURATION = 6000; // ms, matches dot animation

      // ---- helper: go to slide ----
      function goToSlide(index) {
        // wrap around
        if (index < 0) index = slides.length - 1;
        if (index >= slides.length) index = 0;

        // update slides
        slides.forEach((slide, i) => {
          slide.classList.toggle('blume-hero-active', i === index);
        });

        // update dots
        dots.forEach((dot, i) => {
          dot.classList.toggle('blume-hero-active', i === index);
        });

        currentIndex = index;
        resetTimer();
      }

      // ---- next / prev ----
      function nextSlide() {
        goToSlide(currentIndex + 1);
      }

      function prevSlide() {
        goToSlide(currentIndex - 1);
      }

      // ---- autoplay timer ----
      function startTimer() {
        if (slideInterval) clearInterval(slideInterval);
        slideInterval = setInterval(() => {
          nextSlide();
        }, SLIDE_DURATION);
      }

      function resetTimer() {
        if (slideInterval) {
          clearInterval(slideInterval);
          slideInterval = null;
        }
        // only restart if not paused (we don't have pause now, but keep logic)
        startTimer();
      }

      // pause on hover (optional, nice UX)
      slider.addEventListener('mouseenter', () => {
        slider.classList.add('is-paused');
        if (slideInterval) {
          clearInterval(slideInterval);
          slideInterval = null;
        }
      });
      slider.addEventListener('mouseleave', () => {
        slider.classList.remove('is-paused');
        startTimer();
      });

      // ---- event listeners ----
      prevBtn.addEventListener('click', (e) => {
        e.preventDefault();
        prevSlide();
      });

      nextBtn.addEventListener('click', (e) => {
        e.preventDefault();
        nextSlide();
      });

      dots.forEach((dot, idx) => {
        dot.addEventListener('click', (e) => {
          e.preventDefault();
          goToSlide(idx);
        });
      });

      // keyboard navigation
      document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
          prevSlide();
        } else if (e.key === 'ArrowRight') {
          nextSlide();
        }
      });

      // ---- init ----
      // ensure first slide is active (already is in markup, but just in case)
      goToSlide(0);
      // start autoplay
      startTimer();

      // Cleanup on page unload (optional)
      window.addEventListener('beforeunload', () => {
        if (slideInterval) clearInterval(slideInterval);
      });
    })();

  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/store/resources/views/home/product.blade.php ENDPATH**/ ?>