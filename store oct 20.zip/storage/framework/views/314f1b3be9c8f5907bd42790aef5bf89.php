<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['product']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['product']); ?>
<?php foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $price = $product->price;
    $compare = $product->compare_price;
    $discount = ($compare && $compare > $price) ? round((($compare - $price) / $compare) * 100) : 0;
?>

<div class="z-product-card">
    <div class="z-pc-media">
        <a href="<?php echo e(url('/product/'.$product->slug)); ?>">
            <?php if($product->thumbnail): ?>
                <img src="<?php echo e(asset($product->thumbnail)); ?>" alt="<?php echo e($product->name); ?>" loading="lazy">
            <?php else: ?>
                <div class="z-pc-placeholder">
                    <i class="bi bi-image"></i>
                </div>
            <?php endif; ?>
        </a>

        <?php if($discount > 0): ?>
            <span class="z-pc-discount">-<?php echo e($discount); ?>%</span>
        <?php endif; ?>

        <?php if($product->is_new_arrival): ?>
            <span class="z-pc-tag">New</span>
        <?php endif; ?>

        <div class="z-pc-actions">
            <button class="z-pc-act wishlist-btn" data-id="<?php echo e($product->id); ?>" title="Wishlist">
                <i class="bi bi-heart"></i>
            </button>
        </div>
    </div>

    <div class="z-pc-body">
        <div class="z-pc-brand"><?php echo e($product->brand->name ?? 'Zambit'); ?></div>
        <h3 class="z-pc-title">
            <a href="<?php echo e(url('/product/'.$product->slug)); ?>"><?php echo e(\Illuminate\Support\Str::limit($product->name, 45)); ?></a>
        </h3>

        <?php if (isset($component)) { $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rating','data' => ['value' => $product->avg_rating ?? 4.5,'count' => $product->review_count ?? 0]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('rating'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->avg_rating ?? 4.5),'count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->review_count ?? 0)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $attributes = $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $component = $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>

        <div class="z-pc-price">
            <span class="z-price-now">₹<?php echo e(number_format($price)); ?></span>
            <?php if($compare && $compare > $price): ?>
                <span class="z-price-old">₹<?php echo e(number_format($compare)); ?></span>
            <?php endif; ?>
        </div>

        <button class="z-btn-cart add-to-cart-btn" data-id="<?php echo e($product->id); ?>">
            <i class="bi bi-bag-plus"></i> Add to Cart
        </button>
    </div>
</div>
<?php /**PATH /home/mdehsan/zambit-store/resources/views/components/product-card.blade.php ENDPATH**/ ?>