<?php $__env->startSection('title', 'Customers'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i><span>Customers</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <div>
        <h1>Customers</h1>
        <p><?php echo e($customers->total()); ?> registered customers</p>
    </div>
</div>

<div class="z-card">
    <div class="table-responsive">
        <table class="table z-table">
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Contact</th>
                    <th>Orders</th>
                    <th>Total Spent</th>
                    <th>Status</th>
                    <th>Joined</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="z-user-cell">
                            <div class="z-uc-avatar"><?php echo e(strtoupper(substr($c->name,0,1))); ?></div>
                            <div>
                                <strong><?php echo e($c->name); ?></strong>
                                <small>#C-<?php echo e(str_pad($c->id,5,'0',STR_PAD_LEFT)); ?></small>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div><?php echo e($c->email); ?></div>
                        <small class="text-muted"><?php echo e($c->phone); ?></small>
                    </td>
                    <td><?php echo e($c->customerProfile->total_orders ?? 0); ?></td>
                    <td><strong>₹<?php echo e(number_format($c->customerProfile->total_spent ?? 0)); ?></strong></td>
                    <td>
                        <span class="z-status z-status-<?php echo e($c->status === 'active' ? 'delivered' : 'cancelled'); ?>">
                            <?php echo e(ucfirst($c->status)); ?>

                        </span>
                    </td>
                    <td><?php echo e($c->created_at->format('d M Y')); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.customers.show', $c)); ?>" class="z-act-btn"><i class="bi bi-eye"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center py-5 text-muted">No customers yet</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-3 d-flex justify-content-center">
        <?php echo e($customers->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/store/resources/views/admin/customers/index.blade.php ENDPATH**/ ?>