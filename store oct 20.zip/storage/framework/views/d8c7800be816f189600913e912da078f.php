<?php $__env->startSection('title', 'store Store — Premium Shopping Experience'); ?>

<?php $__env->startSection('content'); ?>

<!-- HERO -->
<section class="z-hero">
    <div id="heroSlider" class="carousel slide z-hero-carousel" data-bs-ride="carousel">
        <div class="carousel-inner">
            <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                <div class="z-hero-slide" style="background-image:url('<?php echo e(asset($banner->image)); ?>')">
                    <div class="container">
                        <div class="z-hero-content">
                            <span class="z-hero-badge">🔥 Limited Time Offer</span>
                            <h1><?php echo e($banner->title); ?></h1>
                            <p><?php echo e($banner->subtitle); ?></p>
                            <a href="<?php echo e($banner->link ?? '/shop'); ?>" class="z-btn-primary z-btn-lg">
                                <?php echo e($banner->button_text ?? 'Shop Now'); ?> <i class="bi bi-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="carousel-item active">
                <div class="z-hero-slide z-hero-slide-fallback">
                    <div class="container">
                        <div class="z-hero-content">
                            <span class="z-hero-badge">🔥 Mega Sale — Up to 60% Off</span>
                            <h1>Premium Products.<br>Unbeatable Prices.</h1>
                            <p>Shop the latest electronics, fashion, home essentials & more.</p>
                            <a href="<?php echo e(url('/shop')); ?>" class="z-btn-primary z-btn-lg">
                                Shop Now <i class="bi bi-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <button class="carousel-control-prev z-hero-nav" data-bs-target="#heroSlider" data-bs-slide="prev">
            <i class="bi bi-chevron-left"></i>
        </button>
        <button class="carousel-control-next z-hero-nav" data-bs-target="#heroSlider" data-bs-slide="next">
            <i class="bi bi-chevron-right"></i>
        </button>
    </div>
</section>

<!-- TRUST -->
<section class="z-trust">
    <div class="container">
        <div class="row g-3">
            <div class="col-6 col-lg-3">
                <div class="z-trust-item">
                    <i class="bi bi-truck"></i>
                    <div><strong>Free Shipping</strong><span>On orders above ₹999</span></div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="z-trust-item">
                    <i class="bi bi-arrow-repeat"></i>
                    <div><strong>Easy Returns</strong><span>7-day return policy</span></div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="z-trust-item">
                    <i class="bi bi-shield-check"></i>
                    <div><strong>Secure Payment</strong><span>100% protected</span></div>
                </div>
            </div>
            <div class="col-6 col-lg-3">
                <div class="z-trust-item">
                    <i class="bi bi-headset"></i>
                    <div><strong>24/7 Support</strong><span>Dedicated help</span></div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CATEGORIES -->
<?php if($categories->count()): ?>
<section class="z-section">
    <div class="container">
        <div class="z-section-head">
            <div>
                <span class="z-eyebrow">Browse by Category</span>
                <h2>Shop Top Categories</h2>
            </div>
            <a href="<?php echo e(url('/shop')); ?>" class="z-link-arrow">View All <i class="bi bi-arrow-right"></i></a>
        </div>
        <div class="row g-3">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-md-4 col-lg-2">
                <a href="<?php echo e(url('/shop?category='.$cat->id)); ?>" class="z-cat-card">
                    <div class="z-cat-img">
                        <?php if($cat->image): ?>
                            <img src="<?php echo e(asset($cat->image)); ?>" alt="<?php echo e($cat->name); ?>">
                        <?php else: ?>
                            <i class="bi bi-grid" style="font-size:28px;color:var(--z-blue)"></i>
                        <?php endif; ?>
                    </div>
                    <span><?php echo e($cat->name); ?></span>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- FEATURED PRODUCTS -->
<section class="z-section z-section-alt">
    <div class="container">
        <div class="z-section-head">
            <div>
                <span class="z-eyebrow">Handpicked For You</span>
                <h2>Featured Products</h2>
            </div>
            <a href="<?php echo e(url('/shop')); ?>" class="z-link-arrow">View All <i class="bi bi-arrow-right"></i></a>
        </div>
        <div class="row g-3 g-md-4">
            <?php $__empty_1 = true; $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-6 col-md-4 col-lg-3">
                <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center py-5 text-muted">No products yet.</div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- PROMO -->
<section class="z-section">
    <div class="container">
        <div class="row g-3">
            <div class="col-lg-6">
                <div class="z-promo z-promo-1">
                    <div>
                        <span class="z-promo-tag">New Season</span>
                        <h3>Electronics<br>Up to 40% OFF</h3>
                        <a href="<?php echo e(url('/shop')); ?>" class="z-btn-primary">Shop Now</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="z-promo z-promo-2">
                    <div>
                        <span class="z-promo-tag">Fashion Week</span>
                        <h3>Trending Styles<br>From ₹499</h3>
                        <a href="<?php echo e(url('/shop')); ?>" class="z-btn-primary">Explore</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- BRANDS -->
<?php if($brands->count()): ?>
<section class="z-section z-section-alt">
    <div class="container">
        <div class="z-section-head">
            <div>
                <span class="z-eyebrow">Trusted Brands</span>
                <h2>Shop by Brand</h2>
            </div>
        </div>
        <div class="row g-3">
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4 col-md-3 col-lg-2">
                <a href="<?php echo e(url('/shop?brand='.$brand->id)); ?>" class="z-brand-card">
                    <?php if($brand->logo): ?>
                        <img src="<?php echo e(asset($brand->logo)); ?>" alt="<?php echo e($brand->name); ?>">
                    <?php else: ?>
                        <strong style="font-size:16px;color:var(--z-navy)"><?php echo e($brand->name); ?></strong>
                    <?php endif; ?>
                    <span><?php echo e($brand->name); ?></span>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- TESTIMONIALS -->
<section class="z-section">
    <div class="container">
        <div class="z-section-head text-center d-block">
            <span class="z-eyebrow">Real Reviews</span>
            <h2>What Our Customers Say</h2>
        </div>
        <div class="row g-3">
            <div class="col-md-4">
                <div class="z-testimonial">
                    <?php if (isset($component)) { $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rating','data' => ['value' => 5]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('rating'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 5]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $attributes = $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $component = $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
                    <p>"Amazing shopping experience! Fast delivery, genuine products."</p>
                    <div class="z-testi-author">
                        <div class="z-tavatar">R</div>
                        <div><strong>Ravi Sharma</strong><small>Verified Buyer</small></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="z-testimonial">
                    <?php if (isset($component)) { $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rating','data' => ['value' => 5]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('rating'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 5]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $attributes = $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $component = $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
                    <p>"Customer support is truly world-class. Highly recommend store."</p>
                    <div class="z-testi-author">
                        <div class="z-tavatar">A</div>
                        <div><strong>Anita Verma</strong><small>Verified Buyer</small></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="z-testimonial">
                    <?php if (isset($component)) { $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rating','data' => ['value' => 4.5]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('rating'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => 4.5]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $attributes = $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $component = $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
                    <p>"Best prices in the market. Will definitely shop again!"</p>
                    <div class="z-testi-author">
                        <div class="z-tavatar">S</div>
                        <div><strong>Sunil Patel</strong><small>Verified Buyer</small></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/store/resources/views/home/index.blade.php ENDPATH**/ ?>