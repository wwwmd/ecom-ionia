<header class="z-topbar-admin">
    <div class="z-tb-left">
        <button class="z-tb-toggle" id="toggleSidebar">
            <i class="bi bi-list"></i>
        </button>
        <div class="z-tb-search d-none d-md-block">
            <i class="bi bi-search"></i>
            <input type="text" placeholder="Search...">
        </div>
    </div>

    <div class="z-tb-right">
        <a href="<?php echo e(url('/')); ?>" target="_blank" class="z-tb-btn" title="View Store">
            <i class="bi bi-shop"></i>
        </a>

        <div class="dropdown">
            <button class="z-tb-btn" data-bs-toggle="dropdown">
                <i class="bi bi-bell"></i>
                <span class="z-tb-dot"></span>
            </button>
            <div class="dropdown-menu dropdown-menu-end z-notif-dropdown">
                <div class="z-notif-head">
                    <strong>Notifications</strong>
                    <a href="#" class="z-link">Mark all read</a>
                </div>
                <div class="z-notif-list">
                    <?php for($i=0;$i<4;$i++): ?>
                    <a href="#" class="z-notif-item">
                        <div class="z-ni-icon bg-<?php echo e(['primary','success','warning','danger'][$i]); ?>-subtle">
                            <i class="bi bi-<?php echo e(['bag-check','person-plus','exclamation-triangle','cash-coin'][$i]); ?>"></i>
                        </div>
                        <div>
                            <strong><?php echo e(['New order received','New customer','Low stock alert','Payment received'][$i]); ?></strong>
                            <small><?php echo e(['#ORD-10021','Ravi Sharma','iPhone 15 Pro','₹129,900'][$i]); ?></small>
                        </div>
                    </a>
                    <?php endfor; ?>
                </div>
            </div>
        </div>

        <div class="dropdown">
            <button class="z-tb-profile" data-bs-toggle="dropdown">
                <div class="z-tbp-avatar"><?php echo e(strtoupper(substr(auth()->user()->name ?? 'A', 0, 1))); ?></div>
                <div class="z-tbp-text d-none d-md-block">
                    <strong><?php echo e(auth()->user()->name ?? 'Admin'); ?></strong>
                    <small><?php echo e(auth()->user()->role->name ?? 'Super Admin'); ?></small>
                </div>
            </button>
            <ul class="dropdown-menu dropdown-menu-end z-dropdown">
                <li>
                    <form action="<?php echo e(url('/logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="dropdown-item text-danger"><i class="bi bi-box-arrow-right"></i> Logout</button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</header>
<?php /**PATH /home/mdehsan/store/resources/views/partials/admin-topbar.blade.php ENDPATH**/ ?>