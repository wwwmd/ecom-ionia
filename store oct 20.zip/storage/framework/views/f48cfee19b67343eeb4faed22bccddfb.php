<?php $__env->startSection('title', 'CRM Leads'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i>
    <span>CRM</span>
    <i class="bi bi-chevron-right"></i><span>Leads</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <div>
        <h1>Leads</h1>
        <p>Manage sales leads and conversions</p>
    </div>
    <div class="z-page-head-actions">
        <a href="<?php echo e(route('admin.leads.create')); ?>" class="z-btn-primary"><i class="bi bi-plus-lg"></i> Add Lead</a>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-6 col-lg-3">
        <div class="z-mini-stat">
            <div class="z-ms-icon z-ms-blue"><i class="bi bi-funnel"></i></div>
            <div><span>Total</span><strong><?php echo e($stats['total']); ?></strong></div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="z-mini-stat">
            <div class="z-ms-icon z-ms-teal"><i class="bi bi-stars"></i></div>
            <div><span>New</span><strong><?php echo e($stats['new']); ?></strong></div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="z-mini-stat">
            <div class="z-ms-icon z-ms-orange"><i class="bi bi-telephone"></i></div>
            <div><span>Contacted</span><strong><?php echo e($stats['contacted']); ?></strong></div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="z-mini-stat">
            <div class="z-ms-icon z-ms-green"><i class="bi bi-trophy"></i></div>
            <div><span>Converted</span><strong><?php echo e($stats['converted']); ?></strong></div>
        </div>
    </div>
</div>

<div class="z-card mb-3">
    <form method="GET" class="z-filters">
        <div class="z-fi">
            <label>Status</label>
            <select name="status" class="z-select">
                <option value="">All</option>
                <?php $__currentLoopData = ['new','contacted','interested','followup','negotiation','converted','lost']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s); ?>" <?php if(request('status') == $s): echo 'selected'; endif; ?>><?php echo e(ucfirst($s)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="z-fi">
            <label>Priority</label>
            <select name="priority" class="z-select">
                <option value="">All</option>
                <?php $__currentLoopData = ['low','medium','high','urgent']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p); ?>" <?php if(request('priority') == $p): echo 'selected'; endif; ?>><?php echo e(ucfirst($p)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="z-fi z-fi-btn">
            <button class="z-btn-primary"><i class="bi bi-funnel"></i> Filter</button>
            <a href="<?php echo e(route('admin.leads')); ?>" class="z-btn-ghost">Reset</a>
        </div>
    </form>
</div>

<div class="z-card">
    <div class="table-responsive">
        <table class="table z-table">
            <thead>
                <tr>
                    <th>Code</th><th>Lead</th><th>Phone</th><th>Source</th>
                    <th>Priority</th><th>Status</th><th>Agent</th><th></th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><strong><?php echo e($lead->lead_code); ?></strong></td>
                    <td>
                        <div class="z-user-cell">
                            <div class="z-uc-avatar"><?php echo e(strtoupper(substr($lead->name,0,1))); ?></div>
                            <div><strong><?php echo e($lead->name); ?></strong><small><?php echo e($lead->email); ?></small></div>
                        </div>
                    </td>
                    <td><?php echo e($lead->phone); ?></td>
                    <td><?php echo e(ucfirst($lead->source)); ?></td>
                    <td><span class="z-priority z-priority-<?php echo e($lead->priority); ?>"><?php echo e($lead->priority); ?></span></td>
                    <td><span class="z-status z-status-<?php echo e($lead->status); ?>"><?php echo e(ucfirst($lead->status)); ?></span></td>
                    <td><?php echo e($lead->agent->name ?? 'Unassigned'); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.leads.show', $lead)); ?>" class="z-act-btn"><i class="bi bi-eye"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="text-center py-5 text-muted">No leads yet</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-3 d-flex justify-content-center">
        <?php echo e($leads->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/admin/crm/leads/index.blade.php ENDPATH**/ ?>