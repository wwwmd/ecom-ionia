<?php $__env->startSection('title', 'Shopping Cart — Zambit Store'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <nav class="z-breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Home</a>
        <i class="bi bi-chevron-right"></i>
        <span>Cart</span>
    </nav>

    <h1 class="z-page-title">Shopping Cart</h1>

    <?php if($cartItems->isEmpty()): ?>
        <div class="z-empty">
            <i class="bi bi-bag-x"></i>
            <h4>Your cart is empty</h4>
            <p>Add products to start shopping.</p>
            <a href="<?php echo e(url('/shop')); ?>" class="z-btn-primary">Continue Shopping</a>
        </div>
    <?php else: ?>
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="z-cart-list">
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="z-cart-item" data-id="<?php echo e($item->id); ?>">
                    <?php if($item->product->thumbnail): ?>
                        <img src="<?php echo e(asset($item->product->thumbnail)); ?>" alt="">
                    <?php else: ?>
                        <div style="width:90px;height:90px;background:var(--z-light);border-radius:10px;display:flex;align-items:center;justify-content:center">
                            <i class="bi bi-image" style="font-size:28px;color:var(--z-border)"></i>
                        </div>
                    <?php endif; ?>
                    <div class="z-ci-info">
                        <h5><?php echo e($item->product->name); ?></h5>
                        <span class="text-muted">₹<?php echo e(number_format($item->price)); ?> each</span>
                    </div>
                    <div class="z-qty">
                        <button type="button" class="qty-minus">−</button>
                        <input type="number" value="<?php echo e($item->quantity); ?>" class="cart-qty" data-id="<?php echo e($item->id); ?>">
                        <button type="button" class="qty-plus">+</button>
                    </div>
                    <div class="z-ci-total">₹<?php echo e(number_format($item->price * $item->quantity)); ?></div>
                    <button class="z-remove remove-cart" data-id="<?php echo e($item->id); ?>">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <a href="<?php echo e(url('/shop')); ?>" class="z-btn-ghost mt-3">
                <i class="bi bi-arrow-left"></i> Continue Shopping
            </a>
        </div>

        <div class="col-lg-4">
            <div class="z-summary">
                <h5>Order Summary</h5>

                <div class="z-coupon">
                    <input type="text" id="couponCode" placeholder="Coupon code">
                    <button id="applyCoupon" class="z-btn-ghost" type="button">Apply</button>
                </div>

                <div class="z-summary-row">
                    <span>Subtotal</span>
                    <span id="subTotal">₹<?php echo e(number_format($subtotal)); ?></span>
                </div>
                <div class="z-summary-row">
                    <span>Discount</span>
                    <span id="discount" class="text-success">−₹<?php echo e(number_format($discount)); ?></span>
                </div>
                <div class="z-summary-row">
                    <span>Tax (18%)</span>
                    <span>₹<?php echo e(number_format($tax)); ?></span>
                </div>
                <div class="z-summary-row">
                    <span>Shipping</span>
                    <span>₹<?php echo e(number_format($shipping)); ?></span>
                </div>
                <hr>
                <div class="z-summary-row z-total">
                    <span>Grand Total</span>
                    <span id="grandTotal">₹<?php echo e(number_format($grandTotal)); ?></span>
                </div>

                <a href="<?php echo e(url('/checkout')); ?>" class="z-btn-primary w-100 mt-3">
                    Proceed to Checkout <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/cart/index.blade.php ENDPATH**/ ?>