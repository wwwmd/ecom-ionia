<?php $__env->startSection('title', 'My Orders — Zambit Store'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <nav class="z-breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Home</a>
        <i class="bi bi-chevron-right"></i>
        <span>My Orders</span>
    </nav>

    <h1 class="z-page-title">My Orders</h1>

    <div class="z-card">
        <div class="table-responsive">
            <table class="table z-table">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Date</th>
                        <th>Items</th>
                        <th>Total</th>
                        <th>Payment</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><strong><?php echo e($o->order_number); ?></strong></td>
                        <td><?php echo e($o->created_at->format('d M Y')); ?></td>
                        <td><?php echo e($o->items->count()); ?> items</td>
                        <td><strong>₹<?php echo e(number_format($o->grand_total)); ?></strong></td>
                        <td><span class="z-status z-status-<?php echo e($o->payment_status); ?>"><?php echo e(ucfirst($o->payment_status)); ?></span></td>
                        <td><span class="z-status z-status-<?php echo e($o->status); ?>"><?php echo e(ucfirst(str_replace('_',' ',$o->status))); ?></span></td>
                        <td>
                            <a href="<?php echo e(url('/customer/orders/'.$o->id)); ?>" class="z-btn-ghost" style="padding:6px 14px;font-size:13px">View</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" class="text-center text-muted py-5">
                        <i class="bi bi-inbox" style="font-size:48px;display:block;margin-bottom:12px;opacity:.3"></i>
                        No orders yet. <a href="<?php echo e(url('/shop')); ?>">Start shopping</a>
                    </td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3 d-flex justify-content-center">
            <?php echo e($orders->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/customer/orders.blade.php ENDPATH**/ ?>