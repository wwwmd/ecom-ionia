<?php $__env->startSection('title', 'Activity Logs'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i><span>Activity Logs</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <h1>Activity Logs</h1>
</div>

<div class="z-card">
    <div class="table-responsive">
        <table class="table z-table">
            <thead>
                <tr><th>Time</th><th>User</th><th>Module</th><th>Action</th><th>Description</th><th>IP</th></tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><small><?php echo e($log->created_at->format('d M Y, h:i A')); ?></small></td>
                    <td>
                        <?php if($log->user): ?>
                            <strong><?php echo e($log->user->name); ?></strong>
                            <small class="d-block text-muted"><?php echo e($log->user_type); ?></small>
                        <?php else: ?>
                            <span class="text-muted">System</span>
                        <?php endif; ?>
                    </td>
                    <td><span class="z-status"><?php echo e($log->module); ?></span></td>
                    <td><?php echo e($log->action); ?></td>
                    <td><small><?php echo e($log->description); ?></small></td>
                    <td><small class="text-muted"><?php echo e($log->ip_address); ?></small></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center py-5 text-muted">No logs yet</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-3 d-flex justify-content-center">
        <?php echo e($logs->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/store/resources/views/admin/logs/index.blade.php ENDPATH**/ ?>