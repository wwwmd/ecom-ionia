<?php $__env->startSection('title', 'Add Lead'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i>
    <a href="<?php echo e(route('admin.leads')); ?>">Leads</a>
    <i class="bi bi-chevron-right"></i><span>Add New</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <h1>Add New Lead</h1>
    <a href="<?php echo e(route('admin.leads')); ?>" class="z-btn-ghost"><i class="bi bi-arrow-left"></i> Back</a>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0 ps-3"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($err); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('admin.leads.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row g-3">
        <div class="col-lg-8">
            <div class="z-card">
                <h5>Lead Information</h5>
                <div class="row g-3">
                    <div class="col-md-6"><label>Full Name *</label><input type="text" name="name" class="z-input" value="<?php echo e(old('name')); ?>" required></div>
                    <div class="col-md-6"><label>Phone *</label><input type="tel" name="phone" class="z-input" value="<?php echo e(old('phone')); ?>" required></div>
                    <div class="col-md-6"><label>Email</label><input type="email" name="email" class="z-input" value="<?php echo e(old('email')); ?>"></div>
                    <div class="col-md-6">
                        <label>Source *</label>
                        <select name="source" class="z-select w-100" required>
                            <option value="website">Website</option>
                            <option value="phone">Phone</option>
                            <option value="whatsapp">WhatsApp</option>
                            <option value="walkin">Walk-in</option>
                            <option value="referral">Referral</option>
                            <option value="social">Social</option>
                            <option value="email">Email</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="col-md-6"><label>Product Interest</label><input type="text" name="product_interest" class="z-input" value="<?php echo e(old('product_interest')); ?>"></div>
                    <div class="col-md-6"><label>Estimated Value</label><input type="number" step="0.01" name="estimated_value" class="z-input" value="<?php echo e(old('estimated_value', 0)); ?>"></div>
                    <div class="col-12"><label>Remarks</label><textarea name="remarks" class="z-input" rows="3"><?php echo e(old('remarks')); ?></textarea></div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="z-card mb-3">
                <h5>Status & Priority</h5>
                <div class="mb-3">
                    <label>Status *</label>
                    <select name="status" class="z-select w-100" required>
                        <option value="new">New</option>
                        <option value="contacted">Contacted</option>
                        <option value="interested">Interested</option>
                        <option value="followup">Follow-up</option>
                        <option value="negotiation">Negotiation</option>
                        <option value="converted">Converted</option>
                        <option value="lost">Lost</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label>Priority *</label>
                    <select name="priority" class="z-select w-100" required>
                        <option value="low">Low</option>
                        <option value="medium" selected>Medium</option>
                        <option value="high">High</option>
                        <option value="urgent">Urgent</option>
                    </select>
                </div>
                <div>
                    <label>Assign Agent</label>
                    <select name="assigned_agent_id" class="z-select w-100">
                        <option value="">Unassigned</option>
                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="z-card">
                <button type="submit" class="z-btn-primary w-100 mb-2"><i class="bi bi-check2"></i> Create Lead</button>
                <a href="<?php echo e(route('admin.leads')); ?>" class="z-btn-ghost w-100 justify-content-center">Cancel</a>
            </div>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/admin/crm/leads/create.blade.php ENDPATH**/ ?>