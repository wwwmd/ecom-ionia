<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i><span>Dashboard</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <div>
        <h1>Welcome back, <?php echo e(auth()->user()->name); ?></h1>
        <p>Here's what's happening with your store today.</p>
    </div>
    
</div>

<!-- KPI Cards -->


<!-- Mini Stats -->


<!-- Charts -->




<!-- Recent Tables -->


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
    new Chart(document.getElementById('revenueChart'), {
        type: 'line',
        data: {
            labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
            datasets: [{
                label: 'Revenue',
                data: [45,58,52,68,72,85,92,88,105,118,128,142].map(v => v*1000),
                borderColor: '#2E6DB4',
                backgroundColor: (ctx) => {
                    const g = ctx.chart.ctx.createLinearGradient(0, 0, 0, 300);
                    g.addColorStop(0, 'rgba(46,109,180,.25)');
                    g.addColorStop(1, 'rgba(38,166,154,0)');
                    return g;
                },
                fill: true, tension: .4, borderWidth: 3,
                pointBackgroundColor: '#fff', pointBorderColor: '#2E6DB4',
                pointBorderWidth: 3, pointRadius: 5
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, grid: { color: '#EEF2F7' }, ticks: { callback: v => '₹'+(v/1000)+'k' } },
                x: { grid: { display: false } }
            }
        }
    });

    new Chart(document.getElementById('orderStatusChart'), {
        type: 'doughnut',
        data: {
            labels: ['Delivered','Processing','Shipped','Pending','Cancelled'],
            datasets: [{
                data: [<?php echo e($stats['completed']); ?>, 20, 15, <?php echo e($stats['pending']); ?>, <?php echo e($stats['cancelled']); ?>],
                backgroundColor: ['#16A34A','#2E6DB4','#6366F1','#F59E0B','#DC2626'],
                borderWidth: 0, hoverOffset: 8
            }]
        },
        options: { cutout: '72%', plugins: { legend: { position: 'bottom', labels: { boxWidth: 10 } } } }
    });

    new Chart(document.getElementById('customerChart'), {
        type: 'bar',
        data: {
            labels: ['Jan','Feb','Mar','Apr','May','Jun'],
            datasets: [{
                label: 'New Customers',
                data: [22,35,28,42,55,68],
                backgroundColor: '#26A69A',
                borderRadius: 8, barThickness: 28
            }]
        },
        options: {
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, grid: { color: '#EEF2F7' } }, x: { grid: { display: false } } }
        }
    });

    new Chart(document.getElementById('leadChart'), {
        type: 'bar',
        data: {
            labels: ['New','Contacted','Interested','Negotiation','Converted','Lost'],
            datasets: [{
                data: [24,18,12,8,42,11],
                backgroundColor: ['#2E6DB4','#3B82F6','#8B5CF6','#F59E0B','#16A34A','#DC2626'],
                borderRadius: 6, barThickness: 24
            }]
        },
        options: {
            plugins: { legend: { display: false } },
            scales: { x: { beginAtZero: true, grid: { color: '#EEF2F7' } }, y: { grid: { display: false } } }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/store/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>