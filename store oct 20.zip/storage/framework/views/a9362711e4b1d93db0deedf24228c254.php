<footer class="z-footer">
    <div class="z-newsletter">
        <div class="container">
            <div class="z-nl-box">
                <div class="row align-items-center g-3">
                    <div class="col-lg-6">
                        <h3 class="mb-1">Stay in the loop 🔔</h3>
                        <p class="mb-0">Subscribe to get exclusive deals, new arrivals & insider offers.</p>
                    </div>
                    <div class="col-lg-6">
                        <form class="z-nl-form" id="newsletterForm">
                            <?php echo csrf_field(); ?>
                            <input type="email" name="email" placeholder="Enter your email address" required>
                            <button type="submit">Subscribe <i class="bi bi-arrow-right"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container z-footer-main">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <span style="font-size:26px;font-weight:800;background:linear-gradient(135deg,#26A69A,#2E6DB4);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">
                    Zambit
                </span>
                <p class="z-footer-about mt-3">
                    Zambit Technologies — Think Beyond, Do Beyond. Delivering premium shopping experiences across India with fast shipping, secure payments, and dedicated support.
                </p>
                <div class="z-social">
                    <a href="#"><i class="bi bi-facebook"></i></a>
                    <a href="#"><i class="bi bi-instagram"></i></a>
                    <a href="#"><i class="bi bi-twitter-x"></i></a>
                    <a href="#"><i class="bi bi-youtube"></i></a>
                    <a href="#"><i class="bi bi-linkedin"></i></a>
                </div>
            </div>

            <div class="col-lg-2 col-md-6 col-6">
                <h5 class="z-footer-title">Shop</h5>
                <ul class="z-footer-links">
                    <li><a href="<?php echo e(url('/shop')); ?>">All Products</a></li>
                    <li><a href="<?php echo e(url('/shop?filter=new')); ?>">New Arrivals</a></li>
                    <li><a href="<?php echo e(url('/shop?filter=best')); ?>">Best Sellers</a></li>
                    <li><a href="<?php echo e(url('/shop?filter=deals')); ?>">Deals & Offers</a></li>
                </ul>
            </div>

            <div class="col-lg-2 col-md-6 col-6">
                <h5 class="z-footer-title">Account</h5>
                <ul class="z-footer-links">
                    <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                    <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
                    <li><a href="<?php echo e(url('/customer/orders')); ?>">My Orders</a></li>
                    <li><a href="<?php echo e(url('/wishlist')); ?>">Wishlist</a></li>
                </ul>
            </div>

            <div class="col-lg-2 col-md-6 col-6">
                <h5 class="z-footer-title">Support</h5>
                <ul class="z-footer-links">
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Shipping Policy</a></li>
                    <li><a href="#">Returns</a></li>
                </ul>
            </div>

            <div class="col-lg-2 col-md-6 col-6">
                <h5 class="z-footer-title">Contact</h5>
                <ul class="z-footer-contact">
                    <li><i class="bi bi-geo-alt-fill"></i> 123 Business Park, Mumbai</li>
                    <li><i class="bi bi-telephone-fill"></i> +91 99999 99999</li>
                    <li><i class="bi bi-envelope-fill"></i> hello@zambit.com</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="z-footer-bottom">
        <div class="container d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div>© <?php echo e(date('Y')); ?> Zambit Technologies. All rights reserved.</div>
            <div class="z-payments">
                <span>Secure payments:</span>
                <i class="bi bi-credit-card-2-front"></i>
                <i class="bi bi-paypal"></i>
                <i class="bi bi-bank"></i>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/mdehsan/zambit-store/resources/views/partials/footer.blade.php ENDPATH**/ ?>