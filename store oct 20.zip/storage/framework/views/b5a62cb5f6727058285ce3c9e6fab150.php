<header class="z-header">
    <!-- Top Bar -->
    <div class="z-topbar d-none d-lg-block">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="z-topbar-left">
                <i class="bi bi-telephone-fill"></i> +91 99999 99999
                <span class="mx-3">|</span>
                <i class="bi bi-envelope-fill"></i> hello@zambit.com
            </div>
            <div class="z-topbar-right">
                <a href="#">Track Order</a>
                <span class="mx-2">|</span>
                <a href="#">Help Center</a>
                <span class="mx-2">|</span>
                <a href="#"><i class="bi bi-facebook"></i></a>
                <a href="#" class="ms-2"><i class="bi bi-instagram"></i></a>
                <a href="#" class="ms-2"><i class="bi bi-twitter-x"></i></a>
            </div>
        </div>
    </div>

    <!-- Main Header -->
    <div class="z-header-main">
        <div class="container">
            <div class="row align-items-center g-2 g-lg-3">

                <div class="col-auto d-lg-none">
                    <button class="z-icon-btn" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu">
                        <i class="bi bi-list"></i>
                    </button>
                </div>

                <div class="col-auto col-lg-2">
                    <a href="<?php echo e(url('/')); ?>" class="z-logo">
                        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Zambit"
                             onerror="this.style.display='none';this.nextElementSibling.style.display='block'">
                        <span style="display:none;font-size:22px;font-weight:800;background:linear-gradient(135deg,#2E6DB4,#26A69A);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">
                            Zambit
                        </span>
                    </a>
                </div>

                <div class="col-12 col-lg-6 order-3 order-lg-2">
                    <form class="z-search" action="<?php echo e(url('/shop')); ?>" method="GET">
                        <input type="text" name="q" placeholder="Search for products, brands and more..." autocomplete="off">
                        <button type="submit"><i class="bi bi-search"></i></button>
                    </form>
                </div>

                <div class="col-auto col-lg-4 order-2 order-lg-3 ms-auto">
                    <div class="z-header-actions">

                        <div class="dropdown d-none d-md-block">
                            <a href="#" class="z-action" data-bs-toggle="dropdown">
                                <i class="bi bi-person"></i>
                                <div class="z-action-text">
                                    <small><?php echo e(auth()->check() ? 'Hello,' : 'Hello, Guest'); ?></small>
                                    <strong><?php echo e(auth()->check() ? \Illuminate\Support\Str::limit(auth()->user()->name, 12) : 'Sign In'); ?></strong>
                                </div>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end z-dropdown">
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(auth()->user()->isCustomer()): ?>
                                        <li><a class="dropdown-item" href="<?php echo e(url('/customer/dashboard')); ?>"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
                                        <li><a class="dropdown-item" href="<?php echo e(url('/customer/orders')); ?>"><i class="bi bi-box-seam"></i> My Orders</a></li>
                                        <li><a class="dropdown-item" href="<?php echo e(url('/wishlist')); ?>"><i class="bi bi-heart"></i> Wishlist</a></li>
                                        <li><a class="dropdown-item" href="<?php echo e(url('/customer/profile')); ?>"><i class="bi bi-gear"></i> Settings</a></li>
                                    <?php else: ?>
                                        <li><a class="dropdown-item" href="<?php echo e(url('/admin/dashboard')); ?>"><i class="bi bi-speedometer"></i> Admin Panel</a></li>
                                        <li><a class="dropdown-item" href="<?php echo e(url('/agent/dashboard')); ?>"><i class="bi bi-people"></i> Agent Panel</a></li>
                                    <?php endif; ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <form action="<?php echo e(url('/logout')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button class="dropdown-item text-danger"><i class="bi bi-box-arrow-right"></i> Logout</button>
                                        </form>
                                    </li>
                                <?php else: ?>
                                    <li><a class="dropdown-item" href="<?php echo e(url('/login')); ?>"><i class="bi bi-box-arrow-in-right"></i> Login</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(url('/register')); ?>"><i class="bi bi-person-plus"></i> Create Account</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>

                        <a href="<?php echo e(url('/wishlist')); ?>" class="z-action d-none d-md-flex">
                            <i class="bi bi-heart"></i>
                            <span class="z-count" id="wishlistCount">0</span>
                            <div class="z-action-text">
                                <small>Wishlist</small>
                                <strong>My Items</strong>
                            </div>
                        </a>

                        <a href="<?php echo e(url('/cart')); ?>" class="z-action z-action-cart">
                            <i class="bi bi-bag"></i>
                            <span class="z-count" id="cartCount">0</span>
                            <div class="z-action-text d-none d-md-block">
                                <small>My Cart</small>
                                <strong id="cartTotalHeader">₹0</strong>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Nav -->
    <div class="z-navbar d-none d-lg-block">
        <div class="container d-flex align-items-center">

            <div class="z-allcat dropdown">
                <button class="z-allcat-btn" data-bs-toggle="dropdown">
                    <i class="bi bi-grid-3x3-gap-fill"></i> All Categories
                </button>
                <ul class="dropdown-menu z-megamenu">
                    <?php $__currentLoopData = \App\Models\Category::with('children')->whereNull('parent_id')->where('status','active')->take(10)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="z-mm-parent">
                            <a href="<?php echo e(url('/shop?category='.$cat->id)); ?>">
                                <i class="bi bi-chevron-right"></i> <?php echo e($cat->name); ?>

                            </a>
                            <?php if($cat->children->count()): ?>
                                <ul class="z-mm-sub">
                                    <?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(url('/shop?category='.$sub->id)); ?>"><?php echo e($sub->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <nav class="z-mainnav">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/shop')); ?>">Shop</a>
                <a href="<?php echo e(url('/shop?filter=trending')); ?>">Trending</a>
                <a href="<?php echo e(url('/shop?filter=new')); ?>">New Arrivals</a>
                <a href="<?php echo e(url('/shop?filter=best')); ?>">Best Sellers</a>
                <a href="<?php echo e(url('/shop?filter=deals')); ?>" class="text-danger">
                    <i class="bi bi-fire"></i> Deals
                </a>
            </nav>

            <div class="ms-auto z-nav-offer">
                <i class="bi bi-lightning-charge-fill"></i>
                Free shipping above ₹999
            </div>
        </div>
    </div>
</header>

<!-- Mobile Menu -->
<div class="offcanvas offcanvas-start z-offcanvas" tabindex="-1" id="mobileMenu">
    <div class="offcanvas-header">
        <span style="font-size:20px;font-weight:800;background:linear-gradient(135deg,#2E6DB4,#26A69A);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">
            Zambit
        </span>
        <button class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body p-0">
        <?php if(auth()->guard()->check()): ?>
            <div class="z-mobile-user">
                <div class="z-mu-avatar"><?php echo e(strtoupper(substr(auth()->user()->name,0,1))); ?></div>
                <div>
                    <strong><?php echo e(auth()->user()->name); ?></strong>
                    <small><?php echo e(auth()->user()->email); ?></small>
                </div>
            </div>
        <?php endif; ?>

        <ul class="z-mobile-menu">
            <li><a href="<?php echo e(url('/')); ?>"><i class="bi bi-house"></i> Home</a></li>
            <li><a href="<?php echo e(url('/shop')); ?>"><i class="bi bi-grid"></i> Shop</a></li>
            <li class="z-mm-heading">Categories</li>
            <?php $__currentLoopData = \App\Models\Category::whereNull('parent_id')->where('status','active')->take(8)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url('/shop?category='.$cat->id)); ?>"><i class="bi bi-tag"></i> <?php echo e($cat->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li class="z-mm-heading">More</li>
            <li><a href="<?php echo e(url('/shop?filter=deals')); ?>"><i class="bi bi-fire"></i> Deals</a></li>
            <li><a href="<?php echo e(url('/contact')); ?>"><i class="bi bi-headset"></i> Contact</a></li>
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->isCustomer()): ?>
                    <li><a href="<?php echo e(url('/customer/dashboard')); ?>"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
                <?php endif; ?>
                <li>
                    <form action="<?php echo e(url('/logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="z-mobile-logout"><i class="bi bi-box-arrow-right"></i> Logout</button>
                    </form>
                </li>
            <?php else: ?>
                <li><a href="<?php echo e(url('/login')); ?>" class="text-primary fw-semibold"><i class="bi bi-box-arrow-in-right"></i> Login / Register</a></li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH /home/mdehsan/zambit-store/resources/views/partials/header.blade.php ENDPATH**/ ?>