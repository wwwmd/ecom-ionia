<?php $__env->startSection('title', 'My Leads'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i><span>My Leads</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <div>
        <h1>My Leads</h1>
        <p><?php echo e($leads->total()); ?> leads assigned to you</p>
    </div>
</div>

<div class="z-card">
    <div class="table-responsive">
        <table class="table z-table">
            <thead>
                <tr><th>Code</th><th>Lead</th><th>Phone</th><th>Priority</th><th>Status</th><th>Follow-up</th><th></th></tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><strong><?php echo e($lead->lead_code); ?></strong></td>
                    <td>
                        <div class="z-user-cell">
                            <div class="z-uc-avatar"><?php echo e(strtoupper(substr($lead->name,0,1))); ?></div>
                            <div><strong><?php echo e($lead->name); ?></strong><small><?php echo e($lead->email); ?></small></div>
                        </div>
                    </td>
                    <td><?php echo e($lead->phone); ?></td>
                    <td><span class="z-priority z-priority-<?php echo e($lead->priority); ?>"><?php echo e($lead->priority); ?></span></td>
                    <td><span class="z-status z-status-<?php echo e($lead->status); ?>"><?php echo e(ucfirst($lead->status)); ?></span></td>
                    <td><?php echo e($lead->followup_date ? $lead->followup_date->format('d M') : '—'); ?></td>
                    <td><a href="<?php echo e(route('agent.leads.show', $lead)); ?>" class="z-act-btn"><i class="bi bi-eye"></i></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center py-5 text-muted">No leads assigned</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-3 d-flex justify-content-center">
        <?php echo e($leads->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/store/resources/views/agent/leads/index.blade.php ENDPATH**/ ?>