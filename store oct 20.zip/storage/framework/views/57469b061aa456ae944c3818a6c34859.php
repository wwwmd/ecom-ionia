<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['value' => 0, 'count' => 0]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['value' => 0, 'count' => 0]); ?>
<?php foreach (array_filter((['value' => 0, 'count' => 0]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="z-rating">
    <?php for($i = 1; $i <= 5; $i++): ?>
        <?php if($i <= floor($value)): ?>
            <i class="bi bi-star-fill"></i>
        <?php elseif($i - 0.5 <= $value): ?>
            <i class="bi bi-star-half"></i>
        <?php else: ?>
            <i class="bi bi-star"></i>
        <?php endif; ?>
    <?php endfor; ?>
    <?php if($count): ?>
        <span>(<?php echo e($count); ?>)</span>
    <?php endif; ?>
</div>
<?php /**PATH /var/www/html/store/resources/views/components/rating.blade.php ENDPATH**/ ?>