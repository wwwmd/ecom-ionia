<?php $__env->startSection('title', 'My Dashboard — Zambit Store'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row g-4">
        <aside class="col-lg-3">
            <div class="z-account-nav">
                <div class="z-account-user">
                    <div class="z-au-avatar"><?php echo e(strtoupper(substr(auth()->user()->name,0,1))); ?></div>
                    <div>
                        <strong><?php echo e(auth()->user()->name); ?></strong>
                        <small><?php echo e(auth()->user()->email); ?></small>
                    </div>
                </div>
                <a href="<?php echo e(url('/customer/dashboard')); ?>" class="active"><i class="bi bi-speedometer2"></i> Dashboard</a>
                <a href="<?php echo e(url('/customer/orders')); ?>"><i class="bi bi-box-seam"></i> My Orders</a>
                <a href="<?php echo e(url('/wishlist')); ?>"><i class="bi bi-heart"></i> Wishlist</a>
                <a href="<?php echo e(url('/customer/profile')); ?>"><i class="bi bi-gear"></i> Profile Settings</a>
                <form action="<?php echo e(url('/logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="z-logout-link"><i class="bi bi-box-arrow-right"></i> Logout</button>
                </form>
            </div>
        </aside>

        <div class="col-lg-9">
            <h1 class="z-page-title">Welcome back, <?php echo e(auth()->user()->name); ?> 👋</h1>

            <div class="row g-3 mb-4">
                <?php
                    $stats = [
                        ['Total Orders', $stats['total'], 'bi-bag-check', 'blue'],
                        ['Pending', $stats['pending'], 'bi-hourglass-split', 'orange'],
                        ['Completed', $stats['completed'], 'bi-check2-circle', 'green'],
                        ['Cancelled', $stats['cancelled'], 'bi-x-circle', 'red'],
                    ];
                ?>
                <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-lg-3">
                    <div class="z-mini-stat">
                        <div class="z-ms-icon z-ms-<?php echo e($s[3]); ?>"><i class="bi <?php echo e($s[2]); ?>"></i></div>
                        <div>
                            <span><?php echo e($s[0]); ?></span>
                            <strong><?php echo e($s[1]); ?></strong>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="z-card">
                <h5>Recent Orders</h5>
                <div class="table-responsive">
                    <table class="table z-table">
                        <thead>
                            <tr><th>Order #</th><th>Date</th><th>Total</th><th>Status</th><th></th></tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><strong><?php echo e($o->order_number); ?></strong></td>
                                <td><?php echo e($o->created_at->format('d M Y')); ?></td>
                                <td>₹<?php echo e(number_format($o->grand_total)); ?></td>
                                <td><span class="z-status z-status-<?php echo e($o->status); ?>"><?php echo e(ucfirst($o->status)); ?></span></td>
                                <td><a href="<?php echo e(url('/customer/orders/'.$o->id)); ?>" class="z-link">View</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="text-center text-muted py-4">No orders yet</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/customer/dashboard.blade.php ENDPATH**/ ?>