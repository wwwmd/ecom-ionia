<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i><span>Dashboard</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <div>
        <h1>Welcome back, <?php echo e(auth()->user()->name); ?> 👋</h1>
        <p>Here's what's happening with your store today.</p>
    </div>
    <div class="z-page-head-actions">
        <a href="<?php echo e(route('admin.products.create')); ?>" class="z-btn-primary">
            <i class="bi bi-plus-lg"></i> Add Product
        </a>
    </div>
</div>

<!-- KPI Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="z-kpi z-kpi-blue">
            <div class="z-kpi-top">
                <div class="z-kpi-icon"><i class="bi bi-currency-rupee"></i></div>
            </div>
            <div class="z-kpi-value">₹<?php echo e(number_format($stats['revenue'], 0)); ?></div>
            <div class="z-kpi-label">Total Revenue</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="z-kpi z-kpi-teal">
            <div class="z-kpi-top">
                <div class="z-kpi-icon"><i class="bi bi-bag-check"></i></div>
            </div>
            <div class="z-kpi-value"><?php echo e(number_format($stats['orders'])); ?></div>
            <div class="z-kpi-label">Total Orders</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="z-kpi z-kpi-purple">
            <div class="z-kpi-top">
                <div class="z-kpi-icon"><i class="bi bi-people"></i></div>
            </div>
            <div class="z-kpi-value"><?php echo e(number_format($stats['customers'])); ?></div>
            <div class="z-kpi-label">Customers</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="z-kpi z-kpi-orange">
            <div class="z-kpi-top">
                <div class="z-kpi-icon"><i class="bi bi-funnel"></i></div>
            </div>
            <div class="z-kpi-value"><?php echo e(number_format($stats['leads'])); ?></div>
            <div class="z-kpi-label">Active Leads</div>
        </div>
    </div>
</div>

<!-- Mini Stats -->
<div class="row g-3 mb-4">
    <?php
        $mini = [
            ['Today\'s Sales', '₹'.number_format($stats['today'],0), 'bi-cart-check', 'blue'],
            ['Pending Orders', $stats['pending'], 'bi-hourglass-split', 'orange'],
            ['Completed', $stats['completed'], 'bi-check2-circle', 'green'],
            ['Cancelled', $stats['cancelled'], 'bi-x-circle', 'red'],
            ['Total Agents', $stats['agents'], 'bi-person-badge', 'purple'],
            ['Today Follow-ups', $stats['followups'], 'bi-calendar-check', 'teal'],
            ['Products', number_format($stats['products']), 'bi-box-seam', 'blue'],
            ['Low Stock', $stats['low_stock'], 'bi-exclamation-triangle', 'red'],
        ];
    ?>
    <?php $__currentLoopData = $mini; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-6 col-md-4 col-lg-3">
        <div class="z-mini-stat">
            <div class="z-ms-icon z-ms-<?php echo e($m[3]); ?>"><i class="bi <?php echo e($m[2]); ?>"></i></div>
            <div>
                <span><?php echo e($m[0]); ?></span>
                <strong><?php echo e($m[1]); ?></strong>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- Charts -->
<div class="row g-3 mb-4">
    <div class="col-lg-8">
        <div class="z-card">
            <div class="z-card-head">
                <div>
                    <h5>Revenue Overview</h5>
                    <p>Monthly performance</p>
                </div>
            </div>
            <canvas id="revenueChart" height="90"></canvas>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="z-card h-100">
            <div class="z-card-head"><h5>Order Status</h5></div>
            <canvas id="orderStatusChart" height="220"></canvas>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-lg-6">
        <div class="z-card">
            <div class="z-card-head"><h5>Customer Growth</h5></div>
            <canvas id="customerChart" height="120"></canvas>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="z-card">
            <div class="z-card-head"><h5>Lead Conversion</h5></div>
            <canvas id="leadChart" height="120"></canvas>
        </div>
    </div>
</div>

<!-- Recent Tables -->
<div class="row g-3">
    <div class="col-lg-7">
        <div class="z-card">
            <div class="z-card-head">
                <h5>Recent Orders</h5>
                <a href="<?php echo e(route('admin.orders')); ?>" class="z-link">View All <i class="bi bi-arrow-right"></i></a>
            </div>
            <div class="table-responsive">
                <table class="table z-table mb-0">
                    <thead>
                        <tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><strong>#<?php echo e($o->order_number); ?></strong></td>
                        <td><?php echo e($o->customer_name); ?></td>
                        <td><strong>₹<?php echo e(number_format($o->grand_total)); ?></strong></td>
                        <td><span class="z-status z-status-<?php echo e($o->status); ?>"><?php echo e(ucfirst($o->status)); ?></span></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="text-center text-muted py-4">No orders yet</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="z-card">
            <div class="z-card-head">
                <h5>Recent Leads</h5>
                <a href="<?php echo e(route('admin.leads')); ?>" class="z-link">View All <i class="bi bi-arrow-right"></i></a>
            </div>
            <div class="z-lead-list">
                <?php $__empty_1 = true; $__currentLoopData = $recentLeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="z-lead-item">
                    <div class="z-li-avatar"><?php echo e(strtoupper(substr($l->name,0,1))); ?></div>
                    <div class="z-li-info">
                        <strong><?php echo e($l->name); ?></strong>
                        <small><i class="bi bi-telephone"></i> <?php echo e($l->phone); ?></small>
                    </div>
                    <div class="z-li-tags">
                        <span class="z-priority z-priority-<?php echo e($l->priority); ?>"><?php echo e($l->priority); ?></span>
                        <span class="z-status z-status-<?php echo e($l->status); ?>"><?php echo e($l->status); ?></span>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center text-muted py-4">No leads yet</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
    new Chart(document.getElementById('revenueChart'), {
        type: 'line',
        data: {
            labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
            datasets: [{
                label: 'Revenue',
                data: [45,58,52,68,72,85,92,88,105,118,128,142].map(v => v*1000),
                borderColor: '#2E6DB4',
                backgroundColor: (ctx) => {
                    const g = ctx.chart.ctx.createLinearGradient(0, 0, 0, 300);
                    g.addColorStop(0, 'rgba(46,109,180,.25)');
                    g.addColorStop(1, 'rgba(38,166,154,0)');
                    return g;
                },
                fill: true, tension: .4, borderWidth: 3,
                pointBackgroundColor: '#fff', pointBorderColor: '#2E6DB4',
                pointBorderWidth: 3, pointRadius: 5
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, grid: { color: '#EEF2F7' }, ticks: { callback: v => '₹'+(v/1000)+'k' } },
                x: { grid: { display: false } }
            }
        }
    });

    new Chart(document.getElementById('orderStatusChart'), {
        type: 'doughnut',
        data: {
            labels: ['Delivered','Processing','Shipped','Pending','Cancelled'],
            datasets: [{
                data: [<?php echo e($stats['completed']); ?>, 20, 15, <?php echo e($stats['pending']); ?>, <?php echo e($stats['cancelled']); ?>],
                backgroundColor: ['#16A34A','#2E6DB4','#6366F1','#F59E0B','#DC2626'],
                borderWidth: 0, hoverOffset: 8
            }]
        },
        options: { cutout: '72%', plugins: { legend: { position: 'bottom', labels: { boxWidth: 10 } } } }
    });

    new Chart(document.getElementById('customerChart'), {
        type: 'bar',
        data: {
            labels: ['Jan','Feb','Mar','Apr','May','Jun'],
            datasets: [{
                label: 'New Customers',
                data: [22,35,28,42,55,68],
                backgroundColor: '#26A69A',
                borderRadius: 8, barThickness: 28
            }]
        },
        options: {
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, grid: { color: '#EEF2F7' } }, x: { grid: { display: false } } }
        }
    });

    new Chart(document.getElementById('leadChart'), {
        type: 'bar',
        data: {
            labels: ['New','Contacted','Interested','Negotiation','Converted','Lost'],
            datasets: [{
                data: [24,18,12,8,42,11],
                backgroundColor: ['#2E6DB4','#3B82F6','#8B5CF6','#F59E0B','#16A34A','#DC2626'],
                borderRadius: 6, barThickness: 24
            }]
        },
        options: {
            plugins: { legend: { display: false } },
            scales: { x: { beginAtZero: true, grid: { color: '#EEF2F7' } }, y: { grid: { display: false } } }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/store/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>