<?php $__env->startSection('title', 'Add Product'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i>
    <a href="<?php echo e(route('admin.products')); ?>">Products</a>
    <i class="bi bi-chevron-right"></i><span>Add New</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <div>
        <h1>Add New Product</h1>
        <p>Fill in the details below</p>
    </div>
    <a href="<?php echo e(route('admin.products')); ?>" class="z-btn-ghost">
        <i class="bi bi-arrow-left"></i> Back
    </a>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Fix these errors:</strong>
        <ul class="mb-0 mt-2 ps-3">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($err); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('admin.products.store')); ?>" method="POST" enctype="multipart/form-data" id="productForm">
    <?php echo csrf_field(); ?>

    <div class="row g-3">
        <div class="col-lg-8">

            <div class="z-card mb-3">
                <h5><i class="bi bi-info-circle me-2"></i>Basic Information</h5>
                <div class="row g-3">
                    <div class="col-12">
                        <label>Product Name *</label>
                        <input type="text" name="name" class="z-input" value="<?php echo e(old('name')); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label>SKU (auto if empty)</label>
                        <input type="text" name="sku" class="z-input" value="<?php echo e(old('sku')); ?>" placeholder="SKU-XXXX">
                    </div>
                    <div class="col-md-6">
                        <label>Product Type *</label>
                        <select name="type" id="productType" class="z-select w-100" required>
                            <option value="simple" <?php if(old('type') == 'simple'): echo 'selected'; endif; ?>>Simple</option>
                            <option value="variable" <?php if(old('type') == 'variable'): echo 'selected'; endif; ?>>Variable</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label>Status *</label>
                        <select name="status" class="z-select w-100" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="draft">Draft</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label>Short Description</label>
                        <textarea name="short_description" class="z-input" rows="2"><?php echo e(old('short_description')); ?></textarea>
                    </div>
                    <div class="col-12">
                        <label>Full Description</label>
                        <textarea name="description" class="z-input" rows="5"><?php echo e(old('description')); ?></textarea>
                    </div>
                </div>
            </div>

            <div class="z-card mb-3">
                <h5><i class="bi bi-currency-rupee me-2"></i>Pricing</h5>
                <div class="row g-3">
                    <div class="col-md-4"><label>Regular Price *</label><input type="number" step="0.01" name="price" class="z-input" value="<?php echo e(old('price')); ?>" required></div>
                    <div class="col-md-4"><label>Compare Price</label><input type="number" step="0.01" name="compare_price" class="z-input" value="<?php echo e(old('compare_price')); ?>"></div>
                    <div class="col-md-4"><label>Cost Price</label><input type="number" step="0.01" name="cost_price" class="z-input" value="<?php echo e(old('cost_price')); ?>"></div>
                    <div class="col-md-4">
                        <label>Discount Type</label>
                        <select name="discount_type" class="z-select w-100">
                            <option value="none">None</option>
                            <option value="fixed">Fixed</option>
                            <option value="percent">Percent</option>
                        </select>
                    </div>
                    <div class="col-md-4"><label>Discount Value</label><input type="number" step="0.01" name="discount_value" class="z-input" value="0"></div>
                    <div class="col-md-4"><label>Tax Rate (%)</label><input type="number" step="0.01" name="tax_rate" class="z-input" value="18"></div>
                </div>
            </div>

            <div class="z-card mb-3">
                <h5><i class="bi bi-boxes me-2"></i>Inventory</h5>
                <div class="row g-3">
                    <div class="col-md-4"><label>Stock *</label><input type="number" name="stock" class="z-input" value="<?php echo e(old('stock', 0)); ?>" required></div>
                    <div class="col-md-4"><label>Low Stock Alert</label><input type="number" name="low_stock_alert" class="z-input" value="5"></div>
                    <div class="col-md-4">
                        <label>&nbsp;</label>
                        <div class="form-check form-switch mt-2">
                            <input class="form-check-input" type="checkbox" name="manage_stock" value="1" checked>
                            <label class="form-check-label">Manage Stock</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="z-card mb-3">
                <h5><i class="bi bi-truck me-2"></i>Shipping</h5>
                <div class="row g-3">
                    <div class="col-md-3"><label>Weight (kg)</label><input type="number" step="0.01" name="weight" class="z-input"></div>
                    <div class="col-md-3"><label>Length (cm)</label><input type="number" step="0.01" name="length" class="z-input"></div>
                    <div class="col-md-3"><label>Width (cm)</label><input type="number" step="0.01" name="width" class="z-input"></div>
                    <div class="col-md-3"><label>Height (cm)</label><input type="number" step="0.01" name="height" class="z-input"></div>
                </div>
            </div>

            <div class="z-card mb-3">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0"><i class="bi bi-list-check me-2"></i>Specifications</h5>
                    <button type="button" class="z-btn-ghost btn-sm" id="addSpec"><i class="bi bi-plus-lg"></i> Add</button>
                </div>
                <div id="specsWrap">
                    <div class="spec-row row g-2 mb-2">
                        <div class="col-5"><input type="text" name="specifications[0][key]" class="z-input" placeholder="e.g. Color"></div>
                        <div class="col-6"><input type="text" name="specifications[0][value]" class="z-input" placeholder="e.g. Black"></div>
                        <div class="col-1"><button type="button" class="z-act-btn text-danger remove-spec"><i class="bi bi-trash"></i></button></div>
                    </div>
                </div>
            </div>

            <div class="z-card mb-3">
                <h5><i class="bi bi-sliders me-2"></i>Attributes</h5>
                <?php $__empty_1 = true; $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="mb-3">
                        <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px"><?php echo e($attr->name); ?></label>
                        <div style="display:flex;flex-wrap:wrap;gap:12px">
                            <?php $__currentLoopData = $attr->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="z-check">
                                    <input type="checkbox" name="attributes[<?php echo e($attr->id); ?>][]" value="<?php echo e($val->id); ?>">
                                    <span><?php echo e($val->value); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted mb-0">No attributes yet.</p>
                <?php endif; ?>
            </div>

            <div class="z-card mb-3">
                <h5><i class="bi bi-search me-2"></i>SEO</h5>
                <div class="row g-3">
                    <div class="col-12"><label>Meta Title</label><input type="text" name="meta_title" class="z-input"></div>
                    <div class="col-12"><label>Meta Description</label><textarea name="meta_description" class="z-input" rows="2"></textarea></div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="z-card mb-3">
                <h5><i class="bi bi-image me-2"></i>Thumbnail</h5>
                <div class="z-upload-zone" id="thumbDrop">
                    <input type="file" name="thumbnail" id="thumbInput" accept="image/*" hidden>
                    <i class="bi bi-cloud-upload"></i>
                    <strong>Click to upload</strong>
                    <small>PNG, JPG, WEBP · max 2MB</small>
                </div>
                <div id="thumbPreview" class="mt-2"></div>
            </div>

            <div class="z-card mb-3">
                <h5><i class="bi bi-images me-2"></i>Gallery</h5>
                <div class="z-upload-zone" id="galleryDrop">
                    <input type="file" name="gallery[]" id="galleryInput" accept="image/*" multiple hidden>
                    <i class="bi bi-images"></i>
                    <strong>Add up to 8 images</strong>
                </div>
                <div id="galleryPreview" class="mt-2" style="display:flex;flex-wrap:wrap;gap:8px"></div>
            </div>

            <div class="z-card mb-3">
                <h5><i class="bi bi-tags me-2"></i>Organization</h5>
                <div class="mb-3">
                    <label style="font-size:13px;font-weight:600">Category *</label>
                    <select name="category_id" class="z-select w-100" required>
                        <option value="">-- Select --</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <optgroup label="<?php echo e($cat->name); ?>">
                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                <?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($child->id); ?>">— <?php echo e($child->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label style="font-size:13px;font-weight:600">Brand</label>
                    <select name="brand_id" class="z-select w-100">
                        <option value="">-- Select --</option>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($b->id); ?>"><?php echo e($b->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="z-card mb-3">
                <h5><i class="bi bi-star me-2"></i>Flags</h5>
                <div class="z-check-group">
                    <label class="z-check"><input type="checkbox" name="is_featured" value="1"> Featured</label>
                    <label class="z-check"><input type="checkbox" name="is_trending" value="1"> Trending</label>
                    <label class="z-check"><input type="checkbox" name="is_new_arrival" value="1"> New Arrival</label>
                    <label class="z-check"><input type="checkbox" name="is_best_seller" value="1"> Best Seller</label>
                </div>
            </div>

            <div class="z-card">
                <button type="submit" class="z-btn-primary w-100 mb-2">
                    <i class="bi bi-check2"></i> Save Product
                </button>
                <a href="<?php echo e(route('admin.products')); ?>" class="z-btn-ghost w-100 justify-content-center">Cancel</a>
            </div>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
    /* Thumbnail */
    $('#thumbDrop').on('click', () => $('#thumbInput').click());
    $('#thumbInput').on('change', function () {
        const f = this.files[0]; if (!f) return;
        const r = new FileReader();
        r.onload = e => $('#thumbPreview').html(`<img src="${e.target.result}" style="width:100%;border-radius:10px">`);
        r.readAsDataURL(f);
    });

    /* Gallery */
    $('#galleryDrop').on('click', () => $('#galleryInput').click());
    $('#galleryInput').on('change', function () {
        $('#galleryPreview').html('');
        [...this.files].slice(0, 8).forEach(f => {
            const r = new FileReader();
            r.onload = e => $('#galleryPreview').append(`<img src="${e.target.result}" style="width:60px;height:60px;object-fit:cover;border-radius:8px">`);
            r.readAsDataURL(f);
        });
    });

    /* Specifications */
    let specIdx = 1;
    $('#addSpec').on('click', function () {
        $('#specsWrap').append(`
            <div class="spec-row row g-2 mb-2">
                <div class="col-5"><input type="text" name="specifications[${specIdx}][key]" class="z-input" placeholder="Key"></div>
                <div class="col-6"><input type="text" name="specifications[${specIdx}][value]" class="z-input" placeholder="Value"></div>
                <div class="col-1"><button type="button" class="z-act-btn text-danger remove-spec"><i class="bi bi-trash"></i></button></div>
            </div>
        `);
        specIdx++;
    });

    $(document).on('click', '.remove-spec', function () {
        $(this).closest('.spec-row').remove();
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/admin/products/create.blade.php ENDPATH**/ ?>