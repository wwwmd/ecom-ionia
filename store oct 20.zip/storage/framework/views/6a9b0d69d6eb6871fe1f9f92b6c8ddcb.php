<?php $__env->startSection('title', 'Profile Settings — Zambit Store'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row g-4">
        <aside class="col-lg-3">
            <div class="z-account-nav">
                <div class="z-account-user">
                    <div class="z-au-avatar"><?php echo e(strtoupper(substr(auth()->user()->name,0,1))); ?></div>
                    <div>
                        <strong><?php echo e(auth()->user()->name); ?></strong>
                        <small><?php echo e(auth()->user()->email); ?></small>
                    </div>
                </div>
                <a href="<?php echo e(url('/customer/dashboard')); ?>"><i class="bi bi-speedometer2"></i> Dashboard</a>
                <a href="<?php echo e(url('/customer/orders')); ?>"><i class="bi bi-box-seam"></i> My Orders</a>
                <a href="<?php echo e(url('/wishlist')); ?>"><i class="bi bi-heart"></i> Wishlist</a>
                <a href="<?php echo e(url('/customer/profile')); ?>" class="active"><i class="bi bi-gear"></i> Profile</a>
            </div>
        </aside>

        <div class="col-lg-9">
            <h1 class="z-page-title">Profile Settings</h1>

            <div class="z-card mb-3">
                <h5>Profile Information</h5>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label>Full Name</label>
                        <input type="text" class="z-input" value="<?php echo e(auth()->user()->name); ?>" readonly>
                    </div>
                    <div class="col-md-6">
                        <label>Email</label>
                        <input type="email" class="z-input" value="<?php echo e(auth()->user()->email); ?>" readonly>
                    </div>
                    <div class="col-md-6">
                        <label>Phone</label>
                        <input type="text" class="z-input" value="<?php echo e(auth()->user()->phone ?? '—'); ?>" readonly>
                    </div>
                    <div class="col-md-6">
                        <label>Member Since</label>
                        <input type="text" class="z-input" value="<?php echo e(auth()->user()->created_at->format('d M Y')); ?>" readonly>
                    </div>
                </div>
                <p class="text-muted mt-3 mb-0" style="font-size:13px">
                    <i class="bi bi-info-circle"></i> Profile editing coming soon.
                </p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/customer/profile.blade.php ENDPATH**/ ?>