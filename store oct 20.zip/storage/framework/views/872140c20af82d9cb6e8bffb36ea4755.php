<?php
    $menu = [
        ['label'=>'Dashboard','icon'=>'bi-speedometer2','url'=>url('/admin/dashboard'),'match'=>'admin/dashboard'],
        ['heading'=>'Commerce'],
        ['label'=>'Orders','icon'=>'bi-bag-check','url'=>url('/admin/orders'),'match'=>'admin/orders'],
        ['label'=>'Products','icon'=>'bi-box-seam','url'=>url('/admin/products'),'match'=>'admin/products'],
        ['label'=>'Customers','icon'=>'bi-people','url'=>url('/admin/customers'),'match'=>'admin/customers'],
        ['heading'=>'CRM'],
        ['label'=>'Leads','icon'=>'bi-funnel','url'=>url('/admin/crm/leads'),'match'=>'admin/crm/leads'],
        ['label'=>'Follow-ups','icon'=>'bi-calendar-check','url'=>url('/admin/crm/followups'),'match'=>'admin/crm/followups'],
        ['heading'=>'People'],
        ['label'=>'Agents','icon'=>'bi-person-badge','url'=>url('/admin/customers'),'match'=>'admin/agents'],
        ['heading'=>'System'],
        ['label'=>'Settings','icon'=>'bi-gear','url'=>url('/admin/settings'),'match'=>'admin/settings'],
        ['label'=>'Activity Logs','icon'=>'bi-clock-history','url'=>url('/admin/logs'),'match'=>'admin/logs'],
    ];
?>

<aside class="z-sidebar" id="zSidebar">
    <div class="z-sb-brand">
        <a href="<?php echo e(url('/admin/dashboard')); ?>">
            <span class="z-sb-brand-text">Zambit<span>Admin</span></span>
        </a>
        <button class="z-sb-close d-lg-none" id="closeSidebar"><i class="bi bi-x-lg"></i></button>
    </div>

    <nav class="z-sb-nav">
        <ul>
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($item['heading'])): ?>
                    <li class="z-sb-heading"><?php echo e($item['heading']); ?></li>
                <?php else: ?>
                    <?php $isActive = request()->is($item['match'].'*'); ?>
                    <li>
                        <a href="<?php echo e($item['url']); ?>" class="z-sb-link <?php echo e($isActive ? 'active' : ''); ?>">
                            <i class="bi <?php echo e($item['icon']); ?>"></i>
                            <span><?php echo e($item['label']); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </nav>

    <div class="z-sb-footer">
        <div class="z-sb-user">
            <div class="z-sb-avatar"><?php echo e(strtoupper(substr(auth()->user()->name ?? 'A', 0, 1))); ?></div>
            <div>
                <strong><?php echo e(auth()->user()->name ?? 'Admin'); ?></strong>
                <small><?php echo e(auth()->user()->role->name ?? 'Super Admin'); ?></small>
            </div>
        </div>
        <form action="<?php echo e(url('/logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button class="z-sb-logout"><i class="bi bi-box-arrow-right"></i> Logout</button>
        </form>
    </div>
</aside>

<div class="z-sb-backdrop" id="sbBackdrop"></div>
<?php /**PATH /home/mdehsan/zambit-store/resources/views/partials/admin-sidebar.blade.php ENDPATH**/ ?>