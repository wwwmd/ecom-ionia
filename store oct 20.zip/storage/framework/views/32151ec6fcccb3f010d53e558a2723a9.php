<?php $__env->startSection('title', 'Sign In — Zambit Store'); ?>

<?php $__env->startSection('content'); ?>
<section class="z-auth-page">
    <div class="z-auth-bg"></div>
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-lg-10">
                <div class="z-auth-card">
                    <div class="row g-0">

                        <div class="col-lg-5 z-auth-left d-none d-lg-flex">
                            <div class="z-auth-left-content">
                                <span style="font-size:32px;font-weight:800;color:#fff;">Zambit</span>
                                <h2 class="mt-3">Welcome Back 👋</h2>
                                <p>Sign in to access your dashboard, orders, wishlist and exclusive member deals.</p>
                                <ul class="z-auth-benefits">
                                    <li><i class="bi bi-check-circle-fill"></i> Fast checkout & saved addresses</li>
                                    <li><i class="bi bi-check-circle-fill"></i> Track orders in real time</li>
                                    <li><i class="bi bi-check-circle-fill"></i> Member-only offers & coupons</li>
                                    <li><i class="bi bi-check-circle-fill"></i> Priority customer support</li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-7">
                            <div class="z-auth-form-wrap">
                                <div class="z-auth-head">
                                    <h3>Sign In</h3>
                                    <p>One login for Customers, Agents & Admins</p>
                                </div>

                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger py-2"><?php echo e(session('error')); ?></div>
                                <?php endif; ?>
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success py-2"><?php echo e(session('status')); ?></div>
                                <?php endif; ?>

                                <form method="POST" action="<?php echo e(url('/login')); ?>" class="z-auth-form">
                                    <?php echo csrf_field(); ?>

                                    <div class="z-field">
                                        <label>Email address</label>
                                        <div class="z-input-wrap">
                                            <i class="bi bi-envelope"></i>
                                            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="you@example.com">
                                        </div>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger d-block mt-1"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="z-field">
                                        <label>Password</label>
                                        <div class="z-input-wrap">
                                            <i class="bi bi-lock"></i>
                                            <input type="password" name="password" id="password" required placeholder="Enter your password">
                                            <button type="button" class="z-eye" onclick="togglePwd(this)"><i class="bi bi-eye"></i></button>
                                        </div>
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-danger d-block mt-1"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                                        <label class="z-check">
                                            <input type="checkbox" name="remember"> <span>Remember me</span>
                                        </label>
                                        <a href="#" class="z-link">Forgot password?</a>
                                    </div>

                                    <button type="submit" class="z-btn-primary w-100">
                                        Sign In <i class="bi bi-arrow-right"></i>
                                    </button>
                                </form>

                                <p class="z-auth-foot">
                                    New to Zambit? <a href="<?php echo e(url('/register')); ?>">Create an account</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function togglePwd(btn) {
    const inp = document.getElementById('password');
    const icon = btn.querySelector('i');
    inp.type = inp.type === 'password' ? 'text' : 'password';
    icon.classList.toggle('bi-eye');
    icon.classList.toggle('bi-eye-slash');
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/auth/login.blade.php ENDPATH**/ ?>