<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i><span>Products</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <div>
        <h1>Products</h1>
        <p><?php echo e($products->total()); ?> products in catalog</p>
    </div>
    <div class="z-page-head-actions">
        <a href="<?php echo e(route('admin.products.create')); ?>" class="z-btn-primary">
            <i class="bi bi-plus-lg"></i> Add Product
        </a>
    </div>
</div>

<div class="z-card mb-3">
    <form method="GET" class="z-filters">
        <div class="z-fi">
            <label>Search</label>
            <input type="text" name="q" class="z-input" value="<?php echo e(request('q')); ?>" placeholder="Name or SKU...">
        </div>
        <div class="z-fi">
            <label>Category</label>
            <select name="category" class="z-select">
                <option value="">All</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>" <?php if(request('category') == $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="z-fi">
            <label>Status</label>
            <select name="status" class="z-select">
                <option value="">All</option>
                <option value="active" <?php if(request('status') == 'active'): echo 'selected'; endif; ?>>Active</option>
                <option value="inactive" <?php if(request('status') == 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
                <option value="draft" <?php if(request('status') == 'draft'): echo 'selected'; endif; ?>>Draft</option>
            </select>
        </div>
        <div class="z-fi z-fi-btn">
            <button class="z-btn-primary"><i class="bi bi-funnel"></i> Filter</button>
            <a href="<?php echo e(route('admin.products')); ?>" class="z-btn-ghost">Reset</a>
        </div>
    </form>
</div>

<div class="z-card">
    <div class="table-responsive">
        <table class="table z-table z-datatable">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>SKU</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Status</th>
                    <th width="140">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="z-user-cell">
                            <?php if($p->thumbnail): ?>
                                <img src="<?php echo e(asset($p->thumbnail)); ?>" style="width:38px;height:38px;border-radius:8px;object-fit:cover">
                            <?php else: ?>
                                <div class="z-uc-avatar" style="background:var(--z-light);color:var(--z-border)">
                                    <i class="bi bi-image"></i>
                                </div>
                            <?php endif; ?>
                            <div>
                                <strong><?php echo e(\Illuminate\Support\Str::limit($p->name, 32)); ?></strong>
                                <small><?php echo e($p->brand->name ?? '—'); ?></small>
                            </div>
                        </div>
                    </td>
                    <td><?php echo e($p->sku); ?></td>
                    <td><?php echo e($p->category->name ?? '—'); ?></td>
                    <td><strong>₹<?php echo e(number_format($p->price)); ?></strong></td>
                    <td>
                        <span class="z-stock <?php echo e($p->stock <= 5 ? 'low' : ''); ?>" style="padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600;<?php echo e($p->stock <= 5 ? 'background:#FEE2E2;color:#991B1B' : 'background:#D1FAE5;color:#065F46'); ?>">
                            <?php echo e($p->stock); ?>

                        </span>
                    </td>
                    <td>
                        <span class="z-status z-status-<?php echo e($p->status === 'active' ? 'delivered' : 'cancelled'); ?>">
                            <?php echo e(ucfirst($p->status)); ?>

                        </span>
                    </td>
                    <td>
                        <div class="z-actions">
                            <a href="<?php echo e(route('admin.products.show', $p)); ?>" class="z-act-btn"><i class="bi bi-eye"></i></a>
                            <a href="<?php echo e(route('admin.products.edit', $p)); ?>" class="z-act-btn"><i class="bi bi-pencil"></i></a>
                            <button class="z-act-btn text-danger delete-product" data-id="<?php echo e($p->id); ?>"><i class="bi bi-trash"></i></button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center py-5 text-muted">
                    <i class="bi bi-inbox" style="font-size:48px;opacity:.3;display:block;margin-bottom:12px"></i>
                    No products yet. <a href="<?php echo e(route('admin.products.create')); ?>">Add first product</a>
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-3 d-flex justify-content-center">
        <?php echo e($products->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
    $('.delete-product').on('click', function () {
        const id = $(this).data('id');
        zConfirm('Delete product?', 'This cannot be undone.', function () {
            $.ajax({
                url: '<?php echo e(url("/admin/products")); ?>/' + id,
                method: 'DELETE'
            }).done(() => {
                zToast('Product deleted', 'success');
                setTimeout(() => location.reload(), 700);
            }).fail(() => zToast('Delete failed', 'error'));
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/store/resources/views/admin/products/index.blade.php ENDPATH**/ ?>