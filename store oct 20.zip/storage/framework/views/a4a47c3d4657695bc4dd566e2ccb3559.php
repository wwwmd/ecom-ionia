<?php $__env->startSection('title', 'Customer Profile'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i>
    <a href="<?php echo e(route('admin.customers')); ?>">Customers</a>
    <i class="bi bi-chevron-right"></i><span><?php echo e($customer->name); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row g-3">
    <div class="col-lg-4">
        <div class="z-card text-center">
            <div class="z-uc-avatar" style="width:96px;height:96px;font-size:36px;margin:0 auto 16px">
                <?php echo e(strtoupper(substr($customer->name,0,1))); ?>

            </div>
            <h4 style="margin-bottom:4px"><?php echo e($customer->name); ?></h4>
            <p class="text-muted mb-2">Customer #C-<?php echo e(str_pad($customer->id,5,'0',STR_PAD_LEFT)); ?></p>
            <span class="z-status z-status-<?php echo e($customer->status === 'active' ? 'delivered' : 'cancelled'); ?>">
                <?php echo e(ucfirst($customer->status)); ?>

            </span>

            <div style="text-align:left;margin-top:20px;padding-top:20px;border-top:1px solid var(--z-border)">
                <div style="display:flex;gap:10px;margin-bottom:8px;font-size:13px"><i class="bi bi-envelope" style="color:var(--z-blue)"></i> <?php echo e($customer->email); ?></div>
                <div style="display:flex;gap:10px;margin-bottom:8px;font-size:13px"><i class="bi bi-telephone" style="color:var(--z-blue)"></i> <?php echo e($customer->phone ?? '—'); ?></div>
                <div style="display:flex;gap:10px;font-size:13px"><i class="bi bi-calendar" style="color:var(--z-blue)"></i> Joined <?php echo e($customer->created_at->format('d M Y')); ?></div>
            </div>

            <div class="row g-2 mt-3">
                <div class="col-6">
                    <div style="padding:14px;background:var(--z-light);border-radius:10px">
                        <strong style="font-size:20px;color:var(--z-dark)"><?php echo e($customer->customerProfile->total_orders ?? 0); ?></strong>
                        <div style="font-size:11px;color:var(--z-muted)">Orders</div>
                    </div>
                </div>
                <div class="col-6">
                    <div style="padding:14px;background:var(--z-light);border-radius:10px">
                        <strong style="font-size:20px;color:var(--z-dark)">₹<?php echo e(number_format(($customer->customerProfile->total_spent ?? 0)/1000, 0)); ?>k</strong>
                        <div style="font-size:11px;color:var(--z-muted)">Spent</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="z-card">
            <h5>Recent Orders</h5>
            <div class="table-responsive">
                <table class="table z-table">
                    <thead><tr><th>Order #</th><th>Date</th><th>Total</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $customer->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><strong><?php echo e($o->order_number); ?></strong></td>
                            <td><?php echo e($o->created_at->format('d M Y')); ?></td>
                            <td>₹<?php echo e(number_format($o->grand_total)); ?></td>
                            <td><span class="z-status z-status-<?php echo e($o->status); ?>"><?php echo e(ucfirst($o->status)); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="text-center text-muted py-4">No orders</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/admin/customers/show.blade.php ENDPATH**/ ?>