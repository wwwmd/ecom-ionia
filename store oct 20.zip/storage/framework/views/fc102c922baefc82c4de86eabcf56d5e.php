<?php $__env->startSection('title', 'Edit Product'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i>
    <a href="<?php echo e(route('admin.products')); ?>">Products</a>
    <i class="bi bi-chevron-right"></i><span>Edit</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <div>
        <h1>Edit: <?php echo e($product->name); ?></h1>
        <p>SKU: <?php echo e($product->sku); ?></p>
    </div>
    <a href="<?php echo e(route('admin.products')); ?>" class="z-btn-ghost">
        <i class="bi bi-arrow-left"></i> Back
    </a>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0 ps-3">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($err); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('admin.products.update', $product)); ?>" method="POST" enctype="multipart/form-data" id="productForm">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row g-3">
        <div class="col-lg-8">

            <div class="z-card mb-3">
                <h5>Basic Information</h5>
                <div class="row g-3">
                    <div class="col-12"><label>Name *</label><input type="text" name="name" class="z-input" value="<?php echo e(old('name', $product->name)); ?>" required></div>
                    <div class="col-md-6"><label>SKU</label><input type="text" name="sku" class="z-input" value="<?php echo e(old('sku', $product->sku)); ?>"></div>
                    <div class="col-md-6">
                        <label>Type *</label>
                        <select name="type" class="z-select w-100" required>
                            <option value="simple" <?php if($product->type == 'simple'): echo 'selected'; endif; ?>>Simple</option>
                            <option value="variable" <?php if($product->type == 'variable'): echo 'selected'; endif; ?>>Variable</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label>Status *</label>
                        <select name="status" class="z-select w-100" required>
                            <option value="active" <?php if($product->status == 'active'): echo 'selected'; endif; ?>>Active</option>
                            <option value="inactive" <?php if($product->status == 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
                            <option value="draft" <?php if($product->status == 'draft'): echo 'selected'; endif; ?>>Draft</option>
                        </select>
                    </div>
                    <div class="col-12"><label>Short Description</label><textarea name="short_description" class="z-input" rows="2"><?php echo e(old('short_description', $product->short_description)); ?></textarea></div>
                    <div class="col-12"><label>Description</label><textarea name="description" class="z-input" rows="5"><?php echo e(old('description', $product->description)); ?></textarea></div>
                </div>
            </div>

            <div class="z-card mb-3">
                <h5>Pricing</h5>
                <div class="row g-3">
                    <div class="col-md-4"><label>Price *</label><input type="number" step="0.01" name="price" class="z-input" value="<?php echo e(old('price', $product->price)); ?>" required></div>
                    <div class="col-md-4"><label>Compare Price</label><input type="number" step="0.01" name="compare_price" class="z-input" value="<?php echo e(old('compare_price', $product->compare_price)); ?>"></div>
                    <div class="col-md-4"><label>Cost Price</label><input type="number" step="0.01" name="cost_price" class="z-input" value="<?php echo e(old('cost_price', $product->cost_price)); ?>"></div>
                    <div class="col-md-4"><label>Discount Type</label>
                        <select name="discount_type" class="z-select w-100">
                            <?php $__currentLoopData = ['none','fixed','percent']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($t); ?>" <?php if($product->discount_type == $t): echo 'selected'; endif; ?>><?php echo e(ucfirst($t)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4"><label>Discount Value</label><input type="number" step="0.01" name="discount_value" class="z-input" value="<?php echo e($product->discount_value); ?>"></div>
                    <div class="col-md-4"><label>Tax Rate</label><input type="number" step="0.01" name="tax_rate" class="z-input" value="<?php echo e($product->tax_rate); ?>"></div>
                </div>
            </div>

            <div class="z-card mb-3">
                <h5>Inventory</h5>
                <div class="row g-3">
                    <div class="col-md-4"><label>Stock *</label><input type="number" name="stock" class="z-input" value="<?php echo e($product->stock); ?>" required></div>
                    <div class="col-md-4"><label>Low Stock Alert</label><input type="number" name="low_stock_alert" class="z-input" value="<?php echo e($product->low_stock_alert); ?>"></div>
                    <div class="col-md-4">
                        <label>&nbsp;</label>
                        <div class="form-check form-switch mt-2">
                            <input class="form-check-input" type="checkbox" name="manage_stock" value="1" <?php if($product->manage_stock): echo 'checked'; endif; ?>>
                            <label class="form-check-label">Manage Stock</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="z-card mb-3">
                <h5>Shipping</h5>
                <div class="row g-3">
                    <div class="col-md-3"><label>Weight</label><input type="number" step="0.01" name="weight" class="z-input" value="<?php echo e($product->weight); ?>"></div>
                    <div class="col-md-3"><label>Length</label><input type="number" step="0.01" name="length" class="z-input" value="<?php echo e($product->length); ?>"></div>
                    <div class="col-md-3"><label>Width</label><input type="number" step="0.01" name="width" class="z-input" value="<?php echo e($product->width); ?>"></div>
                    <div class="col-md-3"><label>Height</label><input type="number" step="0.01" name="height" class="z-input" value="<?php echo e($product->height); ?>"></div>
                </div>
            </div>

            <div class="z-card mb-3">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">Specifications</h5>
                    <button type="button" class="z-btn-ghost btn-sm" id="addSpec"><i class="bi bi-plus-lg"></i> Add</button>
                </div>
                <div id="specsWrap">
                    <?php $specs = $product->specifications ?? []; $sIdx = 0; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="spec-row row g-2 mb-2">
                            <div class="col-5"><input type="text" name="specifications[<?php echo e($sIdx); ?>][key]" class="z-input" value="<?php echo e($key); ?>"></div>
                            <div class="col-6"><input type="text" name="specifications[<?php echo e($sIdx); ?>][value]" class="z-input" value="<?php echo e($value); ?>"></div>
                            <div class="col-1"><button type="button" class="z-act-btn text-danger remove-spec"><i class="bi bi-trash"></i></button></div>
                        </div>
                        <?php $sIdx++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="spec-row row g-2 mb-2">
                            <div class="col-5"><input type="text" name="specifications[0][key]" class="z-input"></div>
                            <div class="col-6"><input type="text" name="specifications[0][value]" class="z-input"></div>
                            <div class="col-1"><button type="button" class="z-act-btn text-danger remove-spec"><i class="bi bi-trash"></i></button></div>
                        </div>
                        <?php $sIdx = 1; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="z-card mb-3">
                <h5>Attributes</h5>
                <?php $selectedAttrValues = $product->attributeValues->pluck('id')->toArray(); ?>
                <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-3">
                        <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px"><?php echo e($attr->name); ?></label>
                        <div style="display:flex;flex-wrap:wrap;gap:12px">
                            <?php $__currentLoopData = $attr->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="z-check">
                                    <input type="checkbox" name="attributes[<?php echo e($attr->id); ?>][]" value="<?php echo e($val->id); ?>" <?php if(in_array($val->id, $selectedAttrValues)): echo 'checked'; endif; ?>>
                                    <span><?php echo e($val->value); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="z-card mb-3">
                <h5>SEO</h5>
                <div class="row g-3">
                    <div class="col-12"><label>Meta Title</label><input type="text" name="meta_title" class="z-input" value="<?php echo e($product->meta_title); ?>"></div>
                    <div class="col-12"><label>Meta Description</label><textarea name="meta_description" class="z-input" rows="2"><?php echo e($product->meta_description); ?></textarea></div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="z-card mb-3">
                <h5>Thumbnail</h5>
                <?php if($product->thumbnail): ?>
                    <img src="<?php echo e(asset($product->thumbnail)); ?>" style="width:100%;border-radius:10px;margin-bottom:10px">
                <?php endif; ?>
                <div class="z-upload-zone" id="thumbDrop">
                    <input type="file" name="thumbnail" id="thumbInput" accept="image/*" hidden>
                    <i class="bi bi-cloud-upload"></i>
                    <strong><?php echo e($product->thumbnail ? 'Replace' : 'Upload'); ?></strong>
                </div>
                <div id="thumbPreview" class="mt-2"></div>
            </div>

            <div class="z-card mb-3">
                <h5>Gallery</h5>
                <?php if($product->images->count()): ?>
                    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px">
                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div style="position:relative;width:64px;height:64px;border-radius:8px;overflow:hidden;border:1px solid var(--z-border)">
                                <img src="<?php echo e(asset($img->path)); ?>" style="width:100%;height:100%;object-fit:cover">
                                <label style="position:absolute;top:2px;right:2px;background:rgba(220,38,38,.85);width:18px;height:18px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:11px;cursor:pointer">
                                    <input type="checkbox" name="remove_images[]" value="<?php echo e($img->id); ?>" style="display:none" onchange="this.parentElement.style.opacity=this.checked?'.3':'1'">
                                    <i class="bi bi-x"></i>
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <small class="text-muted">Tick image to remove</small>
                <?php endif; ?>
                <div class="z-upload-zone mt-2" id="galleryDrop">
                    <input type="file" name="gallery[]" id="galleryInput" accept="image/*" multiple hidden>
                    <i class="bi bi-plus-circle"></i>
                    <strong>Add more</strong>
                </div>
            </div>

            <div class="z-card mb-3">
                <h5>Organization</h5>
                <div class="mb-3">
                    <label style="font-size:13px;font-weight:600">Category *</label>
                    <select name="category_id" class="z-select w-100" required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <optgroup label="<?php echo e($cat->name); ?>">
                                <option value="<?php echo e($cat->id); ?>" <?php if($product->category_id == $cat->id): echo 'selected'; endif; ?>><?php echo e($cat->name); ?></option>
                                <?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($child->id); ?>" <?php if($product->category_id == $child->id): echo 'selected'; endif; ?>>— <?php echo e($child->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label style="font-size:13px;font-weight:600">Brand</label>
                    <select name="brand_id" class="z-select w-100">
                        <option value="">-- Select --</option>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($b->id); ?>" <?php if($product->brand_id == $b->id): echo 'selected'; endif; ?>><?php echo e($b->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="z-card mb-3">
                <h5>Flags</h5>
                <div class="z-check-group">
                    <label class="z-check"><input type="checkbox" name="is_featured" value="1" <?php if($product->is_featured): echo 'checked'; endif; ?>> Featured</label>
                    <label class="z-check"><input type="checkbox" name="is_trending" value="1" <?php if($product->is_trending): echo 'checked'; endif; ?>> Trending</label>
                    <label class="z-check"><input type="checkbox" name="is_new_arrival" value="1" <?php if($product->is_new_arrival): echo 'checked'; endif; ?>> New Arrival</label>
                    <label class="z-check"><input type="checkbox" name="is_best_seller" value="1" <?php if($product->is_best_seller): echo 'checked'; endif; ?>> Best Seller</label>
                </div>
            </div>

            <div class="z-card">
                <button type="submit" class="z-btn-primary w-100 mb-2">
                    <i class="bi bi-check2"></i> Update Product
                </button>
                <a href="<?php echo e(route('admin.products')); ?>" class="z-btn-ghost w-100 justify-content-center mb-2">Cancel</a>
                <hr>
                <button type="button" class="z-btn-ghost w-100 text-danger justify-content-center" id="deleteProduct">
                    <i class="bi bi-trash"></i> Delete Product
                </button>
            </div>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
    $('#thumbDrop').on('click', () => $('#thumbInput').click());
    $('#thumbInput').on('change', function () {
        const f = this.files[0]; if (!f) return;
        const r = new FileReader();
        r.onload = e => $('#thumbPreview').html(`<img src="${e.target.result}" style="width:100%;border-radius:10px">`);
        r.readAsDataURL(f);
    });
    $('#galleryDrop').on('click', () => $('#galleryInput').click());

    let specIdx = <?php echo e(isset($sIdx) ? $sIdx : 1); ?>;
    $('#addSpec').on('click', function () {
        $('#specsWrap').append(`
            <div class="spec-row row g-2 mb-2">
                <div class="col-5"><input type="text" name="specifications[${specIdx}][key]" class="z-input"></div>
                <div class="col-6"><input type="text" name="specifications[${specIdx}][value]" class="z-input"></div>
                <div class="col-1"><button type="button" class="z-act-btn text-danger remove-spec"><i class="bi bi-trash"></i></button></div>
            </div>
        `);
        specIdx++;
    });
    $(document).on('click', '.remove-spec', function () { $(this).closest('.spec-row').remove(); });

    $('#deleteProduct').on('click', function () {
        zConfirm('Delete product?', 'This cannot be undone.', function () {
            $.ajax({
                url: '<?php echo e(route("admin.products.destroy", $product)); ?>',
                method: 'DELETE'
            }).done(() => {
                zToast('Deleted', 'success');
                setTimeout(() => window.location.href = '<?php echo e(route("admin.products")); ?>', 600);
            });
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/admin/products/edit.blade.php ENDPATH**/ ?>