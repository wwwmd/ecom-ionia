<?php $__env->startSection('title', 'Follow-ups'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i>
    <span>CRM</span>
    <i class="bi bi-chevron-right"></i><span>Follow-ups</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <div>
        <h1>Follow-ups</h1>
        <p>Track all scheduled follow-ups</p>
    </div>
</div>

<div class="z-card">
    <div class="table-responsive">
        <table class="table z-table">
            <thead>
                <tr><th>Lead</th><th>Type</th><th>Scheduled</th><th>Agent</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $followups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <strong><?php echo e($f->lead->name ?? '—'); ?></strong>
                        <small class="d-block text-muted"><?php echo e($f->lead->lead_code ?? ''); ?></small>
                    </td>
                    <td><?php echo e(ucfirst($f->type)); ?></td>
                    <td><?php echo e($f->scheduled_at->format('d M Y, h:i A')); ?></td>
                    <td><?php echo e($f->agent->name ?? '—'); ?></td>
                    <td><span class="z-status z-status-<?php echo e($f->status === 'completed' ? 'delivered' : 'pending'); ?>"><?php echo e(ucfirst($f->status)); ?></span></td>
                    <td>
                        <?php if($f->status === 'pending'): ?>
                            <button class="z-act-btn complete-fu" data-id="<?php echo e($f->id); ?>" title="Mark Complete">
                                <i class="bi bi-check2"></i>
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center py-5 text-muted">No follow-ups scheduled</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-3 d-flex justify-content-center">
        <?php echo e($followups->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
    $('.complete-fu').on('click', function () {
        const id = $(this).data('id');
        $.post('<?php echo e(url("/admin/crm/followups")); ?>/' + id + '/complete')
            .done(() => { zToast('Marked complete', 'success'); setTimeout(() => location.reload(), 600); })
            .fail(() => zToast('Failed', 'error'));
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/admin/crm/followups/index.blade.php ENDPATH**/ ?>