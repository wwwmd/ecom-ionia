<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i><span>Orders</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <div>
        <h1>Orders</h1>
        <p><?php echo e($orders->total()); ?> orders</p>
    </div>
</div>

<div class="z-card mb-3">
    <form method="GET" class="z-filters">
        <div class="z-fi">
            <label>Status</label>
            <select name="status" class="z-select">
                <option value="">All</option>
                <?php $__currentLoopData = ['pending','confirmed','processing','packed','shipped','out_for_delivery','delivered','cancelled','returned','refunded']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s); ?>" <?php if(request('status') == $s): echo 'selected'; endif; ?>><?php echo e(ucfirst(str_replace('_',' ',$s))); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="z-fi">
            <label>Payment</label>
            <select name="payment" class="z-select">
                <option value="">All</option>
                <?php $__currentLoopData = ['pending','paid','cod_pending','refunded']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s); ?>" <?php if(request('payment') == $s): echo 'selected'; endif; ?>><?php echo e(ucfirst($s)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="z-fi"><label>From</label><input type="date" name="from" class="z-input" value="<?php echo e(request('from')); ?>"></div>
        <div class="z-fi"><label>To</label><input type="date" name="to" class="z-input" value="<?php echo e(request('to')); ?>"></div>
        <div class="z-fi z-fi-btn">
            <button class="z-btn-primary"><i class="bi bi-funnel"></i> Filter</button>
            <a href="<?php echo e(route('admin.orders')); ?>" class="z-btn-ghost">Reset</a>
        </div>
    </form>
</div>

<div class="z-card">
    <div class="table-responsive">
        <table class="table z-table">
            <thead>
                <tr>
                    <th>Order #</th>
                    <th>Customer</th>
                    <th>Date</th>
                    <th>Total</th>
                    <th>Payment</th>
                    <th>Status</th>
                    <th width="100">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><a href="<?php echo e(route('admin.orders.show', $o)); ?>" class="z-link"><strong><?php echo e($o->order_number); ?></strong></a></td>
                    <td>
                        <div class="z-user-cell">
                            <div class="z-uc-avatar"><?php echo e(strtoupper(substr($o->customer_name,0,1))); ?></div>
                            <div>
                                <strong><?php echo e($o->customer_name); ?></strong>
                                <small><?php echo e($o->customer_email); ?></small>
                            </div>
                        </div>
                    </td>
                    <td><?php echo e($o->created_at->format('d M Y')); ?></td>
                    <td><strong>₹<?php echo e(number_format($o->grand_total)); ?></strong></td>
                    <td><span class="z-status z-status-<?php echo e($o->payment_status); ?>"><?php echo e(ucfirst(str_replace('_',' ',$o->payment_status))); ?></span></td>
                    <td><span class="z-status z-status-<?php echo e($o->status); ?>"><?php echo e(ucfirst(str_replace('_',' ',$o->status))); ?></span></td>
                    <td>
                        <a href="<?php echo e(route('admin.orders.show', $o)); ?>" class="z-act-btn"><i class="bi bi-eye"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center py-5 text-muted">No orders yet</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-3 d-flex justify-content-center">
        <?php echo e($orders->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/store/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>