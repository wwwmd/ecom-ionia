<?php $__env->startSection('title', $product->name.' — store Store'); ?>
<?php $__env->startSection('meta_description', $product->meta_description ?? \Illuminate\Support\Str::limit($product->short_description, 155)); ?>

<?php $__env->startSection('content'); ?>
<div class="container z-pdp py-4">

    <nav class="z-breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Home</a>
        <i class="bi bi-chevron-right"></i>
        <a href="<?php echo e(url('/shop')); ?>">Shop</a>
        <i class="bi bi-chevron-right"></i>
        <a href="<?php echo e(url('/shop?category='.$product->category_id)); ?>"><?php echo e($product->category->name ?? 'Category'); ?></a>
        <i class="bi bi-chevron-right"></i>
        <span><?php echo e(\Illuminate\Support\Str::limit($product->name, 40)); ?></span>
    </nav>

    <div class="row g-4">
        <div class="col-lg-5">
            <div class="z-gallery">
                <div class="z-gallery-main">
                    <?php if($product->thumbnail): ?>
                        <img src="<?php echo e(asset($product->thumbnail)); ?>" id="mainImage" alt="<?php echo e($product->name); ?>">
                    <?php else: ?>
                        <div class="z-pc-placeholder" style="aspect-ratio:1/1;background:var(--z-light)">
                            <i class="bi bi-image" style="font-size:80px;color:var(--z-border)"></i>
                        </div>
                    <?php endif; ?>
                    <?php if($product->compare_price > $product->price): ?>
                        <span class="z-gallery-badge">
                            -<?php echo e($product->discount_percentage); ?>% OFF
                        </span>
                    <?php endif; ?>
                </div>

                <?php if($product->images->count()): ?>
                <div class="z-gallery-thumbs">
                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button class="z-thumb <?php echo e($loop->first ? 'active' : ''); ?>" data-img="<?php echo e(asset($img->path)); ?>">
                        <img src="<?php echo e(asset($img->path)); ?>" alt="">
                    </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-lg-7">
            <div class="z-pdp-info">
                <span class="z-pdp-brand"><?php echo e($product->brand->name ?? 'store'); ?></span>
                <h1><?php echo e($product->name); ?></h1>

                <div class="z-pdp-meta">
                    <?php if (isset($component)) { $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rating','data' => ['value' => $product->avg_rating,'count' => $product->review_count]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('rating'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->avg_rating),'count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->review_count)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $attributes = $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $component = $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
                    <span>·</span>
                    <?php if($product->isInStock()): ?>
                        <span class="text-success"><i class="bi bi-check-circle-fill"></i> In Stock</span>
                    <?php else: ?>
                        <span class="text-danger"><i class="bi bi-x-circle-fill"></i> Out of Stock</span>
                    <?php endif; ?>
                    <span>·</span>
                    <span>SKU: <?php echo e($product->sku); ?></span>
                </div>

                <div class="z-pdp-price">
                    <span class="z-price-big">₹<?php echo e(number_format($product->price)); ?></span>
                    <?php if($product->compare_price): ?>
                        <span class="z-price-old-big">₹<?php echo e(number_format($product->compare_price)); ?></span>
                        <span class="z-price-save">Save ₹<?php echo e(number_format($product->compare_price - $product->price)); ?></span>
                    <?php endif; ?>
                </div>

                <p class="z-pdp-short"><?php echo e($product->short_description); ?></p>

                <?php if($product->variants->count()): ?>
                <div class="z-pdp-option">
                    <label>Select Variant</label>
                    <div class="z-variants">
                        <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button class="z-variant <?php echo e($loop->first ? 'active' : ''); ?>" data-id="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="z-pdp-qty-row">
                    <div class="z-qty">
                        <button type="button" class="qty-minus">−</button>
                        <input type="number" id="qty" value="1" min="1">
                        <button type="button" class="qty-plus">+</button>
                    </div>
                    <button class="z-btn-primary z-btn-lg flex-grow-1 add-to-cart-btn" data-id="<?php echo e($product->id); ?>">
                        <i class="bi bi-bag-plus"></i> Add to Cart
                    </button>
                    <button class="z-btn-icon wishlist-btn" data-id="<?php echo e($product->id); ?>">
                        <i class="bi bi-heart"></i>
                    </button>
                </div>

                <button class="z-btn-buy w-100 mt-2" data-id="<?php echo e($product->id); ?>">
                    <i class="bi bi-lightning-charge-fill"></i> Buy Now
                </button>

                <div class="z-pdp-features">
                    <div><i class="bi bi-truck"></i> Free delivery above ₹999</div>
                    <div><i class="bi bi-arrow-repeat"></i> 7-day easy returns</div>
                    <div><i class="bi bi-shield-check"></i> 1-year warranty</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabs -->
    <div class="z-pdp-tabs mt-5">
        <ul class="nav nav-tabs" role="tablist">
            <li><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-desc">Description</button></li>
            <li><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-specs">Specifications</button></li>
            <li><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-reviews">Reviews (<?php echo e($product->review_count); ?>)</button></li>
        </ul>
        <div class="tab-content pt-3">
            <div class="tab-pane fade show active" id="tab-desc">
                <?php echo nl2br(e($product->description ?? $product->short_description)); ?>

            </div>
            <div class="tab-pane fade" id="tab-specs">
                <?php if($product->specifications): ?>
                <table class="table z-spec-table">
                    <?php $__currentLoopData = $product->specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr><th><?php echo e($k); ?></th><td><?php echo e($v); ?></td></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php else: ?>
                    <p class="text-muted">No specifications available.</p>
                <?php endif; ?>
            </div>
            <div class="tab-pane fade" id="tab-reviews">
                <?php $__empty_1 = true; $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="z-review">
                    <div class="z-review-head">
                        <strong><?php echo e($rev->customer->name ?? 'Guest'); ?></strong>
                        <?php if (isset($component)) { $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.rating','data' => ['value' => $rev->rating]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('rating'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($rev->rating)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $attributes = $__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__attributesOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197)): ?>
<?php $component = $__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197; ?>
<?php unset($__componentOriginaldaaa4f7e4868d5d2754fc46560cdd197); ?>
<?php endif; ?>
                    </div>
                    <p><?php echo e($rev->review); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">No reviews yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Related -->
    <?php if($related->count()): ?>
    <section class="z-section">
        <div class="z-section-head"><h2>You May Also Like</h2></div>
        <div class="row g-3">
            <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-md-3"><?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $rp]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($rp)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/store/resources/views/shop/show.blade.php ENDPATH**/ ?>