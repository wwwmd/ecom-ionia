<?php $__env->startSection('title', 'Shop All Products — Zambit Store'); ?>

<?php $__env->startSection('content'); ?>
<div class="container z-shop-page">
    <nav class="z-breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Home</a>
        <i class="bi bi-chevron-right"></i>
        <span>Shop</span>
    </nav>

    <div class="row g-4">

        <aside class="col-lg-3">
            <div class="z-filter-card">
                <h5>Filters</h5>

                <div class="z-filter-group">
                    <h6>Category</h6>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="z-filter-opt">
                        <input type="checkbox" class="cat-filter" value="<?php echo e($cat->id); ?>" <?php if(request('category') == $cat->id): echo 'checked'; endif; ?>>
                        <span><?php echo e($cat->name); ?></span>
                    </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="z-filter-group">
                    <h6>Price Range</h6>
                    <div class="z-price-range">
                        <input type="number" id="minPrice" placeholder="Min" value="<?php echo e(request('min')); ?>">
                        <span>–</span>
                        <input type="number" id="maxPrice" placeholder="Max" value="<?php echo e(request('max')); ?>">
                    </div>
                    <button class="z-btn-ghost w-100 mt-2" id="applyPrice">Apply</button>
                </div>

                <div class="z-filter-group">
                    <h6>Brands</h6>
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="z-filter-opt">
                        <input type="checkbox" class="brand-filter" value="<?php echo e($brand->id); ?>" <?php if(request('brand') == $brand->id): echo 'checked'; endif; ?>>
                        <span><?php echo e($brand->name); ?></span>
                    </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </aside>

        <div class="col-lg-9">
            <div class="z-shop-toolbar">
                <div><strong><?php echo e($products->total()); ?></strong> products found</div>
                <select class="z-select" id="sortBy">
                    <option value="latest" <?php if(request('sort') == 'latest'): echo 'selected'; endif; ?>>Latest</option>
                    <option value="price_asc" <?php if(request('sort') == 'price_asc'): echo 'selected'; endif; ?>>Price: Low to High</option>
                    <option value="price_desc" <?php if(request('sort') == 'price_desc'): echo 'selected'; endif; ?>>Price: High to Low</option>
                    <option value="popular" <?php if(request('sort') == 'popular'): echo 'selected'; endif; ?>>Popularity</option>
                    <option value="rating" <?php if(request('sort') == 'rating'): echo 'selected'; endif; ?>>Top Rated</option>
                </select>
            </div>

            <div class="row g-3 g-md-4">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-6 col-md-4">
                    <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="z-empty">
                        <i class="bi bi-inbox"></i>
                        <h4>No products found</h4>
                        <p>Try changing filters or search query.</p>
                        <a href="<?php echo e(url('/shop')); ?>" class="z-btn-primary">Reset Filters</a>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="mt-4 d-flex justify-content-center">
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
    $('#sortBy').on('change', function () {
        const p = new URLSearchParams(window.location.search);
        p.set('sort', this.value);
        window.location.search = p.toString();
    });

    $('.cat-filter, .brand-filter').on('change', function () {
        const p = new URLSearchParams(window.location.search);
        p.delete('category'); p.delete('brand');

        $('.cat-filter:checked').each((i, el) => p.append('category', el.value));
        $('.brand-filter:checked').each((i, el) => p.append('brand', el.value));

        window.location.search = p.toString();
    });

    $('#applyPrice').on('click', function () {
        const p = new URLSearchParams(window.location.search);
        const min = $('#minPrice').val();
        const max = $('#maxPrice').val();
        if (min) p.set('min', min); else p.delete('min');
        if (max) p.set('max', max); else p.delete('max');
        window.location.search = p.toString();
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/shop/index.blade.php ENDPATH**/ ?>