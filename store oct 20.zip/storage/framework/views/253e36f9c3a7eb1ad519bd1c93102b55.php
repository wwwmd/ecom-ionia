<?php $__env->startSection('title', 'Agent Dashboard'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i><span>Dashboard</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <div>
        <h1>Hello <?php echo e(auth()->user()->name); ?> 👋</h1>
        <p>You have <strong><?php echo e($stats['followups']); ?></strong> follow-ups today</p>
    </div>
    <div class="z-page-head-actions">
        <a href="<?php echo e(route('agent.leads')); ?>" class="z-btn-primary"><i class="bi bi-funnel"></i> My Leads</a>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="z-kpi z-kpi-blue">
            <div class="z-kpi-top"><div class="z-kpi-icon"><i class="bi bi-funnel"></i></div></div>
            <div class="z-kpi-value"><?php echo e($stats['leads']); ?></div>
            <div class="z-kpi-label">Assigned Leads</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="z-kpi z-kpi-orange">
            <div class="z-kpi-top"><div class="z-kpi-icon"><i class="bi bi-calendar-check"></i></div></div>
            <div class="z-kpi-value"><?php echo e($stats['followups']); ?></div>
            <div class="z-kpi-label">Today Follow-ups</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="z-kpi z-kpi-teal">
            <div class="z-kpi-top"><div class="z-kpi-icon"><i class="bi bi-trophy"></i></div></div>
            <div class="z-kpi-value"><?php echo e($stats['converted']); ?></div>
            <div class="z-kpi-label">Converted</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="z-kpi z-kpi-purple">
            <div class="z-kpi-top"><div class="z-kpi-icon"><i class="bi bi-cash-coin"></i></div></div>
            <div class="z-kpi-value">₹<?php echo e(number_format($stats['commission'], 0)); ?></div>
            <div class="z-kpi-label">Commission</div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-7">
        <div class="z-card">
            <div class="z-card-head">
                <h5>Today's Follow-ups</h5>
                <a href="<?php echo e(route('agent.followups')); ?>" class="z-link">View All</a>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $todayFollowups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div style="display:flex;align-items:center;gap:14px;padding:14px;border-radius:10px;border-bottom:1px solid var(--z-border)">
                    <div style="width:60px;font-weight:700;color:var(--z-blue);font-size:14px">
                        <?php echo e($f->scheduled_at->format('h:i A')); ?>

                    </div>
                    <div style="flex:1">
                        <strong style="display:block;font-size:14px"><?php echo e($f->lead->name ?? '—'); ?></strong>
                        <small style="color:var(--z-muted)"><i class="bi bi-<?php echo e(['telephone','whatsapp','envelope','people','bell'][array_search($f->type, ['call','whatsapp','email','meeting','other'])] ?? 'bell'); ?>"></i> <?php echo e(ucfirst($f->type)); ?></small>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted text-center py-4 mb-0">No follow-ups today</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="z-card">
            <div class="z-card-head">
                <h5>Recent Leads</h5>
                <a href="<?php echo e(route('agent.leads')); ?>" class="z-link">View All</a>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $recentLeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="z-lead-item">
                    <div class="z-li-avatar"><?php echo e(strtoupper(substr($l->name,0,1))); ?></div>
                    <div class="z-li-info">
                        <strong><?php echo e($l->name); ?></strong>
                        <small><?php echo e($l->created_at->diffForHumans()); ?></small>
                    </div>
                    <span class="z-status z-status-<?php echo e($l->status); ?>"><?php echo e(ucfirst($l->status)); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted text-center py-4 mb-0">No leads assigned</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/store/resources/views/agent/dashboard.blade.php ENDPATH**/ ?>