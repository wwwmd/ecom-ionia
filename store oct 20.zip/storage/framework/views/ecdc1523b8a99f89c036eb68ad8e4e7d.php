<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> — Store Admin</title>

<!-- Bootstrap + Icons + DataTables -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css" rel="stylesheet">

<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">

<!-- App CSS -->
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/store.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/admin.css')); ?>">


<?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="z-admin-body">

<?php
    $isAgent = auth()->check() && auth()->user()->isAgent();
?>

<div class="z-admin-wrap">

    
    <?php if($isAgent): ?>
        <?php echo $__env->make('partials.agent-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('partials.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <div class="z-admin-main">

        
        <?php echo $__env->make('partials.admin-topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <div class="z-admin-content">

            
            <nav class="z-admin-breadcrumb">
                <a href="<?php echo e($isAgent ? url('/agent/dashboard') : url('/admin/dashboard')); ?>">
                    <i class="bi bi-house-door"></i> Home
                </a>
                <?php echo $__env->yieldContent('breadcrumb'); ?>
            </nav>

            <?php echo $__env->yieldContent('content'); ?>
        </div>

        
        <footer class="z-admin-footer">
            © <?php echo e(date('Y')); ?> Store — Admin Panel
        </footer>
    </div>
</div>


<div class="z-popup-overlay" id="zPopupContainer"></div>


<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    window.Z_CONFIG = {
        baseUrl: "<?php echo e(url('/')); ?>",
        csrf: "<?php echo e(csrf_token()); ?>",
        isAgent: <?php echo e($isAgent ? 'true' : 'false'); ?>

    };
</script>

<script src="<?php echo e(asset('public/assets/js/store.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/admin.js')); ?>"></script>


<script>
$(function () {
    const successMsg = <?php echo json_encode(session('success'), 15, 512) ?>;
    const errorMsg   = <?php echo json_encode(session('error'), 15, 512) ?>;
    const warningMsg = <?php echo json_encode(session('warning'), 15, 512) ?>;
    const infoMsg    = <?php echo json_encode(session('info'), 15, 512) ?>;

    if (successMsg && window.zSuccess) window.zSuccess(successMsg);
    else if (errorMsg && window.zError) window.zError(errorMsg);
    else if (warningMsg && window.zWarning) window.zWarning(warningMsg);
    else if (infoMsg && window.zInfo) window.zInfo(infoMsg);
});
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /var/www/html/store/resources/views/layouts/admin.blade.php ENDPATH**/ ?>