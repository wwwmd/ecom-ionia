<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title><?php echo $__env->yieldContent('title', 'store Store — Premium Shopping'); ?></title>
<meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'Shop premium electronics, fashion & more at store Technologies.'); ?>">

<link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/store.css')); ?>">
<?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="z-main">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Mobile Bottom Nav -->
<nav class="z-mobile-nav d-lg-none">
    <a href="<?php echo e(url('/')); ?>" class="z-mn-item <?php echo e(request()->is('/') ? 'active' : ''); ?>">
        <i class="bi bi-house-door"></i><span>Home</span>
    </a>
    <a href="<?php echo e(url('/shop')); ?>" class="z-mn-item <?php echo e(request()->is('shop*') ? 'active' : ''); ?>">
        <i class="bi bi-grid"></i><span>Shop</span>
    </a>
    <a href="<?php echo e(url('/cart')); ?>" class="z-mn-item <?php echo e(request()->is('cart*') ? 'active' : ''); ?>">
        <i class="bi bi-bag"></i><span>Cart</span>
        <span class="z-badge" id="mobileCartCount">0</span>
    </a>
    <a href="<?php echo e(url('/wishlist')); ?>" class="z-mn-item">
        <i class="bi bi-heart"></i><span>Wishlist</span>
    </a>
    <a href="<?php echo e(auth()->check() ? url('/customer/dashboard') : url('/login')); ?>" class="z-mn-item">
        <i class="bi bi-person"></i><span>Account</span>
    </a>
</nav>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    window.Z_CONFIG = {
        baseUrl: "<?php echo e(url('/')); ?>",
        csrf: "<?php echo e(csrf_token()); ?>",
        isAuth: <?php echo e(auth()->check() ? 'true' : 'false'); ?>

    };
</script>
<script src="<?php echo e(asset('assets/js/store.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/mdehsan/store/resources/views/layouts/frontend.blade.php ENDPATH**/ ?>