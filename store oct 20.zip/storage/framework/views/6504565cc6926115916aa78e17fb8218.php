<?php $__env->startSection('title', 'Product Details'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <i class="bi bi-chevron-right"></i>
    <a href="<?php echo e(route('admin.products')); ?>">Products</a>
    <i class="bi bi-chevron-right"></i><span><?php echo e(\Illuminate\Support\Str::limit($product->name, 30)); ?></span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="z-page-head">
    <h1><?php echo e($product->name); ?></h1>
    <div class="z-page-head-actions">
        <a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="z-btn-primary"><i class="bi bi-pencil"></i> Edit</a>
        <a href="<?php echo e(route('admin.products')); ?>" class="z-btn-ghost"><i class="bi bi-arrow-left"></i> Back</a>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-4">
        <div class="z-card">
            <?php if($product->thumbnail): ?>
                <img src="<?php echo e(asset($product->thumbnail)); ?>" style="width:100%;border-radius:10px">
            <?php else: ?>
                <div style="aspect-ratio:1/1;background:var(--z-light);border-radius:10px;display:flex;align-items:center;justify-content:center">
                    <i class="bi bi-image" style="font-size:60px;color:var(--z-border)"></i>
                </div>
            <?php endif; ?>

            <div class="mt-3">
                <div class="d-flex justify-content-between mb-2"><span>SKU</span><strong><?php echo e($product->sku); ?></strong></div>
                <div class="d-flex justify-content-between mb-2"><span>Price</span><strong>₹<?php echo e(number_format($product->price)); ?></strong></div>
                <div class="d-flex justify-content-between mb-2"><span>Stock</span><strong><?php echo e($product->stock); ?></strong></div>
                <div class="d-flex justify-content-between"><span>Status</span>
                    <span class="z-status z-status-<?php echo e($product->status === 'active' ? 'delivered' : 'cancelled'); ?>"><?php echo e(ucfirst($product->status)); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="z-card mb-3">
            <h5>Description</h5>
            <p class="text-muted"><?php echo e($product->short_description); ?></p>
            <div><?php echo nl2br(e($product->description)); ?></div>
        </div>

        <?php if($product->specifications): ?>
        <div class="z-card mb-3">
            <h5>Specifications</h5>
            <table class="table z-table">
                <?php $__currentLoopData = $product->specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr><th style="width:40%"><?php echo e($k); ?></th><td><?php echo e($v); ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mdehsan/zambit-store/resources/views/admin/products/show.blade.php ENDPATH**/ ?>