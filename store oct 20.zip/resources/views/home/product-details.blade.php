@extends('layouts.frontend')
@section('title', 'Product-Details')

@section('content')
  <nav class="ionp-breadcrumb" aria-label="Breadcrumb">
    <ol class="ionp-breadcrumb-list">
      <li class="ionp-breadcrumb-item">
        <a href="/" class="ionp-breadcrumb-link">Home</a>
      </li>
      <li class="ionp-breadcrumb-sep" aria-hidden="true">/</li>
      <li class="ionp-breadcrumb-item">
        <span class="ionp-breadcrumb-current" aria-current="page">Products-Details</span>
      </li>
    </ol>
  </nav>
  <section class="ionpd-section" aria-labelledby="ionpdTitle">
    <div class="ionpd-container">
      <div class="ionpd-grid">

        <!-- ============ LEFT: GALLERY ============ -->
        <div class="ionpd-gallery">

          <!-- Main image with cursor-position zoom -->
          <div class="ionpd-main" id="ionpdMain">
            <!-- Base (normal) image -->
            <div class="ionpd-base" id="ionpdBase"></div>
            <!-- Zoom layer (hover par dikhega) -->
            <div class="ionpd-zoom" id="ionpdZoom" aria-hidden="true"></div>
          </div>

          <!-- Thumbnails -->
          <div class="ionpd-thumbs" id="ionpdThumbs">
            <button class="ionpd-thumb ionpd-active" type="button"
                    data-img="{{asset('public/assets/images/X-BLUE-5-PLATES-5.webp')}}">
              <img src="{{asset('public/assets/images/X-BLUE-5-PLATES-5.webp')}}" alt="View 1">
            </button>
            <button class="ionpd-thumb" type="button"
                    data-img="{{asset('public/assets/images/EN-7-P-1.webp')}}">
              <img src="{{asset('public/assets/images/EN-7-P-1.webp')}}" alt="View 2">
            </button>
            <button class="ionpd-thumb" type="button"
                    data-img="{{asset('public/assets/images/sm-230.1.webp')}}">
              <img src="{{asset('public/assets/images/sm-230.1.webp')}}" alt="View 3">
            </button>
            <button class="ionpd-thumb" type="button"
                    data-img="{{asset('public/assets/images/TL-112-9PLATES-1.webp')}}">
              <img src="{{asset('public/assets/images/TL-112-9PLATES-1.webp')}}" alt="View 4">
            </button>
          </div>
        </div>

        <!-- ============ RIGHT: INFO ============ -->
        <div class="ionpd-info">
          <h1 class="ionpd-title" id="ionpdTitle">Cream Concealer Refill</h1>
          <p class="ionpd-desc">
            Creamy, lightweight concealer colored from fruit and made with hydrating olive squalane.
          </p>
          <p class="ionpd-price">$80.00</p>

          <div class="ionpd-buyrow">
            <div class="ionpd-qty">
              <button class="ionpd-qty-btn" type="button" data-qty="minus" aria-label="Decrease quantity">−</button>
              <input class="ionpd-qty-input" id="ionpdQty" type="text" value="1" inputmode="numeric">
              <button class="ionpd-qty-btn" type="button" data-qty="plus" aria-label="Increase quantity">+</button>
            </div>
            {{-- <button class="ionpd-btn" type="button">ADD TO CART</button> --}}
            <button class="ionpd-btn" type="button">Buy Now</button>
          </div>

          <div class="ionpd-mini-row">
            <a class="ionpd-mini" href="#compare"><i class="fa-solid fa-code-compare"></i> COMPARE</a>
            <a class="ionpd-mini" href="#wishlist"><i class="fa-regular fa-heart"></i> ADD TO WISHLIST</a>
          </div>
{{--
          <div class="ionpd-share">
            <strong>Share:</strong>
            <a href="#facebook" aria-label="Share on Facebook"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="#twitter" aria-label="Share on Twitter"><i class="fa-brands fa-twitter"></i></a>
            <a href="#pinterest" aria-label="Share on Pinterest"><i class="fa-brands fa-pinterest-p"></i></a>
          </div> --}}

          <dl class="ionpd-meta">
            <dt>Vendor:</dt>   <dd>Partners Demo</dd>
            <dt>Type:</dt>     <dd>Makeup</dd>
            <dt>Sku:</dt>      <dd>KL9P6</dd>
            <dt>Available:</dt><dd>Available</dd>
          </dl>

          <div class="ionpd-visitors">
            Currently there are <span class="ionpd-num">12</span> peoples are currently looking at this product
          </div>

          <div class="ionpd-shipping">
            <i class="fa-solid fa-bag-shopping"></i>
            Spend <strong>$200.00</strong> for FREE SHIPPING
          </div>

          {{-- <span class="ionpd-deal">End Deal</span> --}}
        </div>
      </div>
    </div>
  </section>
  <section class="iondr-section" aria-label="Product description and reviews">
    <div class="iondr-container">

      <!-- ================= TABS ================= -->
      <div class="iondr-tabs" role="tablist">
        <button class="iondr-tab iondr-active" type="button"
                data-tab="desc" role="tab" aria-selected="true">DESCRIPTION</button>
        <button class="iondr-tab" type="button"
                data-tab="review" role="tab" aria-selected="false">REVIEW</button>
      </div>

      <!-- ================= PANEL: DESCRIPTION ================= -->
      <div class="iondr-panel iondr-active" id="iondrPanelDesc" role="tabpanel">
        <p class="iondr-desc-text">
          Woman's zipped leather jacket. Adjustable belt for a comfortable fit, complete with shoulder pads and front zip pocket.
        </p>


      </div>

      <!-- ================= PANEL: REVIEW ================= -->
      <div class="iondr-panel" id="iondrPanelReview" role="tabpanel">
        <div class="iondr-review-list">

          <article class="iondr-review">
            <div class="iondr-review-stars">★★★★★</div>
            <h4 class="iondr-review-title">Amazing quality</h4>
            <p class="iondr-review-text">The finish is so smooth and it stays all day. Totally worth it.</p>
            <span class="iondr-review-author">— Priya S.</span>
          </article>

          <article class="iondr-review">
            <div class="iondr-review-stars">★★★★★</div>
            <h4 class="iondr-review-title">Lightweight & hydrating</h4>
            <p class="iondr-review-text">Feels like nothing on the skin but covers everything. Love it.</p>
            <span class="iondr-review-author">— Aditya R.</span>
          </article>

          <article class="iondr-review">
            <div class="iondr-review-stars">★★★★☆</div>
            <h4 class="iondr-review-title">Great value</h4>
            <p class="iondr-review-text">Good coverage, blends easily, and a little goes a long way.</p>
            <span class="iondr-review-author">— Sneha K.</span>
          </article>

          <article class="iondr-review">
            <div class="iondr-review-stars">★★★★★</div>
            <h4 class="iondr-review-title">My new favourite</h4>
            <p class="iondr-review-text">Perfect for daily use. Doesn't cake or settle into fine lines.</p>
            <span class="iondr-review-author">— Rohan M.</span>
          </article>

        </div>
      </div>

        <div class="iondr-hero">
<video class="iondr-hero-video"
       src="{{asset('public/assets/videos/baground.mp4')}}"

       autoplay muted loop playsinline></video>

          <div class="iondr-hero-overlay" aria-hidden="true"></div>
        </div>

    </div>
  </section>
   <section class="ionp-section" aria-labelledby="ionpTitle">
    <div class="ionp-container">

      <!-- PAGE TITLE -->
      <header class="omnx-news-header">

        <h1 class="omnx-news-title" id="omnxNewsHeading">You may also  <em>like</em></h1>
        {{-- <p class="omnx-news-subtitle">Subscribe for latest news and blog updates from our editor.</p> --}}
      </header>


      <!-- TOOLBAR -->


      <!-- PRODUCT GRID -->
      <div class="ionp-grid" id="ionpGrid">

        <!-- CARD 1 -->
        <article class="ionp-card" data-name="Better Naked Palette" data-price="60">
          <div class="ionp-img-wrap">
            <img class="ionp-img" src="{{asset('public/assets/images/X-BLUE-5-PLATES-5.webp')}}" alt="Better Naked Palette">
            <div class="ionp-actions">
              <button class="ionp-action" type="button">PRODUCT DETAILS <i class="fa-solid fa-arrow-right"></i></button>
            </div>
          </div>
          <a class="ionp-name" href="#product">Ionia X-BLUE Alkaline</a>
          <p class="ionp-price">$60.00</p>
        </article>

        <!-- CARD 2 -->
        <article class="ionp-card" data-name="Ionia EN-7P – Alkaline" data-price="70">
          <div class="ionp-img-wrap">
            <img class="ionp-img" src="{{asset('public/assets/images/EN-7-P-1.webp')}}" alt="Ionia EN-7P – Alkaline">
            <div class="ionp-actions">
              <button class="ionp-action" type="button">PRODUCT DETAILS <i class="fa-solid fa-arrow-right"></i></button>
            </div>
          </div>
          <a class="ionp-name" href="#product">Ionia EN-7P – Alkaline</a>
          <p class="ionp-price">$70.00</p>
        </article>

        <!-- CARD 3 (badge + old price) -->
        <article class="ionp-card" data-name="Bright Eyed Illuminating" data-price="49">
          <div class="ionp-img-wrap">
            {{-- <span class="ionp-badge">5%</span> --}}
            <img class="ionp-img" src="{{asset('public/assets/images/sm-230.1.webp')}}" alt="Ionia SM-S230TL Alkaline">
            <div class="ionp-actions">
              <button class="ionp-action" type="button">PRODUCT DETAILS <i class="fa-solid fa-arrow-right"></i></button>
            </div>
          </div>
          <a class="ionp-name" href="#product">Ionia SM-S230TL Alkaline</a>
          <p class="ionp-price">$49.00 <span class="ionp-price-old">$52.00</span></p>
        </article>

        <!-- CARD 4 -->
        <article class="ionp-card" data-name="Ionia IO-400U – Alkaline" data-price="30">
          <div class="ionp-img-wrap">
            <img class="ionp-img" src="{{asset('public/assets/images/TL-112-9PLATES-1.webp')}}" alt="Ionia IO-400U – Alkaline">
            <div class="ionp-actions">
              <button class="ionp-action" type="button">PRODUCT DETAILS <i class="fa-solid fa-arrow-right"></i></button>
            </div>
          </div>
          <a class="ionp-name" href="#product">Ionia IO-400U – Alkaline</a>
          <p class="ionp-price">$30.00</p>
        </article>


      </div>
    </div>
  </section>
@endsection
@push('scripts')

  <script>
    (function () {
      const main    = document.getElementById('ionpdMain');
      const base    = document.getElementById('ionpdBase');
      const zoom    = document.getElementById('ionpdZoom');
      const thumbs  = document.querySelectorAll('.ionpd-thumb');
      const qtyInput = document.getElementById('ionpdQty');
      const qtyBtns  = document.querySelectorAll('.ionpd-qty-btn');

      // current active image URL (base + zoom both use same)
      let currentSrc = thumbs[0].getAttribute('data-img');

      // set both layers with same image
      function applyImage(src) {
        currentSrc = src;
        base.style.backgroundImage = 'url("' + src + '")';
        zoom.style.backgroundImage = 'url("' + src + '")';
        // reset zoom position to center
        zoom.style.backgroundPosition = '50% 50%';
      }

      // ============ CURSOR POSITION MAGNIFIER ============
      function moveZoom(e) {
        const rect = main.getBoundingClientRect();
        let x = e.clientX - rect.left;
        let y = e.clientY - rect.top;

        // clamp within bounds (0..1)
        let ratioX = x / rect.width;
        let ratioY = y / rect.height;

        if (ratioX < 0) ratioX = 0;
        if (ratioY < 0) ratioY = 0;
        if (ratioX > 1) ratioX = 1;
        if (ratioY > 1) ratioY = 1;

        // convert to percentage — cursor ke exact position par zoom
        const px = ratioX * 100;
        const py = ratioY * 100;

        zoom.style.backgroundPosition = px + '% ' + py + '%';
      }

      main.addEventListener('mouseenter', function (e) {
        moveZoom(e);
      });

      main.addEventListener('mousemove', function (e) {
        // mobile / touch par zoom skip
        if (window.innerWidth < 768) return;
        moveZoom(e);
      });

      // ============ THUMBNAIL SWAP ============
      thumbs.forEach(function (t) {
        const swap = function () {
          thumbs.forEach(function (x) { x.classList.remove('ionpd-active'); });
          t.classList.add('ionpd-active');
          const newSrc = t.getAttribute('data-img');
          if (newSrc) applyImage(newSrc);
        };
        t.addEventListener('mouseenter', swap);
        t.addEventListener('click', swap);
        t.addEventListener('focus', swap);
      });

      // ============ QUANTITY ============
      qtyBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
          let v = parseInt(qtyInput.value, 10);
          if (isNaN(v)) v = 1;
          if (btn.getAttribute('data-qty') === 'plus') v = v + 1;
          else v = v > 1 ? v - 1 : 1;
          qtyInput.value = v;
        });
      });
      qtyInput.addEventListener('input', function () {
        let v = qtyInput.value.replace(/\D/g, '');
        if (v === '' || parseInt(v, 10) < 1) v = '1';
        qtyInput.value = v;
      });

      // init
      applyImage(currentSrc);
    })();

       (function () {
      const tabs = document.querySelectorAll('.iondr-tab');
      const panels = {
        desc:   document.getElementById('iondrPanelDesc'),
        review: document.getElementById('iondrPanelReview')
      };

      tabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
          const key = tab.getAttribute('data-tab');

          tabs.forEach(function (t) {
            t.classList.remove('iondr-active');
            t.setAttribute('aria-selected', 'false');
          });
          tab.classList.add('iondr-active');
          tab.setAttribute('aria-selected', 'true');

          Object.keys(panels).forEach(function (k) {
            if (panels[k]) panels[k].classList.remove('iondr-active');
          });
          if (panels[key]) panels[key].classList.add('iondr-active');
        });
      });
    })();

    (() => {
      const header = document.getElementById('owHeader');
      const menuButton = document.getElementById('owMenuButton');
      const drawer = document.getElementById('owSideDrawer');
      const overlay = document.getElementById('owDrawerOverlay');
      const closeButton = document.getElementById('owDrawerClose');
      let lastFocus = null;

      function owOpenDrawer() {
        lastFocus = document.activeElement;
        header.classList.add('ow-menu-open');
        drawer.classList.add('ow-visible');
        overlay.classList.add('ow-visible');
        drawer.setAttribute('aria-hidden', 'false');
        overlay.setAttribute('aria-hidden', 'false');
        menuButton.setAttribute('aria-expanded', 'true');
        menuButton.setAttribute('aria-label', 'Close menu');
        document.body.classList.add('ow-body-locked');
        closeButton.focus();
      }
      function owCloseDrawer() {
        header.classList.remove('ow-menu-open');
        drawer.classList.remove('ow-visible');
        overlay.classList.remove('ow-visible');
        drawer.setAttribute('aria-hidden', 'true');
        overlay.setAttribute('aria-hidden', 'true');
        menuButton.setAttribute('aria-expanded', 'false');
        menuButton.setAttribute('aria-label', 'Open menu');
        document.body.classList.remove('ow-body-locked');
        if (lastFocus) lastFocus.focus();
      }

      menuButton.addEventListener('click', () => drawer.classList.contains('ow-visible') ? owCloseDrawer() : owOpenDrawer());
      closeButton.addEventListener('click', owCloseDrawer);
      overlay.addEventListener('click', owCloseDrawer);
      drawer.querySelectorAll('a').forEach(link => link.addEventListener('click', owCloseDrawer));
      document.addEventListener('keydown', event => {
        if (event.key === 'Escape' && drawer.classList.contains('ow-visible')) owCloseDrawer();
      });
      document.getElementById('owNewsletterForm').addEventListener('submit', event => {
        event.preventDefault();
        document.getElementById('owNewsletterMessage').textContent = 'Thanks! Connect this form to your newsletter service to collect subscriptions.';
        event.target.reset();
      });
    })();

        (function() {
      const slider = document.getElementById('heroSlider');
      const slides = Array.from(document.querySelectorAll('.blume-hero-slide'));
      const dots = Array.from(document.querySelectorAll('.blume-hero-dot'));
      const prevBtn = document.getElementById('prevBtn');
      const nextBtn = document.getElementById('nextBtn');
      const dotsContainer = document.getElementById('dotsContainer');

      let currentIndex = 0;
      let slideInterval = null;
      const SLIDE_DURATION = 6000; // ms, matches dot animation

      // ---- helper: go to slide ----
      function goToSlide(index) {
        // wrap around
        if (index < 0) index = slides.length - 1;
        if (index >= slides.length) index = 0;

        // update slides
        slides.forEach((slide, i) => {
          slide.classList.toggle('blume-hero-active', i === index);
        });

        // update dots
        dots.forEach((dot, i) => {
          dot.classList.toggle('blume-hero-active', i === index);
        });

        currentIndex = index;
        resetTimer();
      }

      // ---- next / prev ----
      function nextSlide() {
        goToSlide(currentIndex + 1);
      }

      function prevSlide() {
        goToSlide(currentIndex - 1);
      }

      // ---- autoplay timer ----
      function startTimer() {
        if (slideInterval) clearInterval(slideInterval);
        slideInterval = setInterval(() => {
          nextSlide();
        }, SLIDE_DURATION);
      }

      function resetTimer() {
        if (slideInterval) {
          clearInterval(slideInterval);
          slideInterval = null;
        }
        // only restart if not paused (we don't have pause now, but keep logic)
        startTimer();
      }

      // pause on hover (optional, nice UX)
      slider.addEventListener('mouseenter', () => {
        slider.classList.add('is-paused');
        if (slideInterval) {
          clearInterval(slideInterval);
          slideInterval = null;
        }
      });
      slider.addEventListener('mouseleave', () => {
        slider.classList.remove('is-paused');
        startTimer();
      });

      // ---- event listeners ----
      prevBtn.addEventListener('click', (e) => {
        e.preventDefault();
        prevSlide();
      });

      nextBtn.addEventListener('click', (e) => {
        e.preventDefault();
        nextSlide();
      });

      dots.forEach((dot, idx) => {
        dot.addEventListener('click', (e) => {
          e.preventDefault();
          goToSlide(idx);
        });
      });

      // keyboard navigation
      document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
          prevSlide();
        } else if (e.key === 'ArrowRight') {
          nextSlide();
        }
      });

      // ---- init ----
      // ensure first slide is active (already is in markup, but just in case)
      goToSlide(0);
      // start autoplay
      startTimer();

      // Cleanup on page unload (optional)
      window.addEventListener('beforeunload', () => {
        if (slideInterval) clearInterval(slideInterval);
      });
    })();

  </script>
@endpush
