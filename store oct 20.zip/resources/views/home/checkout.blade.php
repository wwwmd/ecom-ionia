{{-- resources/views/checkout.blade.php --}}
@extends('layouts.frontend')
@section('title', 'Checkout — Ionia')

@section('content')
<section class="ioncu-checkout-page">
    <div class="container">
        <div class="row g-4">

            {{-- ==================== LEFT : FORM ==================== --}}
            <div class="col-lg-7">
                <div class="ioncu-checkout-left">

                    {{-- ---------- STEP INDICATOR ---------- --}}
                    <div class="ioncu-steps">
                        <div class="ioncu-step is-active" data-step="1">
                            <span class="ioncu-step-num">1</span>
                            <span class="ioncu-step-label">Login</span>
                        </div>
                        <div class="ioncu-step" data-step="2">
                            <span class="ioncu-step-num">2</span>
                            <span class="ioncu-step-label">Address</span>
                        </div>
                        <div class="ioncu-step" data-step="3">
                            <span class="ioncu-step-num">3</span>
                            <span class="ioncu-step-label">Payment</span>
                        </div>
                    </div>

                    {{-- ================================================ --}}
                    {{-- STEP 1 : LOGIN                                  --}}
                    {{-- ================================================ --}}
                    <div class="ioncu-step-panel is-active" data-panel="1">
                        <div class="ioncu-panel-head">
                            <h3>Contact</h3>
                            @if(!auth()->check())
                                <a href="{{ url('/login') }}" class="ioncu-link">Sign in</a>
                            @else
                                <span class="ioncu-signed">
                                    Signed in as <strong>{{ auth()->user()->email }}</strong>
                                </span>
                            @endif
                        </div>

                        @guest
                            {{-- Guest : quick login / continue as guest --}}
                            <form method="POST" action="{{ url('/login') }}" class="ioncu-login-inline">
                                @csrf
                                <div class="ioncu-input-box">
                                    <input type="email" name="email" placeholder="Email or mobile phone number" required>
                                    <i class="bi bi-question-circle"></i>
                                </div>
                                <div class="ioncu-input-box">
                                    <input type="password" name="password" placeholder="Password" required>
                                </div>
                                <label class="ioncu-check">
                                    <input type="checkbox" name="remember"> <span>Email me with news and offers</span>
                                </label>
                                <button type="submit" class="ioncu-submit w-100 mt-3">
                                    <span>SIGN IN &amp; CONTINUE</span>
                                </button>
                            </form>
                            <p class="ioncu-guest-note">
                                Or <a href="#" class="ioncu-link" data-guest-continue>continue as guest</a>
                            </p>
                        @endguest

                        @auth
                            <div class="ioncu-signed-box">
                                <i class="bi bi-check-circle-fill"></i>
                                <span>You are logged in. Continue to add your delivery address.</span>
                            </div>
                            <button type="button" class="ioncu-submit w-100 mt-3" data-next="2">
                                <span>CONTINUE TO ADDRESS</span>
                            </button>
                        @endauth
                    </div>

                    {{-- ================================================ --}}
                    {{-- STEP 2 : ADDRESS                                --}}
                    {{-- ================================================ --}}
                    <div class="ioncu-step-panel" data-panel="2">
                        <div class="ioncu-panel-head">
                            <h3>Delivery</h3>
                        </div>

                        <form id="ioncuAddressForm" method="POST" action="{{ url('/checkout/address') }}">
                            @csrf

                            {{-- Country --}}
                            <div class="ioncu-input-box">
                                <select name="country" required>
                                    <option value="India" selected>India</option>
                                    <option value="USA">United States</option>
                                    <option value="UK">United Kingdom</option>
                                    <option value="UAE">United Arab Emirates</option>
                                </select>
                            </div>

                            {{-- Name row --}}
                            <div class="ioncu-row-2">
                                <div class="ioncu-input-box">
                                    <input type="text" name="first_name" placeholder="First name (optional)" value="{{ old('first_name', auth()->user()->first_name ?? '') }}">
                                </div>
                                <div class="ioncu-input-box">
                                    <input type="text" name="last_name" placeholder="Last name" required value="{{ old('last_name', auth()->user()->last_name ?? '') }}">
                                </div>
                            </div>

                            {{-- Address --}}
                            <div class="ioncu-input-box">
                                <input type="text" name="address" placeholder="Address" required value="{{ old('address') }}">
                            </div>

                            <div class="ioncu-input-box">
                                <input type="text" name="address2" placeholder="Apartment, suite, etc. (optional)" value="{{ old('address2') }}">
                            </div>

                            {{-- City / State / PIN --}}
                            <div class="ioncu-row-3">
                                <div class="ioncu-input-box">
                                    <input type="text" name="city" placeholder="City" required value="{{ old('city') }}">
                                </div>
                                <div class="ioncu-input-box">
                                    <select name="state" required>
                                        <option value="">State</option>
                                        <option value="MH">Maharashtra</option>
                                        <option value="DL">Delhi</option>
                                        <option value="KA">Karnataka</option>
                                        <option value="TN">Tamil Nadu</option>
                                        <option value="GJ">Gujarat</option>
                                    </select>
                                </div>
                                <div class="ioncu-input-box">
                                    <input type="text" name="pincode" placeholder="PIN code" required value="{{ old('pincode') }}">
                                </div>
                            </div>

                            <label class="ioncu-check">
                                <input type="checkbox" name="save_info" value="1" checked> <span>Save this information for next time</span>
                            </label>

                            {{-- Saved addresses (if any) --}}
                            @if(isset($savedAddresses) && $savedAddresses->count())
                                <div class="ioncu-saved-addresses">
                                    <h6>Saved addresses</h6>
                                    @foreach($savedAddresses as $addr)
                                        <label class="ioncu-saved-item">
                                            <input type="radio" name="saved_address_id" value="{{ $addr->id }}">
                                            <span>
                                                <strong>{{ $addr->first_name }} {{ $addr->last_name }}</strong><br>
                                                {{ $addr->address }}, {{ $addr->city }}, {{ $addr->state }} - {{ $addr->pincode }}
                                            </span>
                                        </label>
                                    @endforeach
                                </div>
                            @endif

                            <button type="submit" class="ioncu-submit w-100 mt-3">
                                <span>CONTINUE TO PAYMENT</span>
                            </button>
                        </form>
                    </div>

                    {{-- ================================================ --}}
                    {{-- STEP 3 : PAYMENT                                --}}
                    {{-- ================================================ --}}
                    <div class="ioncu-step-panel" data-panel="3">
                        <div class="ioncu-panel-head">
                            <h3>Payment</h3>
                        </div>
                        <p class="ioncu-panel-sub">All transactions are secure and encrypted.</p>

                        <div class="ioncu-payment-box is-disabled">
                            <i class="bi bi-credit-card-2-front"></i>
                            <p>This store can't accept payments right now.</p>
                        </div>

                        <button type="button" class="ioncu-submit w-100 mt-3" id="ioncuPayBtn" disabled>
                            <span>PAY NOW</span>
                        </button>

                        <p class="ioncu-secure-note">
                            <i class="bi bi-shield-lock"></i> Secured by Ionia Payments
                        </p>
                    </div>

                </div>
            </div>

            {{-- ==================== RIGHT : ORDER SUMMARY ==================== --}}
            <div class="col-lg-5">
                <div class="ioncu-summary">
                    <h4>Order Summary</h4>

                    @php
                        // Example product data — replace with your cart items
                        $items = $items ?? [
                            ['name' => 'Herbal Skin Remedy', 'qty' => 1, 'price' => 280.00, 'image' => 'https://via.placeholder.com/60'],
                        ];
                        $subtotal = collect($items)->sum(fn($i) => $i['qty'] * $i['price']);
                    @endphp

                    @foreach($items as $item)
                        <div class="ioncu-summary-item">
                            <div class="ioncu-summary-thumb">
                                <img src="{{ $item['image'] }}" alt="{{ $item['name'] }}">
                                <span class="ioncu-summary-qty">{{ $item['qty'] }}</span>
                            </div>
                            <div class="ioncu-summary-info">
                                <span>{{ $item['name'] }}</span>
                            </div>
                            <div class="ioncu-summary-price">
                                ${{ number_format($item['price'], 2) }}
                            </div>
                        </div>
                    @endforeach

                    <div class="ioncu-summary-line">
                        <span>Subtotal</span>
                        <span>${{ number_format($subtotal, 2) }}</span>
                    </div>
                    <div class="ioncu-summary-line">
                        <span>Shipping</span>
                        <span class="ioncu-muted">Enter shipping address</span>
                    </div>

                    <div class="ioncu-summary-total">
                        <span>Total</span>
                        <span>USD ${{ number_format($subtotal, 2) }}</span>
                    </div>
                </div>
            </div>

        </div>

        <p class="ioncu-copyright">All rights reserved. Ionia.</p>
    </div>

    {{-- ==================== SUCCESS POPUP ==================== --}}
    <div class="ioncu-success-overlay" id="ioncuSuccess">
        <div class="ioncu-success-card">
            <div class="ioncu-success-icon">
                <i class="bi bi-check-lg"></i>
            </div>
            <h3>Order Placed</h3>
            <p>Thank you! Your order has been placed successfully.</p>
            <div class="ioncu-success-actions">
                <a href="{{ url('/') }}" class="ioncu-submit"><span>CONTINUE SHOPPING</span></a>
            </div>
        </div>
    </div>
</section>
@endsection

@push('styles')
<style>
    /* ============================================================
       CHECKOUT PAGE — IONIA PREMIUM THEME
       ============================================================ */

    .ioncu-checkout-page {
        position: relative;
        min-height: 100vh;
        padding: 60px 0 40px;
        background: #ffffff;
        font-family: 'Segoe UI', Roboto, sans-serif;
    }

    /* ============================================================
       STEPS
       ============================================================ */
    .ioncu-steps {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 32px;
    }

    .ioncu-step {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 0.85rem;
        color: #b0b0b0;
        font-weight: 500;
        letter-spacing: 0.3px;
        transition: color 0.3s ease;
    }

    .ioncu-step-num {
        width: 26px;
        height: 26px;
        border-radius: 50%;
        background: #f0f0f0;
        color: #b0b0b0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.75rem;
        font-weight: 700;
        transition: all 0.3s ease;
    }

    .ioncu-step.is-active {
        color: #d95a0a;
    }

    .ioncu-step.is-active .ioncu-step-num {
        background: #d95a0a;
        color: #ffffff;
        box-shadow: 0 4px 10px -3px rgba(217, 90, 10, 0.5);
    }

    .ioncu-step.is-done .ioncu-step-num {
        background: #26a69a;
        color: #ffffff;
    }

    .ioncu-step.is-done {
        color: #26a69a;
    }

    /* ============================================================
       PANELS
       ============================================================ */
    .ioncu-step-panel {
        display: none;
        animation: ioncuFade 0.35s ease;
    }

    .ioncu-step-panel.is-active {
        display: block;
    }

    @keyframes ioncuFade {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .ioncu-panel-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 20px;
    }

    .ioncu-panel-head h3 {
        font-size: 1.15rem;
        font-weight: 600;
        color: #2b2b2b;
        margin: 0;
        letter-spacing: 0.2px;
    }

    .ioncu-panel-sub {
        font-size: 0.85rem;
        color: #8a8a8a;
        margin-bottom: 18px;
    }

    .ioncu-link {
        color: #d95a0a;
        font-size: 0.85rem;
        text-decoration: none;
        transition: color 0.2s ease;
        font-weight: 500;
    }

    .ioncu-link:hover {
        color: #c8372d;
        text-decoration: underline;
    }

    /* ============================================================
       INPUT BOX
       ============================================================ */
    .ioncu-input-box {
        position: relative;
        margin-bottom: 14px;
    }

    .ioncu-input-box input,
    .ioncu-input-box select {
        width: 100%;
        height: 48px;
        padding: 0 16px;
        border: 1.5px solid #e0e0e0;
        border-radius: 8px;
        font-size: 0.9rem;
        color: #2b2b2b;
        background: #ffffff;
        transition: all 0.25s ease;
        outline: none;
        font-family: inherit;
        appearance: none;
    }

    .ioncu-input-box select {
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23888' stroke-width='2'><polyline points='6 9 12 15 18 9'/></svg>");
        background-repeat: no-repeat;
        background-position: right 16px center;
        padding-right: 40px;
    }

    .ioncu-input-box input:focus,
    .ioncu-input-box select:focus {
        border-color: #d95a0a;
        box-shadow: 0 0 0 4px rgba(217, 90, 10, 0.10);
    }

    .ioncu-input-box input::placeholder {
        color: #b0b0b0;
        font-size: 0.88rem;
    }

    .ioncu-input-box i {
        position: absolute;
        right: 16px;
        top: 50%;
        transform: translateY(-50%);
        color: #b0b0b0;
        font-size: 1rem;
        pointer-events: none;
    }

    /* Row layouts */
    .ioncu-row-2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
    }

    .ioncu-row-3 {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        gap: 12px;
    }

    /* ============================================================
       CHECKBOX
       ============================================================ */
    .ioncu-check {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 0.85rem;
        color: #666;
        cursor: pointer;
        margin: 4px 0 18px;
        user-select: none;
    }

    .ioncu-check input {
        width: 16px;
        height: 16px;
        accent-color: #d95a0a;
        cursor: pointer;
    }

    /* ============================================================
       SAVED ADDRESSES
       ============================================================ */
    .ioncu-saved-addresses {
        margin: 18px 0 6px;
        padding-top: 18px;
        border-top: 1px solid #ececec;
    }

    .ioncu-saved-addresses h6 {
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        color: #8a8a8a;
        margin-bottom: 12px;
    }

    .ioncu-saved-item {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        padding: 12px 14px;
        border: 1.5px solid #e8e8e8;
        border-radius: 8px;
        margin-bottom: 10px;
        cursor: pointer;
        font-size: 0.85rem;
        color: #4a4a4a;
        line-height: 1.5;
        transition: all 0.2s ease;
    }

    .ioncu-saved-item:hover {
        border-color: #d95a0a;
        background: rgba(217, 90, 10, 0.03);
    }

    .ioncu-saved-item input {
        margin-top: 3px;
        accent-color: #d95a0a;
    }

    /* ============================================================
       LOGIN / GUEST AREA
       ============================================================ */
    .ioncu-login-inline {
        display: block;
    }

    .ioncu-signed-box {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 14px 16px;
        background: rgba(38, 166, 154, 0.06);
        border-left: 3px solid #26a69a;
        color: #1e7a70;
        font-size: 0.88rem;
    }

    .ioncu-signed-box i {
        font-size: 1.1rem;
    }

    .ioncu-signed {
        font-size: 0.8rem;
        color: #8a8a8a;
    }

    .ioncu-signed strong {
        color: #4a4a4a;
    }

    .ioncu-guest-note {
        text-align: center;
        font-size: 0.85rem;
        color: #8a8a8a;
        margin-top: 14px;
    }

    /* ============================================================
       PAYMENT
       ============================================================ */
    .ioncu-payment-box {
        background: #f7f7f7;
        border: 1.5px dashed #d4d4d4;
        border-radius: 10px;
        padding: 40px 20px;
        text-align: center;
        color: #8a8a8a;
        margin-bottom: 16px;
    }

    .ioncu-payment-box i {
        font-size: 2rem;
        color: #c0c0c0;
        display: block;
        margin-bottom: 12px;
    }

    .ioncu-payment-box p {
        font-size: 0.85rem;
        margin: 0;
    }

    .ioncu-payment-box.is-active {
        background: #ffffff;
        border-style: solid;
        border-color: #e0e0e0;
    }

    .ioncu-secure-note {
        text-align: center;
        font-size: 0.78rem;
        color: #b0b0b0;
        margin-top: 14px;
    }

    .ioncu-secure-note i {
        color: #26a69a;
        margin-right: 4px;
    }

    /* ============================================================
       BUTTON — IONIA PREMIUM
       ============================================================ */
    .ioncu-submit {
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        min-width: 130px;
        height: 50px;
        padding: 0 28px;
        border: 0;
        font-family: 'Inter', system-ui, sans-serif;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: .16em;
        text-transform: uppercase;
        color: #ffffff;
        background: #d95a0a;
        cursor: pointer;
        overflow: hidden;
        border-radius: 8px;
        box-shadow: 0 14px 30px -12px rgba(217, 90, 10, 0.7);
        transition: background .3s ease, letter-spacing .3s ease, box-shadow .3s ease, transform .3s ease;
        text-decoration: none;
    }

    .ioncu-submit:hover {
        background: #c8372d;
        letter-spacing: .20em;
        transform: translateY(-2px);
        box-shadow: 0 20px 40px -14px rgba(200, 55, 45, 0.85);
        color: #ffffff;
    }

    .ioncu-submit:active {
        transform: translateY(0);
        box-shadow: 0 8px 20px -10px rgba(200, 55, 45, 0.7);
    }

    .ioncu-submit::before {
        content: '';
        position: absolute;
        top: 0;
        left: -130%;
        width: 100%;
        height: 100%;
        background: linear-gradient(100deg, transparent 25%, rgba(255,255,255,0.30) 50%, transparent 75%);
        transition: left 0.75s cubic-bezier(0.2, 0.9, 0.3, 1);
        z-index: 2;
        pointer-events: none;
    }

    .ioncu-submit:hover::before {
        left: 130%;
    }

    .ioncu-submit span {
        position: relative;
        z-index: 3;
    }

    .ioncu-submit:disabled {
        background: #e0e0e0;
        color: #a0a0a0;
        box-shadow: none;
        cursor: not-allowed;
        transform: none;
    }

    .ioncu-submit:disabled:hover {
        background: #e0e0e0;
        letter-spacing: .16em;
    }

    .ioncu-submit:disabled::before {
        display: none;
    }

    /* ============================================================
       ORDER SUMMARY
       ============================================================ */
    .ioncu-summary {
        background: #fafafa;
        border: 1px solid #ececec;
        border-radius: 12px;
        padding: 26px 24px;
        position: sticky;
        top: 30px;
    }

    .ioncu-summary h4 {
        font-size: 0.95rem;
        font-weight: 600;
        color: #2b2b2b;
        letter-spacing: 0.3px;
        margin-bottom: 22px;
        padding-bottom: 16px;
        border-bottom: 1px solid #ececec;
    }

    .ioncu-summary-item {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 12px 0;
        border-bottom: 1px solid #f0f0f0;
    }

    .ioncu-summary-thumb {
        position: relative;
        width: 60px;
        height: 60px;
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid #ececec;
        flex-shrink: 0;
        background: #ffffff;
    }

    .ioncu-summary-thumb img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .ioncu-summary-qty {
        position: absolute;
        top: -8px;
        right: -8px;
        background: #d95a0a;
        color: #ffffff;
        font-size: 0.7rem;
        font-weight: 700;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 2px 6px rgba(217, 90, 10, 0.4);
    }

    .ioncu-summary-info {
        flex: 1;
        font-size: 0.88rem;
        color: #4a4a4a;
        line-height: 1.4;
    }

    .ioncu-summary-price {
        font-size: 0.88rem;
        color: #2b2b2b;
        font-weight: 500;
    }

    .ioncu-summary-line {
        display: flex;
        justify-content: space-between;
        font-size: 0.85rem;
        color: #6a6a6a;
        padding: 10px 0;
    }

    .ioncu-muted {
        color: #b0b0b0;
        font-style: italic;
        font-size: 0.8rem;
    }

    .ioncu-summary-total {
        display: flex;
        justify-content: space-between;
        font-size: 1rem;
        font-weight: 700;
        color: #2b2b2b;
        padding-top: 16px;
        margin-top: 10px;
        border-top: 1px solid #e0e0e0;
    }

    /* ============================================================
       COPYRIGHT
       ============================================================ */
    .ioncu-copyright {
        text-align: center;
        font-size: 0.75rem;
        color: #b0b0b0;
        margin-top: 50px;
        letter-spacing: 0.5px;
    }

    /* ============================================================
       SUCCESS POPUP
       ============================================================ */
    .ioncu-success-overlay {
        position: fixed;
        inset: 0;
        background: rgba(30, 20, 20, 0.55);
        backdrop-filter: blur(4px);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.35s ease, visibility 0.35s ease;
        padding: 20px;
    }

    .ioncu-success-overlay.is-show {
        opacity: 1;
        visibility: visible;
    }

    .ioncu-success-card {
        background: #ffffff;
        border-radius: 16px;
        padding: 48px 40px 36px;
        max-width: 420px;
        width: 100%;
        text-align: center;
        box-shadow: 0 30px 70px -20px rgba(200, 55, 45, 0.35);
        border-top: 4px solid #d95a0a;
        transform: translateY(20px) scale(0.96);
        transition: transform 0.4s cubic-bezier(0.2, 0.9, 0.3, 1);
    }

    .ioncu-success-overlay.is-show .ioncu-success-card {
        transform: translateY(0) scale(1);
    }

    .ioncu-success-icon {
        width: 72px;
        height: 72px;
        border-radius: 50%;
        background: linear-gradient(135deg, #d95a0a, #c8372d);
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 22px;
        color: #ffffff;
        font-size: 2rem;
        box-shadow: 0 14px 30px -10px rgba(217, 90, 10, 0.6);
    }

    .ioncu-success-card h3 {
        font-family: 'Georgia', 'Times New Roman', serif;
        font-size: 24px;
        font-weight: 400;
        color: #2b2b2b;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        margin-bottom: 12px;
    }

    .ioncu-success-card p {
        font-size: 0.9rem;
        color: #8a8a8a;
        line-height: 1.7;
        margin-bottom: 26px;
    }

    .ioncu-success-actions {
        display: flex;
        justify-content: center;
    }

    /* ============================================================
       RESPONSIVE
       ============================================================ */
    @media (max-width: 991px) {
        .ioncu-checkout-page {
            padding: 40px 12px 30px;
        }

        .ioncu-summary {
            position: static;
        }
    }

    @media (max-width: 575px) {
        .ioncu-row-2,
        .ioncu-row-3 {
            grid-template-columns: 1fr;
        }

        .ioncu-steps {
            gap: 8px;
        }

        .ioncu-step-label {
            display: none;
        }

        .ioncu-step.is-active .ioncu-step-label {
            display: inline;
        }

        .ioncu-panel-head h3 {
            font-size: 1rem;
        }

        .ioncu-success-card {
            padding: 36px 24px 28px;
        }
    }
   
</style>
@endpush

@push('scripts')
<script>
(function () {
    /* ============================================================
       STEP NAVIGATION
       ============================================================ */
    const panels = document.querySelectorAll('.ioncu-step-panel');
    const steps  = document.querySelectorAll('.ioncu-step');

    function goToStep(n) {
        panels.forEach(p => p.classList.toggle('is-active', p.dataset.panel == n));
        steps.forEach(s => {
            const sn = parseInt(s.dataset.step);
            s.classList.toggle('is-active', sn == n);
            s.classList.toggle('is-done', sn < n);
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Continue buttons
    document.querySelectorAll('[data-next]').forEach(btn => {
        btn.addEventListener('click', () => goToStep(btn.dataset.next));
    });

    // Guest continue → jump straight to address
    document.querySelectorAll('[data-guest-continue]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            goToStep(2);
        });
    });

    /* ============================================================
       ADDRESS FORM → PAYMENT
       ============================================================ */
    const addressForm = document.getElementById('ioncuAddressForm');
    if (addressForm) {
        addressForm.addEventListener('submit', function (e) {
            e.preventDefault();

            // Simple validation
            let ok = true;
            addressForm.querySelectorAll('[required]').forEach(inp => {
                if (!inp.value.trim()) {
                    inp.style.borderColor = '#c8372d';
                    ok = false;
                } else {
                    inp.style.borderColor = '#e0e0e0';
                }
            });
            if (!ok) return;

            // Enable payment & go to step 3
            const payBox = document.querySelector('.ioncu-payment-box');
            const payBtn = document.getElementById('ioncuPayBtn');
            if (payBox) {
                payBox.classList.remove('is-disabled');
                payBox.classList.add('is-active');
                payBox.innerHTML = `
                    <i class="bi bi-credit-card-2-front" style="color:#d95a0a;"></i>
                    <p style="color:#4a4a4a;font-weight:500;">Cash on Delivery / Card on file</p>
                `;
            }
            if (payBtn) payBtn.disabled = false;

            goToStep(3);
        });
    }

    /* ============================================================
       PAY NOW → SUCCESS POPUP
       ============================================================ */
    const payBtn = document.getElementById('ioncuPayBtn');
    const success = document.getElementById('ioncuSuccess');

    if (payBtn && success) {
        payBtn.addEventListener('click', () => {
            payBtn.disabled = true;
            payBtn.querySelector('span').textContent = 'PROCESSING...';

            // Simulate payment
            setTimeout(() => {
                success.classList.add('is-show');
                payBtn.querySelector('span').textContent = 'PAID';
                // TODO: fire an AJAX call here to place the real order
            }, 1200);
        });
    }

    /* ============================================================
       SAVED ADDRESS SELECT → AUTOFILL
       ============================================================ */
    document.querySelectorAll('input[name="saved_address_id"]').forEach(radio => {
        radio.addEventListener('change', function () {
            // For demo, just highlight. In production, autofill fields from your DB.
            document.querySelectorAll('.ioncu-saved-item').forEach(el => el.style.borderColor = '#e8e8e8');
            this.closest('.ioncu-saved-item').style.borderColor = '#d95a0a';
        });
    });
})();

(() => {
      const header = document.getElementById('owHeader');
      const menuButton = document.getElementById('owMenuButton');
      const drawer = document.getElementById('owSideDrawer');
      const overlay = document.getElementById('owDrawerOverlay');
      const closeButton = document.getElementById('owDrawerClose');
      let lastFocus = null;

      function owOpenDrawer() {
        lastFocus = document.activeElement;
        header.classList.add('ow-menu-open');
        drawer.classList.add('ow-visible');
        overlay.classList.add('ow-visible');
        drawer.setAttribute('aria-hidden', 'false');
        overlay.setAttribute('aria-hidden', 'false');
        menuButton.setAttribute('aria-expanded', 'true');
        menuButton.setAttribute('aria-label', 'Close menu');
        document.body.classList.add('ow-body-locked');
        closeButton.focus();
      }
      function owCloseDrawer() {
        header.classList.remove('ow-menu-open');
        drawer.classList.remove('ow-visible');
        overlay.classList.remove('ow-visible');
        drawer.setAttribute('aria-hidden', 'true');
        overlay.setAttribute('aria-hidden', 'true');
        menuButton.setAttribute('aria-expanded', 'false');
        menuButton.setAttribute('aria-label', 'Open menu');
        document.body.classList.remove('ow-body-locked');
        if (lastFocus) lastFocus.focus();
      }

      menuButton.addEventListener('click', () => drawer.classList.contains('ow-visible') ? owCloseDrawer() : owOpenDrawer());
      closeButton.addEventListener('click', owCloseDrawer);
      overlay.addEventListener('click', owCloseDrawer);
      drawer.querySelectorAll('a').forEach(link => link.addEventListener('click', owCloseDrawer));
      document.addEventListener('keydown', event => {
        if (event.key === 'Escape' && drawer.classList.contains('ow-visible')) owCloseDrawer();
      });
      document.getElementById('owNewsletterForm').addEventListener('submit', event => {
        event.preventDefault();
        document.getElementById('owNewsletterMessage').textContent = 'Thanks! Connect this form to your newsletter service to collect subscriptions.';
        event.target.reset();
      });
    })();

        (function() {
      const slider = document.getElementById('heroSlider');
      const slides = Array.from(document.querySelectorAll('.blume-hero-slide'));
      const dots = Array.from(document.querySelectorAll('.blume-hero-dot'));
      const prevBtn = document.getElementById('prevBtn');
      const nextBtn = document.getElementById('nextBtn');
      const dotsContainer = document.getElementById('dotsContainer');

      let currentIndex = 0;
      let slideInterval = null;
      const SLIDE_DURATION = 6000; // ms, matches dot animation

      // ---- helper: go to slide ----
      function goToSlide(index) {
        // wrap around
        if (index < 0) index = slides.length - 1;
        if (index >= slides.length) index = 0;

        // update slides
        slides.forEach((slide, i) => {
          slide.classList.toggle('blume-hero-active', i === index);
        });

        // update dots
        dots.forEach((dot, i) => {
          dot.classList.toggle('blume-hero-active', i === index);
        });

        currentIndex = index;
        resetTimer();
      }

      // ---- next / prev ----
      function nextSlide() {
        goToSlide(currentIndex + 1);
      }

      function prevSlide() {
        goToSlide(currentIndex - 1);
      }

      // ---- autoplay timer ----
      function startTimer() {
        if (slideInterval) clearInterval(slideInterval);
        slideInterval = setInterval(() => {
          nextSlide();
        }, SLIDE_DURATION);
      }

      function resetTimer() {
        if (slideInterval) {
          clearInterval(slideInterval);
          slideInterval = null;
        }
        // only restart if not paused (we don't have pause now, but keep logic)
        startTimer();
      }

      // pause on hover (optional, nice UX)
      slider.addEventListener('mouseenter', () => {
        slider.classList.add('is-paused');
        if (slideInterval) {
          clearInterval(slideInterval);
          slideInterval = null;
        }
      });
      slider.addEventListener('mouseleave', () => {
        slider.classList.remove('is-paused');
        startTimer();
      });

      // ---- event listeners ----
      prevBtn.addEventListener('click', (e) => {
        e.preventDefault();
        prevSlide();
      });

      nextBtn.addEventListener('click', (e) => {
        e.preventDefault();
        nextSlide();
      });

      dots.forEach((dot, idx) => {
        dot.addEventListener('click', (e) => {
          e.preventDefault();
          goToSlide(idx);
        });
      });

      // keyboard navigation
      document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
          prevSlide();
        } else if (e.key === 'ArrowRight') {
          nextSlide();
        }
      });

      // ---- init ----
      // ensure first slide is active (already is in markup, but just in case)
      goToSlide(0);
      // start autoplay
      startTimer();

      // Cleanup on page unload (optional)
      window.addEventListener('beforeunload', () => {
        if (slideInterval) clearInterval(slideInterval);
      });
    })();
</script>
@endpush
