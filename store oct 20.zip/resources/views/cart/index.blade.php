@extends('layouts.frontend')
@section('title', 'Shopping Cart — store Store')

@section('content')
<div class="container py-4">


    <h1 class="z-page-title">Shopping Cart</h1>

    @if($cartItems->isEmpty())
        <div class="z-empty">
            <i class="bi bi-bag-x"></i>
            <h4>Your cart is empty</h4>
            <p>Add products to start shopping.</p>
            <a href="{{ url('/shop') }}" class="z-btn-primary">Continue Shopping</a>
        </div>
    @else
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="z-cart-list">
                @foreach($cartItems as $item)
                <div class="z-cart-item" data-id="{{ $item->id }}">
                    @if($item->product->thumbnail)
                        <img src="{{ asset($item->product->thumbnail) }}" alt="">
                    @else
                        <div style="width:90px;height:90px;background:var(--z-light);border-radius:10px;display:flex;align-items:center;justify-content:center">
                            <i class="bi bi-image" style="font-size:28px;color:var(--z-border)"></i>
                        </div>
                    @endif
                    <div class="z-ci-info">
                        <h5>{{ $item->product->name }}</h5>
                        <span class="text-muted">₹{{ number_format($item->price) }} each</span>
                    </div>
                    <div class="z-qty">
                        <button type="button" class="qty-minus">−</button>
                        <input type="number" value="{{ $item->quantity }}" class="cart-qty" data-id="{{ $item->id }}">
                        <button type="button" class="qty-plus">+</button>
                    </div>
                    <div class="z-ci-total">₹{{ number_format($item->price * $item->quantity) }}</div>
                    <button class="z-remove remove-cart" data-id="{{ $item->id }}">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
                @endforeach
            </div>

            <a href="{{ url('/shop') }}" class="z-btn-ghost mt-3">
                <i class="bi bi-arrow-left"></i> Continue Shopping
            </a>
        </div>

        <div class="col-lg-4">
            <div class="z-summary">
                <h5>Order Summary</h5>

                <div class="z-coupon">
                    <input type="text" id="couponCode" placeholder="Coupon code">
                    <button id="applyCoupon" class="z-btn-ghost" type="button">Apply</button>
                </div>

                <div class="z-summary-row">
                    <span>Subtotal</span>
                    <span id="subTotal">₹{{ number_format($subtotal) }}</span>
                </div>
                <div class="z-summary-row">
                    <span>Discount</span>
                    <span id="discount" class="text-success">−₹{{ number_format($discount) }}</span>
                </div>
                <div class="z-summary-row">
                    <span>Tax (18%)</span>
                    <span>₹{{ number_format($tax) }}</span>
                </div>
                <div class="z-summary-row">
                    <span>Shipping</span>
                    <span>₹{{ number_format($shipping) }}</span>
                </div>
                <hr>
                <div class="z-summary-row z-total">
                    <span>Grand Total</span>
                    <span id="grandTotal">₹{{ number_format($grandTotal) }}</span>
                </div>

                <a href="{{ url('/checkout') }}" class="z-btn-primary w-100 mt-3">
                    Proceed to Checkout <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>
    @endif
</div>
@endsection
@push('styles')
<style>
     .z-page-title{
        padding-top: 100px;
        margin-bottom: 40px;
    }
</style>
@endpush
